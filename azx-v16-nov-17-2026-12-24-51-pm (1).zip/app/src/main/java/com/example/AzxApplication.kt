package com.example

import android.app.Application
import com.example.data.local.AzxDatabase
import com.example.data.local.AzxPreferencesDataStore
import com.example.data.repository.AzxRepository
import com.example.notifications.NotificationHelper
import com.google.android.filament.utils.Utils

class AzxApplication : Application() {
  lateinit var database: AzxDatabase
    private set
  lateinit var repository: AzxRepository
    private set

  override fun onCreate() {
    super.onCreate()
    runCatching { Utils.init() }
    database = AzxDatabase.getInstance(this)
    repository = AzxRepository(database, AzxPreferencesDataStore(this))
    NotificationHelper.ensureChannel(this)
  }
}
