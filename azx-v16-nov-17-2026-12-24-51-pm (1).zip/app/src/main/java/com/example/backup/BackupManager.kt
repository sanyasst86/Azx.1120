package com.example.backup

import android.content.ContentResolver
import android.net.Uri
import com.example.data.repository.FullBackupSnapshot
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class BackupEnvelope(
  val format: String = "AZX_V16_BACKUP",
  val version: Int = 1,
  val createdAt: Long,
  val sha256: String,
  val payloadJson: String,
)

sealed interface BackupVerifyResult {
  data class Valid(
    val snapshot: FullBackupSnapshot,
    val tasksCount: Int,
    val goalsCount: Int,
    val workoutsCount: Int,
    val xpTotal: Int,
  ) : BackupVerifyResult

  data class Invalid(val reason: String) : BackupVerifyResult
}

object BackupManager {
  private val json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    prettyPrint = false
  }

  fun serializeEnvelope(snapshot: FullBackupSnapshot): String {
    val payload = json.encodeToString(snapshot)
    val hash = sha256Hex(payload)
    val envelope =
      BackupEnvelope(
        createdAt = snapshot.exportedAt,
        sha256 = hash,
        payloadJson = payload,
      )
    return json.encodeToString(envelope)
  }

  fun verifyAndParseEnvelope(rawJson: String): BackupVerifyResult {
    return try {
      val env = json.decodeFromString<BackupEnvelope>(rawJson)
      if (env.format != "AZX_V16_BACKUP") {
        return BackupVerifyResult.Invalid("Неизвестный формат резервной копии.")
      }
      val actualHash = sha256Hex(env.payloadJson)
      if (!actualHash.equals(env.sha256, ignoreCase = true)) {
        return BackupVerifyResult.Invalid("Ошибка целостности (SHA-256 не совпадает). Файл повреждён.")
      }
      val snapshot = json.decodeFromString<FullBackupSnapshot>(env.payloadJson)
      BackupVerifyResult.Valid(
        snapshot = snapshot,
        tasksCount = snapshot.tasks.size,
        goalsCount = snapshot.goals.size,
        workoutsCount = snapshot.workoutHistories.size,
        xpTotal = snapshot.xpTransactions.sumOf { it.amount },
      )
    } catch (e: Exception) {
      BackupVerifyResult.Invalid("Не удалось прочитать резервную копию: ${e.message ?: "неверный JSON"}")
    }
  }

  suspend fun writeBackupToUri(
    contentResolver: ContentResolver,
    uri: Uri,
    snapshot: FullBackupSnapshot,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val text = serializeEnvelope(snapshot)
        contentResolver.openOutputStream(uri)?.use { out ->
          out.write(text.toByteArray(Charsets.UTF_8))
          out.flush()
        } ?: error("Не удалось открыть файл для записи")
      }
    }

  suspend fun readBackupFromUri(
    contentResolver: ContentResolver,
    uri: Uri,
  ): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        contentResolver.openInputStream(uri)?.use { input ->
          input.bufferedReader(Charsets.UTF_8).readText()
        } ?: error("Не удалось прочитать файл")
      }
    }

  fun sha256Hex(input: String): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
  }
}
