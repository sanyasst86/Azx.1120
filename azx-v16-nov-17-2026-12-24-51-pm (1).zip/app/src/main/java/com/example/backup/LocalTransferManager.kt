package com.example.backup

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class TransferSessionInfo(
  val ipAddress: String,
  val port: Int,
  val pin: String,
  val qrPayload: String,
  val qrBitmap: Bitmap,
)

object LocalTransferManager {

  fun getLocalIpv4Address(): String? {
    return try {
      val interfaces = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
      for (ni in interfaces) {
        if (!ni.isUp || ni.isLoopback) continue
        for (addr in ni.inetAddresses.toList()) {
          if (addr is Inet4Address && !addr.isLoopbackAddress) {
            return addr.hostAddress
          }
        }
      }
      null
    } catch (_: Exception) {
      null
    }
  }

  fun generateQrBitmap(payload: String, sizePx: Int = 512): Bitmap {
    val hints = mapOf(EncodeHintType.MARGIN to 1)
    val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    for (x in 0 until sizePx) {
      for (y in 0 until sizePx) {
        bmp.setPixel(x, y, if (matrix.get(x, y)) Color.BLACK else Color.WHITE)
      }
    }
    return bmp
  }

  fun parseQrPayload(raw: String): Triple<String, Int, String>? {
    return try {
      // Expected: azxv16://transfer?ip=192.168.1.10&port=54321&pin=1234
      if (!raw.startsWith("azxv16://transfer")) return null
      val query = raw.substringAfter("?", "")
      val params =
        query.split("&").mapNotNull { part ->
          val kv = part.split("=", limit = 2)
          if (kv.size == 2) kv[0] to kv[1] else null
        }.toMap()
      val ip = params["ip"] ?: return null
      val port = params["port"]?.toIntOrNull() ?: return null
      val pin = params["pin"] ?: return null
      Triple(ip, port, pin)
    } catch (_: Exception) {
      null
    }
  }

  suspend fun startServerOnce(
    envelopeJson: String,
    onServerReady: (TransferSessionInfo) -> Unit,
  ): Result<String> =
    withContext(Dispatchers.IO) {
      var server: ServerSocket? = null
      try {
        val ip = getLocalIpv4Address() ?: return@withContext Result.failure(
          IllegalStateException("Подключи устройство к Wi-Fi или точке доступа для локальной передачи."),
        )
        server = ServerSocket(0).apply { soTimeout = 120_000 }
        val port = server.localPort
        val pin = "%04d".format(Random.nextInt(1000, 9999))
        val payload = "azxv16://transfer?ip=$ip&port=$port&pin=$pin"
        val qr = generateQrBitmap(payload)
        withContext(Dispatchers.Main) {
          onServerReady(TransferSessionInfo(ip, port, pin, payload, qr))
        }

        val client = server.accept()
        client.use { socket ->
          val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
          val writer = PrintWriter(socket.getOutputStream(), true, Charsets.UTF_8)
          val clientPin = reader.readLine()?.trim()
          if (clientPin != pin) {
            writer.println("ERR_PIN")
            return@withContext Result.failure(SecurityException("Неверный PIN-код устройства-получателя."))
          }
          writer.println("OK")
          writer.println(envelopeJson)
          writer.flush()
        }
        Result.success("Данные успешно переданы по локальному Wi-Fi.")
      } catch (e: Exception) {
        Result.failure(e)
      } finally {
        runCatching { server?.close() }
      }
    }

  suspend fun receiveFromSender(
    ip: String,
    port: Int,
    pin: String,
  ): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        Socket(ip.trim(), port).use { socket ->
          socket.soTimeout = 15_000
          val writer = PrintWriter(socket.getOutputStream(), true, Charsets.UTF_8)
          val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
          writer.println(pin.trim())
          writer.flush()
          val status = reader.readLine()?.trim()
          if (status != "OK") {
            error(if (status == "ERR_PIN") "Неверный PIN-код" else "Отправитель отклонил соединение")
          }
          val body = reader.readLine() ?: error("Пустой ответ от отправителя")
          body
        }
      }
    }
}
