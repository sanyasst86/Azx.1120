package com.example.backup

import android.content.ContentResolver
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.example.data.repository.AzxRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class StatsReportData(
  val periodTitle: String,
  val displayName: String,
  val level: Int,
  val totalXp: Int,
  val streakDays: Int,
  val tasksDone: Int,
  val tasksTotal: Int,
  val goalsCompleted: Int,
  val goalsTotal: Int,
  val workoutsCount: Int,
  val basketballCount: Int,
  val habitsDoneCount: Int,
  val projectsDone: Int,
  val projectsTotal: Int,
  val unlockedAchievements: Int,
  val totalAchievements: Int,
  val directionBreakdown: List<Pair<String, Int>>,
)

object PdfReportGenerator {

  suspend fun exportStatisticsPdf(
    contentResolver: ContentResolver,
    uri: Uri,
    report: StatsReportData,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 72dpi
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, 595f, 842f, bgPaint)

        val titlePaint =
          Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
          }
        val subtitlePaint =
          Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.DKGRAY
            textSize = 11f
          }
        val sectionPaint =
          Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
          }
        val bodyPaint =
          Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 12f
          }
        val linePaint =
          Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1.5f
          }
        val barBgPaint = Paint().apply { color = Color.rgb(230, 230, 230) }
        val barFgPaint = Paint().apply { color = Color.BLACK }

        var y = 52f
        val left = 44f
        val right = 551f

        canvas.drawText("AZX.V16 — СТАТИСТИКА (${report.periodTitle.uppercase()})", left, y, titlePaint)
        y += 20f
        val dateStr = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
        canvas.drawText("Профиль: ${report.displayName} • Сформировано: $dateStr", left, y, subtitlePaint)
        y += 14f
        canvas.drawLine(left, y, right, y, linePaint)
        y += 28f

        canvas.drawText("ОСНОВНЫЕ ПОКАЗАТЕЛИ", left, y, sectionPaint)
        y += 22f
        val rows =
          listOf(
            "Уровень и опыт" to "Уровень ${report.level} • ${report.totalXp} XP",
            "Серия (Streak)" to "${report.streakDays} дн.",
            "Выполнено задач" to "${report.tasksDone} из ${report.tasksTotal}",
            "Цели (100%)" to "${report.goalsCompleted} из ${report.goalsTotal}",
            "Тренировки (BODY + др.)" to "${report.workoutsCount}",
            "Баскетбол (занятия)" to "${report.basketballCount}",
            "Отметки привычек" to "${report.habitsDoneCount}",
            "Проекты завершены" to "${report.projectsDone} из ${report.projectsTotal}",
            "Достижения" to "${report.unlockedAchievements} из ${report.totalAchievements}",
          )
        rows.forEach { (k, v) ->
          canvas.drawText(k, left, y, bodyPaint)
          canvas.drawText(v, 360f, y, sectionPaint.apply { textSize = 12f })
          y += 22f
        }

        y += 12f
        canvas.drawLine(left, y, right, y, linePaint)
        y += 26f
        canvas.drawText("АКТИВНОСТЬ ПО НАПРАВЛЕНИЯМ", left, y, sectionPaint.apply { textSize = 14f })
        y += 22f

        val maxVal = (report.directionBreakdown.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
        report.directionBreakdown.forEach { (dir, count) ->
          canvas.drawText(dir, left, y, bodyPaint)
          canvas.drawText("$count", 190f, y, bodyPaint)
          val barLeft = 225f
          val barMaxW = 320f
          val ratio = count.toFloat() / maxVal.toFloat()
          canvas.drawRect(barLeft, y - 10f, barLeft + barMaxW, y + 2f, barBgPaint)
          if (ratio > 0f) {
            canvas.drawRect(barLeft, y - 10f, barLeft + barMaxW * ratio, y + 2f, barFgPaint)
          }
          y += 26f
        }

        y = 800f
        canvas.drawText(
          "AZX.V16 — BUILD YOUR PRIME • Локальный оффлайн-отчёт без фиктивных данных",
          left,
          y,
          subtitlePaint,
        )

        doc.finishPage(page)
        contentResolver.openOutputStream(uri)?.use { out ->
          doc.writeTo(out)
          out.flush()
        } ?: error("Не удалось открыть PDF-файл")
        doc.close()
      }
    }
}
