package com.example.coach

import com.example.data.local.entity.CalendarEventEntity
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.ProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.WorkoutEntity
import com.example.data.repository.AzxRepository
import kotlin.math.min

enum class CoachHorizon(val titleRu: String) {
  DAY("День"),
  WEEK("Неделя"),
  MONTH("Месяц"),
}

data class CoachBlock(
  val id: String,
  val title: String,
  val direction: String,
  val dateEpochDay: Long,
  val startMinutes: Int,
  val durationMinutes: Int,
  val type: String, // STUDY, WORKOUT, TASK, REST
  val priority: Int,
  val linkedTaskId: Long? = null,
  val note: String = "",
)

data class CoachPlanResult(
  val horizon: CoachHorizon,
  val blocks: List<CoachBlock>,
  val overdueCount: Int,
  val freeMinutesEstimate: Int,
  val recommendations: List<String>,
)

/**
 * Локальный алгоритмический планировщик COACH (правила приоритетов, свободных окон,
 * баланса учёбы, тренировок и восстановления — без облачного ИИ).
 */
object CoachPlanner {

  fun buildPlan(
    horizon: CoachHorizon,
    baseDay: Long,
    profile: ProfileEntity,
    tasks: List<TaskEntity>,
    goals: List<GoalEntity>,
    workouts: List<WorkoutEntity>,
    existingEvents: List<CalendarEventEntity>,
  ): CoachPlanResult {
    val openTasks = tasks.filter { it.status == "TODO" }
    val overdueTasks = openTasks.filter { it.dateEpochDay < baseDay }
    val activeGoalIds = goals.filter { !it.isCompleted }.sortedByDescending { it.priority }.map { it.id }.toSet()

    val daysCount =
      when (horizon) {
        CoachHorizon.DAY -> 1
        CoachHorizon.WEEK -> 7
        CoachHorizon.MONTH -> 30
      }

    // Prioritize tasks: linked to high-priority goals & high priority & closer deadline first
    val prioritizedQueue =
      openTasks.sortedWith(
        compareByDescending<TaskEntity> { it.priority }
          .thenByDescending { if (it.goalId != null && it.goalId in activeGoalIds) 1 else 0 }
          .thenBy { it.dateEpochDay },
      ).toMutableList()

    val blocks = mutableListOf<CoachBlock>()
    var blockCounter = 0

    for (offset in 0 until daysCount) {
      val day = baseDay + offset
      val dayTasks =
        prioritizedQueue.filter { it.dateEpochDay == day || (offset == 0 && it.dateEpochDay < baseDay) }
      prioritizedQueue.removeAll(dayTasks.toSet())

      // Core school/study morning anchor & evening recovery anchor for a 14-year-old
      blocks +=
        CoachBlock(
          id = "coach_study_$offset",
          title = "Учёба и базовый фокус (MIND)",
          direction = "MIND",
          dateEpochDay = day,
          startMinutes = 9 * 60,
          durationMinutes = 120,
          type = "STUDY",
          priority = 3,
          note = "Утренний учебный слот без отвлечений на телефон",
        )

      // Free afternoon slots starting 15:30 up to 21:00 (max ~4 planned slots to avoid overload)
      var cursorMinutes = 15 * 60 + 30
      val dailyCap = 21 * 60

      // Include user's fixed calendar events if any on this day
      val fixed = existingEvents.filter { it.dateEpochDay == day && it.linkedTaskId == null }
      fixed.forEach { ev ->
        blocks +=
          CoachBlock(
            id = "ev_${ev.id}",
            title = ev.title,
            direction = ev.direction,
            dateEpochDay = day,
            startMinutes = ev.startTimeMinutes,
            durationMinutes = ev.durationMinutes,
            type = ev.type,
            priority = 3,
            note = ev.notes,
          )
      }

      // Schedule tasks into open afternoon windows
      val tasksForToday =
        if (dayTasks.isNotEmpty()) dayTasks.take(4)
        else prioritizedQueue.take(min(2, prioritizedQueue.size)).also { picked ->
          prioritizedQueue.removeAll(picked.toSet())
        }

      tasksForToday.forEach { task ->
        val preferredStart = task.timeMinutes ?: cursorMinutes
        val start = maxOf(preferredStart, cursorMinutes)
        if (start + task.durationMinutes <= dailyCap) {
          blocks +=
            CoachBlock(
              id = "task_${task.id}_${blockCounter++}",
              title = task.title,
              direction = task.direction,
              dateEpochDay = day,
              startMinutes = start,
              durationMinutes = task.durationMinutes.coerceIn(15, 120),
              type = if (task.direction == "BODY" || task.direction == "BASKETBALL") "WORKOUT" else "TASK",
              priority = task.priority,
              linkedTaskId = task.id,
              note = if (task.dateEpochDay < baseDay) "Перенесено COACH с прошлого дня" else task.description,
            )
          cursorMinutes = start + task.durationMinutes + 15 // 15-min rest buffer
        }
      }

      // Suggest workout or active recovery block if none scheduled on that day
      val hasWorkoutBlock = blocks.any { it.dateEpochDay == day && it.type == "WORKOUT" }
      if (!hasWorkoutBlock && workouts.isNotEmpty() && cursorMinutes + 30 <= dailyCap) {
        val suggested =
          if (offset % 3 == 2) workouts.firstOrNull { it.category == "RECOVERY" } ?: workouts.first()
          else workouts[offset % workouts.size]
        blocks +=
          CoachBlock(
            id = "coach_w_${offset}",
            title = if (offset % 3 == 2) "Восстановление: ${suggested.title}" else "Тренировка: ${suggested.title}",
            direction = if (suggested.category == "BASKETBALL") "BASKETBALL" else "BODY",
            dateEpochDay = day,
            startMinutes = cursorMinutes,
            durationMinutes = suggested.estimatedMinutes.coerceIn(20, 60),
            type = if (suggested.category == "RECOVERY") "REST" else "WORKOUT",
            priority = 2,
            note = "Баланс нагрузки и восстановления",
          )
        cursorMinutes += suggested.estimatedMinutes + 15
      }

      // Evening wind-down & rest block
      blocks +=
        CoachBlock(
          id = "coach_rest_$offset",
          title = "Гигиена, итоги дня и отдых без экрана",
          direction = "DISCIPLINE",
          dateEpochDay = day,
          startMinutes = 21 * 60 + 30,
          durationMinutes = 45,
          type = "REST",
          priority = 2,
          note = "Подготовка ко сну (рекомендовано 8–9 часов сна)",
        )
    }

    val todayBlocks = blocks.filter { it.dateEpochDay == baseDay }
    val busyToday = todayBlocks.sumOf { it.durationMinutes }
    val freeMinutes = (14 * 60 - busyToday).coerceAtLeast(0)

    val recommendations = buildList {
      if (overdueTasks.isNotEmpty()) {
        add("Обнаружено незавершённых прошлых задач: ${overdueTasks.size}. Используй перенос на сегодня без потери приоритетов.")
      }
      if (openTasks.isEmpty()) {
        add("Активных задач пока нет — добавь 2–3 ключевых шага по приоритетам: ${profile.priorities}.")
      }
      val highPriorityCount = openTasks.count { it.priority == 3 }
      if (highPriorityCount > 4) {
        add("Слишком много задач с высоким приоритетом ($highPriorityCount). Оставь максимум 3 главных на день.")
      }
      add("Окно свободного времени сегодня: ~$freeMinutes мин. Запланируй отдых каждые 45–60 минут работы.")
    }

    return CoachPlanResult(
      horizon = horizon,
      blocks = blocks.sortedWith(compareBy({ it.dateEpochDay }, { it.startMinutes })),
      overdueCount = overdueTasks.size,
      freeMinutesEstimate = freeMinutes,
      recommendations = recommendations,
    )
  }

  suspend fun carryOverOverdueTasks(repo: AzxRepository, tasks: List<TaskEntity>, targetDay: Long): Int {
    val overdue = tasks.filter { it.status == "TODO" && it.dateEpochDay < targetDay }
    overdue.forEach { t ->
      repo.saveTask(t.copy(dateEpochDay = targetDay))
    }
    return overdue.size
  }
}
