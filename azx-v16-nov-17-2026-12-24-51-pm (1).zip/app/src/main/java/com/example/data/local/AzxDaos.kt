package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.AchievementEntity
import com.example.data.local.entity.CalendarEventEntity
import com.example.data.local.entity.DiaryEntryEntity
import com.example.data.local.entity.ExerciseEntity
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitHistoryEntity
import com.example.data.local.entity.MissionEntity
import com.example.data.local.entity.ProfileEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.ProjectStepEntity
import com.example.data.local.entity.ReminderEntity
import com.example.data.local.entity.SettingsEntity
import com.example.data.local.entity.SubtaskEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.WorkoutEntity
import com.example.data.local.entity.WorkoutHistoryEntity
import com.example.data.local.entity.XPTransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CoreDao {
  // Profile
  @Query("SELECT * FROM profile WHERE id = 1")
  fun observeProfile(): Flow<ProfileEntity?>

  @Query("SELECT * FROM profile WHERE id = 1")
  suspend fun getProfileOnce(): ProfileEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertProfile(profile: ProfileEntity)

  // Settings
  @Query("SELECT * FROM settings WHERE id = 1")
  fun observeSettings(): Flow<SettingsEntity?>

  @Query("SELECT * FROM settings WHERE id = 1")
  suspend fun getSettingsOnce(): SettingsEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertSettings(settings: SettingsEntity)

  // Tasks
  @Query("SELECT * FROM tasks ORDER BY dateEpochDay ASC, COALESCE(timeMinutes, 1440) ASC, priority DESC")
  fun observeAllTasks(): Flow<List<TaskEntity>>

  @Query("SELECT * FROM tasks")
  suspend fun getAllTasksOnce(): List<TaskEntity>

  @Query("SELECT * FROM tasks WHERE id = :id")
  suspend fun getTaskById(id: Long): TaskEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTask(task: TaskEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTasks(tasks: List<TaskEntity>)

  @Update
  suspend fun updateTask(task: TaskEntity)

  @Delete
  suspend fun deleteTask(task: TaskEntity)

  @Query("DELETE FROM tasks")
  suspend fun clearTasks()

  // Goals & Subtasks
  @Query("SELECT * FROM goals ORDER BY isCompleted ASC, priority DESC, deadlineEpochDay ASC")
  fun observeAllGoals(): Flow<List<GoalEntity>>

  @Query("SELECT * FROM goals")
  suspend fun getAllGoalsOnce(): List<GoalEntity>

  @Query("SELECT * FROM goals WHERE id = :id")
  suspend fun getGoalById(id: Long): GoalEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGoal(goal: GoalEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGoals(goals: List<GoalEntity>)

  @Update
  suspend fun updateGoal(goal: GoalEntity)

  @Delete
  suspend fun deleteGoal(goal: GoalEntity)

  @Query("DELETE FROM subtasks WHERE goalId = :goalId")
  suspend fun deleteSubtasksByGoal(goalId: Long)

  @Query("SELECT * FROM subtasks ORDER BY orderIndex ASC, id ASC")
  fun observeAllSubtasks(): Flow<List<SubtaskEntity>>

  @Query("SELECT * FROM subtasks WHERE goalId = :goalId ORDER BY orderIndex ASC, id ASC")
  suspend fun getSubtasksForGoalOnce(goalId: Long): List<SubtaskEntity>

  @Query("SELECT * FROM subtasks")
  suspend fun getAllSubtasksOnce(): List<SubtaskEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSubtask(subtask: SubtaskEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSubtasks(subtasks: List<SubtaskEntity>)

  @Update
  suspend fun updateSubtask(subtask: SubtaskEntity)

  @Delete
  suspend fun deleteSubtask(subtask: SubtaskEntity)

  @Query("DELETE FROM goals")
  suspend fun clearGoals()

  @Query("DELETE FROM subtasks")
  suspend fun clearSubtasks()

  // Habits & History
  @Query("SELECT * FROM habits ORDER BY isActive DESC, createdAt ASC")
  fun observeAllHabits(): Flow<List<HabitEntity>>

  @Query("SELECT * FROM habits")
  suspend fun getAllHabitsOnce(): List<HabitEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHabit(habit: HabitEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHabits(habits: List<HabitEntity>)

  @Update
  suspend fun updateHabit(habit: HabitEntity)

  @Delete
  suspend fun deleteHabit(habit: HabitEntity)

  @Query("DELETE FROM habit_history WHERE habitId = :habitId")
  suspend fun deleteHistoryForHabit(habitId: Long)

  @Query("SELECT * FROM habit_history ORDER BY dateEpochDay DESC")
  fun observeAllHabitHistory(): Flow<List<HabitHistoryEntity>>

  @Query("SELECT * FROM habit_history")
  suspend fun getAllHabitHistoryOnce(): List<HabitHistoryEntity>

  @Query("SELECT * FROM habit_history WHERE habitId = :habitId AND dateEpochDay = :epochDay LIMIT 1")
  suspend fun getHabitHistoryEntry(habitId: Long, epochDay: Long): HabitHistoryEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHabitHistory(entry: HabitHistoryEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHabitHistories(entries: List<HabitHistoryEntity>)

  @Delete
  suspend fun deleteHabitHistory(entry: HabitHistoryEntity)

  @Query("DELETE FROM habits")
  suspend fun clearHabits()

  @Query("DELETE FROM habit_history")
  suspend fun clearHabitHistory()
}

@Dao
interface FitnessDao {
  @Query("SELECT * FROM exercises ORDER BY category ASC, nameRu ASC")
  fun observeAllExercises(): Flow<List<ExerciseEntity>>

  @Query("SELECT * FROM exercises")
  suspend fun getAllExercisesOnce(): List<ExerciseEntity>

  @Query("SELECT COUNT(*) FROM exercises")
  suspend fun countExercises(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertExercises(items: List<ExerciseEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertExercise(item: ExerciseEntity): Long

  @Query("SELECT * FROM workouts ORDER BY isCustom DESC, id ASC")
  fun observeAllWorkouts(): Flow<List<WorkoutEntity>>

  @Query("SELECT * FROM workouts")
  suspend fun getAllWorkoutsOnce(): List<WorkoutEntity>

  @Query("SELECT COUNT(*) FROM workouts")
  suspend fun countWorkouts(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertWorkouts(items: List<WorkoutEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertWorkout(workout: WorkoutEntity): Long

  @Delete
  suspend fun deleteWorkout(workout: WorkoutEntity)

  @Query("SELECT * FROM workout_history ORDER BY completedAt DESC")
  fun observeWorkoutHistory(): Flow<List<WorkoutHistoryEntity>>

  @Query("SELECT * FROM workout_history")
  suspend fun getAllWorkoutHistoryOnce(): List<WorkoutHistoryEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertWorkoutHistory(entry: WorkoutHistoryEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertWorkoutHistories(entries: List<WorkoutHistoryEntity>)

  @Query("DELETE FROM exercises")
  suspend fun clearExercises()

  @Query("DELETE FROM workouts")
  suspend fun clearWorkouts()

  @Query("DELETE FROM workout_history")
  suspend fun clearWorkoutHistory()
}

@Dao
interface GameProjectDao {
  // XP & Achievements & Missions
  @Query("SELECT * FROM xp_transactions ORDER BY createdAt DESC")
  fun observeXpTransactions(): Flow<List<XPTransactionEntity>>

  @Query("SELECT * FROM xp_transactions")
  suspend fun getAllXpTransactionsOnce(): List<XPTransactionEntity>

  @Query("SELECT COALESCE(SUM(amount), 0) FROM xp_transactions")
  fun observeTotalXp(): Flow<Int>

  @Query("SELECT COALESCE(SUM(amount), 0) FROM xp_transactions")
  suspend fun getTotalXpOnce(): Int

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertXpIfUnique(tx: XPTransactionEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertXpTransactions(list: List<XPTransactionEntity>)

  @Query("SELECT * FROM achievements ORDER BY isUnlocked DESC, requirementTarget ASC")
  fun observeAchievements(): Flow<List<AchievementEntity>>

  @Query("SELECT * FROM achievements")
  suspend fun getAllAchievementsOnce(): List<AchievementEntity>

  @Query("SELECT COUNT(*) FROM achievements")
  suspend fun countAchievements(): Int

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertAchievements(items: List<AchievementEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertAchievements(items: List<AchievementEntity>)

  @Update
  suspend fun updateAchievement(item: AchievementEntity)

  @Query("SELECT * FROM missions ORDER BY isWeekly ASC, isCompleted ASC, id ASC")
  fun observeMissions(): Flow<List<MissionEntity>>

  @Query("SELECT * FROM missions")
  suspend fun getAllMissionsOnce(): List<MissionEntity>

  @Query("SELECT * FROM missions WHERE periodKey = :periodKey")
  suspend fun getMissionsForPeriod(periodKey: String): List<MissionEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMissions(items: List<MissionEntity>)

  @Update
  suspend fun updateMission(item: MissionEntity)

  // Projects & Steps
  @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
  fun observeProjects(): Flow<List<ProjectEntity>>

  @Query("SELECT * FROM projects")
  suspend fun getAllProjectsOnce(): List<ProjectEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProject(project: ProjectEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProjects(projects: List<ProjectEntity>)

  @Update
  suspend fun updateProject(project: ProjectEntity)

  @Delete
  suspend fun deleteProject(project: ProjectEntity)

  @Query("DELETE FROM project_steps WHERE projectId = :projectId")
  suspend fun deleteStepsForProject(projectId: Long)

  @Query("SELECT * FROM project_steps ORDER BY orderIndex ASC, id ASC")
  fun observeProjectSteps(): Flow<List<ProjectStepEntity>>

  @Query("SELECT * FROM project_steps WHERE projectId = :projectId ORDER BY orderIndex ASC, id ASC")
  suspend fun getStepsForProjectOnce(projectId: Long): List<ProjectStepEntity>

  @Query("SELECT * FROM project_steps")
  suspend fun getAllProjectStepsOnce(): List<ProjectStepEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProjectStep(step: ProjectStepEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProjectSteps(steps: List<ProjectStepEntity>)

  @Update
  suspend fun updateProjectStep(step: ProjectStepEntity)

  @Delete
  suspend fun deleteProjectStep(step: ProjectStepEntity)

  // Diary & Calendar & Reminders
  @Query("SELECT * FROM diary_entries ORDER BY dateEpochDay DESC")
  fun observeDiaryEntries(): Flow<List<DiaryEntryEntity>>

  @Query("SELECT * FROM diary_entries")
  suspend fun getAllDiaryEntriesOnce(): List<DiaryEntryEntity>

  @Query("SELECT * FROM diary_entries WHERE dateEpochDay = :epochDay LIMIT 1")
  suspend fun getDiaryEntryByDay(epochDay: Long): DiaryEntryEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertDiaryEntry(entry: DiaryEntryEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDiaryEntries(entries: List<DiaryEntryEntity>)

  @Query("SELECT * FROM calendar_events ORDER BY dateEpochDay ASC, startTimeMinutes ASC")
  fun observeCalendarEvents(): Flow<List<CalendarEventEntity>>

  @Query("SELECT * FROM calendar_events")
  suspend fun getAllCalendarEventsOnce(): List<CalendarEventEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCalendarEvent(event: CalendarEventEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCalendarEvents(events: List<CalendarEventEntity>)

  @Update
  suspend fun updateCalendarEvent(event: CalendarEventEntity)

  @Delete
  suspend fun deleteCalendarEvent(event: CalendarEventEntity)

  @Query("DELETE FROM calendar_events WHERE dateEpochDay = :epochDay AND linkedTaskId IS NOT NULL")
  suspend fun clearPlannedTasksForDay(epochDay: Long)

  @Query("SELECT * FROM reminders ORDER BY hour ASC, minute ASC")
  fun observeReminders(): Flow<List<ReminderEntity>>

  @Query("SELECT * FROM reminders")
  suspend fun getAllRemindersOnce(): List<ReminderEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReminder(reminder: ReminderEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReminders(reminders: List<ReminderEntity>)

  @Update
  suspend fun updateReminder(reminder: ReminderEntity)

  @Delete
  suspend fun deleteReminder(reminder: ReminderEntity)

  @Query("DELETE FROM xp_transactions")
  suspend fun clearXpTransactions()

  @Query("DELETE FROM achievements")
  suspend fun clearAchievements()

  @Query("DELETE FROM missions")
  suspend fun clearMissions()

  @Query("DELETE FROM projects")
  suspend fun clearProjects()

  @Query("DELETE FROM project_steps")
  suspend fun clearProjectSteps()

  @Query("DELETE FROM diary_entries")
  suspend fun clearDiaryEntries()

  @Query("DELETE FROM calendar_events")
  suspend fun clearCalendarEvents()

  @Query("DELETE FROM reminders")
  suspend fun clearReminders()
}
