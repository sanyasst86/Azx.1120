package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.entity.AchievementEntity
import com.example.data.local.entity.CalendarEventEntity
import com.example.data.local.entity.DiaryEntryEntity
import com.example.data.local.entity.ExerciseEntity
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitHistoryEntity
import com.example.data.local.entity.MissionEntity
import com.example.data.local.entity.ProfileEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.ProjectStepEntity
import com.example.data.local.entity.ReminderEntity
import com.example.data.local.entity.SettingsEntity
import com.example.data.local.entity.SubtaskEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.WorkoutEntity
import com.example.data.local.entity.WorkoutHistoryEntity
import com.example.data.local.entity.XPTransactionEntity

@Database(
  entities = [
    ProfileEntity::class,
    TaskEntity::class,
    GoalEntity::class,
    SubtaskEntity::class,
    HabitEntity::class,
    HabitHistoryEntity::class,
    WorkoutEntity::class,
    ExerciseEntity::class,
    WorkoutHistoryEntity::class,
    XPTransactionEntity::class,
    AchievementEntity::class,
    MissionEntity::class,
    ProjectEntity::class,
    ProjectStepEntity::class,
    DiaryEntryEntity::class,
    CalendarEventEntity::class,
    ReminderEntity::class,
    SettingsEntity::class,
  ],
  version = 1,
  exportSchema = false,
)
abstract class AzxDatabase : RoomDatabase() {
  abstract fun coreDao(): CoreDao
  abstract fun fitnessDao(): FitnessDao
  abstract fun gameProjectDao(): GameProjectDao

  companion object {
    @Volatile private var INSTANCE: AzxDatabase? = null

    fun getInstance(context: Context): AzxDatabase {
      return INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
              context.applicationContext,
              AzxDatabase::class.java,
              "azx_v16.db",
            )
              .build()
              .also { INSTANCE = it }
        }
    }
  }
}
