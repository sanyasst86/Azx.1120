package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.azxDataStore: DataStore<Preferences> by preferencesDataStore(name = "azx_prefs")

class AzxPreferencesDataStore(private val context: Context) {

  private object Keys {
    val DAY_STARTED_EPOCH = longPreferencesKey("day_started_epoch")
    val SELECTED_ANATOMY_SIDE = stringPreferencesKey("selected_anatomy_side")
    val LAST_STATS_PERIOD = stringPreferencesKey("last_stats_period")
    val COACH_LAST_GENERATED_EPOCH = longPreferencesKey("coach_last_generated_epoch")
    val ATTRIBUTION_ACCEPTED = booleanPreferencesKey("attribution_accepted")
  }

  val dayStartedEpoch: Flow<Long> =
    context.azxDataStore.data.map { it[Keys.DAY_STARTED_EPOCH] ?: 0L }

  val selectedAnatomySide: Flow<String> =
    context.azxDataStore.data.map { it[Keys.SELECTED_ANATOMY_SIDE] ?: "FRONT" }

  val lastStatsPeriod: Flow<String> =
    context.azxDataStore.data.map { it[Keys.LAST_STATS_PERIOD] ?: "WEEK" }

  suspend fun setDayStarted(epochDay: Long) {
    context.azxDataStore.edit { it[Keys.DAY_STARTED_EPOCH] = epochDay }
  }

  suspend fun setAnatomySide(side: String) {
    context.azxDataStore.edit { it[Keys.SELECTED_ANATOMY_SIDE] = side }
  }

  suspend fun setStatsPeriod(period: String) {
    context.azxDataStore.edit { it[Keys.LAST_STATS_PERIOD] = period }
  }
}
