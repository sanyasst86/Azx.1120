package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "profile")
data class ProfileEntity(
  @PrimaryKey val id: Int = 1,
  val displayName: String = "Атлет",
  val age: Int = 14,
  val heightCm: Int = 168,
  val weightKg: Float = 56f,
  val fitnessLevel: String = "Базовый",
  val interests: String = "Баскетбол, Автосъёмка, Монтаж",
  val mainGoalsSummary: String = "Сила, техника броска, дисциплина дня",
  val priorities: String = "1. Учёба и сон • 2. Баскетбол и тело • 3. Проекты",
  val scheduleNotes: String = "Учёба 08:30–14:30 • Свободное время 16:00–20:30 • Отбой 22:30",
  val availableEquipment: String = "Турник, коврик, баскетбольный мяч, эспандер",
  val updatedAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(tableName = "tasks")
data class TaskEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val description: String = "",
  val direction: String = "DISCIPLINE",
  val dateEpochDay: Long,
  val timeMinutes: Int? = null,
  val durationMinutes: Int = 30,
  val priority: Int = 2, // 1=Низкий, 2=Средний, 3=Высокий
  val repeatRule: String = "NONE", // NONE, DAILY, WEEKLY
  val reminderEnabled: Boolean = false,
  val status: String = "TODO", // TODO, DONE, SKIPPED
  val goalId: Long? = null,
  val completedAt: Long? = null,
  val xpAwarded: Int = 25,
)

@Serializable
@Entity(tableName = "goals")
data class GoalEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val description: String = "",
  val direction: String,
  val priority: Int = 2,
  val deadlineEpochDay: Long,
  val progressPercent: Int = 0,
  val isCompleted: Boolean = false,
  val historyLog: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(
  tableName = "subtasks",
  indices = [Index("goalId")],
)
data class SubtaskEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val goalId: Long,
  val title: String,
  val isDone: Boolean = false,
  val orderIndex: Int = 0,
)

@Serializable
@Entity(tableName = "habits")
data class HabitEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val direction: String,
  val targetPerWeek: Int = 5,
  val currentStreak: Int = 0,
  val bestStreak: Int = 0,
  val reminderTimeMinutes: Int? = null,
  val isActive: Boolean = true,
  val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(
  tableName = "habit_history",
  indices = [Index(value = ["habitId", "dateEpochDay"], unique = true)],
)
data class HabitHistoryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val habitId: Long,
  val dateEpochDay: Long,
  val completed: Boolean = true,
  val moodScore: Int = 4,
  val note: String = "",
)
