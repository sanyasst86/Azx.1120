package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "workouts")
data class WorkoutEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val category: String, // HOME, GYM, AFK, LFK, BASKETBALL, RECOVERY, MOBILITY
  val description: String = "",
  val exerciseIdsCsv: String = "",
  val targetMusclesCsv: String = "",
  val estimatedMinutes: Int = 25,
  val isCustom: Boolean = false,
  val scheduledEpochDay: Long? = null,
)

@Serializable
@Entity(tableName = "exercises")
data class ExerciseEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val nameRu: String,
  val category: String, // HOME, GYM, AFK, LFK, BASKETBALL, RECOVERY, MOBILITY
  val description: String,
  val technique: String,
  val safetyNotes: String,
  val primaryMusclesCsv: String,
  val secondaryMusclesCsv: String = "",
  val defaultSets: Int = 3,
  val defaultReps: Int = 10,
  val defaultDurationSec: Int = 0,
  val restSec: Int = 60,
  val isBasketball: Boolean = false,
)

@Serializable
@Entity(tableName = "workout_history")
data class WorkoutHistoryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val workoutId: Long,
  val workoutTitle: String,
  val category: String,
  val durationMinutes: Int,
  val totalSetsCompleted: Int,
  val targetMusclesCsv: String,
  val completedAt: Long = System.currentTimeMillis(),
  val notes: String = "",
  val xpAwarded: Int = 60,
)
