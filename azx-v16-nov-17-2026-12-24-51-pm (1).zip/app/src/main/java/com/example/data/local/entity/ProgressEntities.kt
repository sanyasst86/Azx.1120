package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
  tableName = "xp_transactions",
  indices = [Index(value = ["actionKey"], unique = true)],
)
data class XPTransactionEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val actionKey: String,
  val sourceType: String, // TASK, WORKOUT, HABIT, SUBTASK, MISSION, ACHIEVEMENT, PROJECT_STEP, MIND, BASKETBALL
  val description: String,
  val amount: Int,
  val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(
  tableName = "achievements",
  indices = [Index(value = ["code"], unique = true)],
)
data class AchievementEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val code: String,
  val title: String,
  val description: String,
  val requirementType: String, // TASKS, WORKOUTS, BASKETBALL, HABITS, GOALS, PROJECTS, XP, STREAK
  val requirementTarget: Int,
  val isUnlocked: Boolean = false,
  val unlockedAt: Long? = null,
  val xpReward: Int = 50,
)

@Serializable
@Entity(tableName = "missions")
data class MissionEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val code: String,
  val title: String,
  val description: String,
  val isWeekly: Boolean = false,
  val periodKey: String, // e.g. "2026-11-16" or "2026-W46"
  val targetCount: Int,
  val currentCount: Int = 0,
  val xpReward: Int = 40,
  val isCompleted: Boolean = false,
  val xpClaimed: Boolean = false,
)

@Serializable
@Entity(tableName = "projects")
data class ProjectEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val category: String, // CAR_PHOTO, VIDEO_EDIT, CONTENT, OTHER
  val description: String = "",
  val deadlineEpochDay: Long,
  val status: String = "ACTIVE", // ACTIVE, PAUSED, DONE
  val progressPercent: Int = 0,
  val notes: String = "",
  val historyLog: String = "",
  val updatedAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(
  tableName = "project_steps",
  indices = [Index("projectId")],
)
data class ProjectStepEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val projectId: Long,
  val title: String,
  val isDone: Boolean = false,
  val orderIndex: Int = 0,
)

@Serializable
@Entity(
  tableName = "diary_entries",
  indices = [Index(value = ["dateEpochDay"], unique = true)],
)
data class DiaryEntryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val dateEpochDay: Long,
  val moodRating: Int = 3,
  val energyRating: Int = 3,
  val sleepHours: Float = 8f,
  val screenTimeMinutes: Int = 120,
  val gratitudeOrNote: String = "",
  val directionFocus: String = "DISCIPLINE",
  val isRestDay: Boolean = false,
  val updatedAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val direction: String,
  val dateEpochDay: Long,
  val startTimeMinutes: Int,
  val durationMinutes: Int = 45,
  val type: String = "TASK", // WORKOUT, STUDY, REST, TASK, EVENT
  val linkedTaskId: Long? = null,
  val notes: String = "",
)

@Serializable
@Entity(tableName = "reminders")
data class ReminderEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val targetType: String, // TASK, HABIT, WORKOUT, EVENT, DAILY_PLAN
  val targetId: Long = 0,
  val hour: Int,
  val minute: Int,
  val enabled: Boolean = true,
  val lastTriggeredEpochDay: Long = 0,
)

@Serializable
@Entity(tableName = "settings")
data class SettingsEntity(
  @PrimaryKey val id: Int = 1,
  val notificationsEnabled: Boolean = true,
  val dailyPlanHour: Int = 8,
  val dailyPlanMinute: Int = 0,
  val workoutSoundEnabled: Boolean = true,
  val coachAutoCarryOver: Boolean = true,
  val focusMinutes: Int = 25,
  val restMinutes: Int = 5,
  val screenTimeLimitMinutes: Int = 120,
  val lastBackupAt: Long = 0L,
)
