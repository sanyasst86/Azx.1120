package com.example.domain.model

import kotlin.math.floor
import kotlin.math.sqrt

data class LevelProgress(
  val level: Int,
  val currentXp: Int,
  val levelStartXp: Int,
  val nextLevelXp: Int,
  val progressFraction: Float,
  val rankTitle: String,
)

object LevelSystem {
  fun xpRequiredForLevel(level: Int): Int {
    if (level <= 1) return 0
    val n = level - 1
    return 100 * n + 50 * n * (n - 1) / 2
  }

  fun calculate(totalXp: Int): LevelProgress {
    val safeXp = totalXp.coerceAtLeast(0)
    var level = 1
    while (xpRequiredForLevel(level + 1) <= safeXp && level < 99) {
      level++
    }
    val start = xpRequiredForLevel(level)
    val next = xpRequiredForLevel(level + 1)
    val span = (next - start).coerceAtLeast(1)
    val fraction = ((safeXp - start).toFloat() / span.toFloat()).coerceIn(0f, 1f)
    return LevelProgress(
      level = level,
      currentXp = safeXp,
      levelStartXp = start,
      nextLevelXp = next,
      progressFraction = fraction,
      rankTitle = rankTitleFor(level),
    )
  }

  fun rankTitleFor(level: Int): String =
    when {
      level < 3 -> "СТАРТ"
      level < 6 -> "ИНИЦИАТОР"
      level < 10 -> "АТЛЕТ"
      level < 15 -> "СТРАТЕГ"
      level < 22 -> "ДИСЦИПЛИНА"
      level < 30 -> "ПРАЙМ"
      else -> "АБСОЛЮТ"
    }
}
