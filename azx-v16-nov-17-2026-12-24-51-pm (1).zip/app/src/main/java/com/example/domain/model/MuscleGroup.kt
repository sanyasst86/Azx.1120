package com.example.domain.model

enum class AnatomySide(val titleRu: String) {
  FRONT("Спереди"),
  BACK("Сзади"),
}

enum class MuscleGroup(
  val id: String,
  val titleRu: String,
  val side: AnatomySide,
  val functionRu: String,
  val safetyTip14Ru: String,
  val glbNodes: Set<String>,
) {
  // FRONT
  PECTORALS(
    id = "pectorals",
    titleRu = "Грудные мышцы",
    side = AnatomySide.FRONT,
    functionRu =
      "Приводят и сгибают плечо вперёд, участвуют в жимах, отжиманиях и передачах в баскетболе.",
    safetyTip14Ru =
      "В 14 лет фокусируйся на технике отжиманий и контролируемом темпе без предельных весов.",
    glbNodes = setOf("pectoralis-major", "pectoralis-minor", "subclavius"),
  ),
  ANTERIOR_DELTS(
    id = "anterior_delts",
    titleRu = "Передние дельты",
    side = AnatomySide.FRONT,
    functionRu = "Поднимают руку вперёд и стабилизируют плечевой сустав при броске и жиме.",
    safetyTip14Ru = "Обязательно разминай плечевые суставы перед нагрузкой, не работай через боль.",
    glbNodes = setOf("deltoid", "supraspinatus"),
  ),
  BICEPS(
    id = "biceps",
    titleRu = "Бицепсы",
    side = AnatomySide.FRONT,
    functionRu = "Сгибают локтевой сустав и разворачивают предплечье, стабилизируют плечо.",
    safetyTip14Ru = "Избегай раскачки корпуса, сохраняй ровное дыхание и полный контроль амплитуды.",
    glbNodes = setOf("biceps-brachii", "brachialis", "coracobrachialis"),
  ),
  FOREARMS(
    id = "forearms",
    titleRu = "Предплечья",
    side = AnatomySide.FRONT,
    functionRu = "Обеспечивают силу хвата, контроль кисти при ведении и выпуске баскетбольного мяча.",
    safetyTip14Ru = "Растягивай сгибатели и разгибатели запястья после баскетбольных тренировок.",
    glbNodes =
      setOf(
        "brachioradialis",
        "pronator-teres",
        "flexor-carpi-radialis",
        "palmaris-longus",
        "flexor-carpi-ulnaris",
        "flexor-digitorum-superficialis",
        "flexor-digitorum-profundus",
        "flexor-pollicis-longus",
        "pronator-quadratus",
        "supinator",
        "extensor-carpi-radialis-longus",
        "extensor-carpi-radialis-brevis",
        "extensor-digitorum",
        "extensor-digiti-minimi",
        "extensor-carpi-ulnaris",
        "abductor-pollicis-longus",
        "extensor-pollicis-brevis",
        "extensor-pollicis-longus",
        "extensor-indicis",
      ),
  ),
  RECTUS_ABDOMINIS(
    id = "rectus_abdominis",
    titleRu = "Прямая мышца живота",
    side = AnatomySide.FRONT,
    functionRu = "Сгибает позвоночник, удерживает корпус стабильным при прыжках, спринте и контакте.",
    safetyTip14Ru = "Удерживай поясницу прижатой в упражнениях на коврике, избегай рывков шеей.",
    glbNodes = setOf("rectus-abdominis", "pyramidalis", "linea-alba"),
  ),
  OBLIQUES(
    id = "obliques",
    titleRu = "Косые мышцы живота",
    side = AnatomySide.FRONT,
    functionRu = "Отвечают за вращение и боковую стабилизацию корпуса при смене направления.",
    safetyTip14Ru = "Сочетай планки и спокойные скручивания без скручивания позвоночника с тяжёлым весом.",
    glbNodes = setOf("external-oblique", "internal-oblique", "transversus-abdominis", "serratus-anterior"),
  ),
  QUADRICEPS(
    id = "quadriceps",
    titleRu = "Квадрицепсы",
    side = AnatomySide.FRONT,
    functionRu = "Разгибают коленный сустав, формируют мощность отталкивания в прыжке и приземлении.",
    safetyTip14Ru = "Следи, чтобы колени не заваливались внутрь при приседаниях и приземлениях.",
    glbNodes = setOf(
      "rectus-femoris",
      "vastus-lateralis",
      "vastus-medialis",
      "vastus-intermedius",
      "sartorius",
      "pectineus",
      "adductor-longus",
      "adductor-brevis",
      "gracilis",
    ),
  ),
  TIBIALIS_ANTERIOR(
    id = "tibialis_anterior",
    titleRu = "Передняя большеберцовая",
    side = AnatomySide.FRONT,
    functionRu = "Тыльно сгибает стопу, амортизирует шаг и защищает голеностоп в быстром беге.",
    safetyTip14Ru = "Укрепляй голень лёгкими подъёмами носков — это снижает риск усталости надкостницы.",
    glbNodes =
      setOf(
        "tibialis-anterior",
        "extensor-hallucis-longus",
        "extensor-digitorum-longus",
        "fibularis-tertius",
        "fibularis-longus",
        "fibularis-brevis",
      ),
  ),

  // BACK
  TRAPEZIUS(
    id = "trapezius",
    titleRu = "Трапеции",
    side = AnatomySide.BACK,
    functionRu = "Стабилизируют лопатки и шею, поддерживают правильную осанку и работу верхнего плечевого пояса.",
    safetyTip14Ru = "Не задирай плечи к ушам в тягах и отжиманиях, держи шею свободной.",
    glbNodes = setOf("trapezius", "levator-scapulae", "rhomboid-major", "rhomboid-minor", "sternocleidomastoid"),
  ),
  POSTERIOR_DELTS(
    id = "posterior_delts",
    titleRu = "Задние дельты",
    side = AnatomySide.BACK,
    functionRu = "Отводят руку назад, уравновешивают грудные мышцы и берегут осанку подростка.",
    safetyTip14Ru = "Тренируй с лёгкой резиной или собственным весом для баланса плечевого сустава.",
    glbNodes = setOf("deltoid", "infraspinatus", "teres-minor", "teres-major"),
  ),
  LATS(
    id = "lats",
    titleRu = "Широчайшие мышцы спины",
    side = AnatomySide.BACK,
    functionRu = "Тянут руки вниз и назад, формируют силовую базу в подтягиваниях и защите в баскетболе.",
    safetyTip14Ru = "Делай подтягивания и австралийские тяги без рывков, опускаясь в полный контроль.",
    glbNodes = setOf("latissimus-dorsi", "serratus-posterior-inferior"),
  ),
  TRICEPS(
    id = "triceps",
    titleRu = "Трицепсы",
    side = AnatomySide.BACK,
    functionRu = "Разгибают локоть, дают финальный импульс в броске по кольцу и при отжиманиях.",
    safetyTip14Ru = "Не перерастягивай локти, избегай резких падений в нижней точке.",
    glbNodes = setOf("triceps-brachii", "anconeus"),
  ),
  ERECTOR_SPINAE(
    id = "erector_spinae",
    titleRu = "Разгибатели спины",
    side = AnatomySide.BACK,
    functionRu = "Поддерживают позвоночник в нейтральном положении, защищают спину при движении.",
    safetyTip14Ru = "В период активного роста в 14 лет исключай осевые перегрузки; выбирай лодочку и планки.",
    glbNodes =
      setOf(
        "iliocostalis",
        "longissimus",
        "spinalis",
        "semispinalis",
        "multifidus",
        "quadratus-lumborum",
      ),
  ),
  GLUTES(
    id = "glutes",
    titleRu = "Ягодичные мышцы",
    side = AnatomySide.BACK,
    functionRu = "Главный двигатель ускорения, вертикального прыжка и стабильности таза.",
    safetyTip14Ru = "Включай ягодичный мостик в разминку для защиты коленей и поясницы.",
    glbNodes = setOf("gluteus-maximus", "gluteus-medius", "gluteus-minimus", "tensor-fasciae-latae"),
  ),
  HAMSTRINGS(
    id = "hamstrings",
    titleRu = "Бицепсы бёдер",
    side = AnatomySide.BACK,
    functionRu = "Сгибают колено, тормозят спринт и защищают связки при резких остановках.",
    safetyTip14Ru = "Регулярно выполняй мягкую растяжку задней поверхности бедра без боли.",
    glbNodes = setOf(
      "biceps-femoris",
      "semitendinosus",
      "semimembranosus",
      "adductor-magnus",
      "adductor-minimus",
      "popliteus",
    ),
  ),
  CALVES(
    id = "calves",
    titleRu = "Икроножные мышцы",
    side = AnatomySide.BACK,
    functionRu = "Отвечают за взрывной первый шаг, отталкивание стопой и работу ног в защите.",
    safetyTip14Ru = "Работай в полной амплитуде на ступеньке или полу и не забывай про ахиллово сухожилие.",
    glbNodes = setOf("gastrocnemius", "soleus", "plantaris", "calcaneal-tendon"),
  );

  companion object {
    fun byId(id: String): MuscleGroup? = entries.find { it.id == id }

    fun frontGroups(): List<MuscleGroup> = entries.filter { it.side == AnatomySide.FRONT }

    fun backGroups(): List<MuscleGroup> = entries.filter { it.side == AnatomySide.BACK }

    fun fromNodeName(nodeName: String, preferredSide: AnatomySide): MuscleGroup? {
      if (nodeName == "deltoid") {
        return if (preferredSide == AnatomySide.BACK) POSTERIOR_DELTS else ANTERIOR_DELTS
      }
      return entries.firstOrNull { nodeName in it.glbNodes }
    }

    fun parseCsv(csv: String): List<MuscleGroup> =
      csv.split(",").mapNotNull { byId(it.trim()) }
  }
}
