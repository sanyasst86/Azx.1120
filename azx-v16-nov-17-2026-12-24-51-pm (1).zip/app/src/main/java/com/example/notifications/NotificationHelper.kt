package com.example.notifications

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.R
import com.example.data.local.AzxDatabase
import com.example.data.repository.AzxRepository
import java.util.Calendar
import java.util.concurrent.TimeUnit

object NotificationHelper {
  const val CHANNEL_ID = "azx_reminders"
  private const val EXTRA_TITLE = "extra_title"
  private const val EXTRA_BODY = "extra_body"
  private const val EXTRA_NOTIF_ID = "extra_notif_id"

  fun ensureChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val channel =
        NotificationChannel(
          CHANNEL_ID,
          "AZX.V16 Напоминания",
          NotificationManager.IMPORTANCE_DEFAULT,
        ).apply {
          description = "Напоминания о задачах, привычках, тренировках и плане дня"
        }
      manager.createNotificationChannel(channel)
    }
  }

  fun hasNotificationPermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
    } else {
      true
    }
  }

  fun showNotification(context: Context, id: Int, title: String, body: String) {
    if (!hasNotificationPermission(context)) return
    ensureChannel(context)
    val tapIntent =
      Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
      }
    val pendingTap =
      PendingIntent.getActivity(
        context,
        id,
        tapIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
    val notif =
      NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setAutoCancel(true)
        .setContentIntent(pendingTap)
        .build()
    NotificationManagerCompat.from(context).notify(id, notif)
  }

  fun scheduleReminderAlarm(
    context: Context,
    requestCode: Int,
    hour: Int,
    minute: Int,
    title: String,
    body: String,
  ) {
    val cal =
      Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
        set(Calendar.MINUTE, minute.coerceIn(0, 59))
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) {
          add(Calendar.DAY_OF_YEAR, 1)
        }
      }
    val intent =
      Intent(context, ReminderReceiver::class.java).apply {
        putExtra(EXTRA_TITLE, title)
        putExtra(EXTRA_BODY, body)
        putExtra(EXTRA_NOTIF_ID, requestCode)
      }
    val pi =
      PendingIntent.getBroadcast(
        context,
        requestCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
  }

  fun cancelReminderAlarm(context: Context, requestCode: Int) {
    val intent = Intent(context, ReminderReceiver::class.java)
    val pi =
      PendingIntent.getBroadcast(
        context,
        requestCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmManager.cancel(pi)
  }

  fun scheduleDailyCheckWorker(context: Context, enabled: Boolean) {
    val wm = WorkManager.getInstance(context)
    if (!enabled) {
      wm.cancelUniqueWork("azx_daily_plan_check")
      return
    }
    val request =
      PeriodicWorkRequestBuilder<DailyPlanWorker>(12, TimeUnit.HOURS).build()
    wm.enqueueUniquePeriodicWork(
      "azx_daily_plan_check",
      ExistingPeriodicWorkPolicy.UPDATE,
      request,
    )
  }

  fun extractTitle(intent: Intent): String =
    intent.getStringExtra(EXTRA_TITLE) ?: "AZX.V16 — BUILD YOUR PRIME"

  fun extractBody(intent: Intent): String =
    intent.getStringExtra(EXTRA_BODY) ?: "Время проверить план дня и активные задачи."

  fun extractNotifId(intent: Intent): Int =
    intent.getIntExtra(EXTRA_NOTIF_ID, 1001)
}

class ReminderReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val title = NotificationHelper.extractTitle(intent)
    val body = NotificationHelper.extractBody(intent)
    val id = NotificationHelper.extractNotifId(intent)
    NotificationHelper.showNotification(context, id, title, body)
  }
}

class DailyPlanWorker(
  appContext: Context,
  params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
  override suspend fun doWork(): Result {
    val db = AzxDatabase.getInstance(applicationContext)
    val settings = db.coreDao().getSettingsOnce()
    if (settings != null && !settings.notificationsEnabled) return Result.success()

    val today = AzxRepository.todayEpochDay()
    val pendingToday =
      db.coreDao().getAllTasksOnce().count { it.dateEpochDay == today && it.status == "TODO" }
    val activeHabits = db.coreDao().getAllHabitsOnce().count { it.isActive }
    if (pendingToday > 0 || activeHabits > 0) {
      NotificationHelper.showNotification(
        applicationContext,
        9001,
        "AZX.V16 — План на сегодня",
        "Активных задач сегодня: $pendingToday • Привычек к контролю: $activeHabits.",
      )
    }
    return Result.success()
  }
}
