package com.example.ui.anatomy

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.ExerciseEntity
import com.example.domain.model.AnatomySide
import com.example.domain.model.MuscleGroup
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AnatomyModuleColors
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxChip
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.DarkGray
import com.example.ui.theme.Graphite
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun AnatomyScreen(
  exercises: List<ExerciseEntity>,
  initialExerciseId: Long? = null,
  isWideLayout: Boolean,
  onBack: () -> Unit,
  onSideChanged: (AnatomySide) -> Unit,
) {
  val initialEx = remember(initialExerciseId, exercises) {
    exercises.find { it.id == initialExerciseId }
  }
  val initialSide =
    remember(initialEx) {
      initialEx
        ?.let { MuscleGroup.parseCsv(it.primaryMusclesCsv).firstOrNull()?.side }
        ?: AnatomySide.FRONT
    }
  var currentSide by remember(initialEx) { mutableStateOf(initialSide) }
  var selectedMuscle by remember(initialEx) {
    mutableStateOf(if (initialEx == null) MuscleGroup.PECTORALS else null)
  }
  var selectedExercise by remember(initialExerciseId, exercises) {
    mutableStateOf(initialEx)
  }
  var showAttributionDialog by remember { mutableStateOf(false) }

  val controller = remember { Anatomy3DController() }

  val primaryMuscles: Set<MuscleGroup> =
    remember(selectedMuscle, selectedExercise) {
      when {
        selectedExercise != null ->
          MuscleGroup.parseCsv(selectedExercise!!.primaryMusclesCsv).toSet()
        selectedMuscle != null -> setOf(selectedMuscle!!)
        else -> emptySet()
      }
    }

  val secondaryMuscles: Set<MuscleGroup> =
    remember(selectedExercise) {
      selectedExercise?.let { MuscleGroup.parseCsv(it.secondaryMusclesCsv).toSet() } ?: emptySet()
    }

  val matchingExercises =
    remember(exercises, selectedMuscle) {
      if (selectedMuscle == null) exercises
      else
        exercises.filter { ex ->
          ex.primaryMusclesCsv.split(",").any { it.trim() == selectedMuscle!!.id } ||
            ex.secondaryMusclesCsv.split(",").any { it.trim() == selectedMuscle!!.id }
        }
    }

  val sideGroups =
    remember(currentSide) {
      if (currentSide == AnatomySide.FRONT) MuscleGroup.frontGroups() else MuscleGroup.backGroups()
    }

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    // Top Bar
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("anatomy_back_btn")) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = "Назад",
            tint = PureWhite,
          )
        }
        Column {
          Text(
            text = "3D АНАТОМИЯ ТЕЛА",
            style = MaterialTheme.typography.titleLarge,
            color = PureWhite,
          )
          Text(
            text = "Интерактивная 3D-модель мышц (177 анатомических структур)",
            style = MaterialTheme.typography.bodySmall,
            color = MidGray,
          )
        }
      }
      IconButton(onClick = { showAttributionDialog = true }) {
        Icon(
          imageVector = Icons.Rounded.Info,
          contentDescription = "Лицензия 3D-модели",
          tint = LightGray,
        )
      }
    }

    if (isWideLayout) {
      Row(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Box(modifier = Modifier.weight(1.1f).fillMaxHeight()) {
          AnatomyViewportCard(
            currentSide = currentSide,
            primaryMuscles = primaryMuscles,
            secondaryMuscles = secondaryMuscles,
            controller = controller,
            hasSelection = selectedMuscle != null || selectedExercise != null,
            onSideToggle = { side ->
              currentSide = side
              controller.setSide(side)
              onSideChanged(side)
              if (selectedExercise == null && selectedMuscle != null && selectedMuscle!!.side != side) {
                selectedMuscle = if (side == AnatomySide.FRONT) MuscleGroup.PECTORALS else MuscleGroup.LATS
              }
            },
            onMusclePicked = { picked ->
              selectedExercise = null
              selectedMuscle = picked
            },
            onClearSelection = {
              selectedMuscle = null
              selectedExercise = null
            },
          )
        }
        Spacer(modifier = Modifier.width(16.dp))
        AnatomyDetailsColumn(
          modifier = Modifier.weight(0.9f).fillMaxHeight(),
          currentSide = currentSide,
          sideGroups = sideGroups,
          selectedMuscle = selectedMuscle,
          selectedExercise = selectedExercise,
          matchingExercises = matchingExercises,
          onSelectMuscle = { mg ->
            selectedExercise = null
            selectedMuscle = if (selectedMuscle == mg) null else mg
            if (mg.side != currentSide) {
              currentSide = mg.side
              controller.setSide(mg.side)
              onSideChanged(mg.side)
            }
          },
          onSelectExercise = { ex ->
            selectedExercise = if (selectedExercise?.id == ex.id) null else ex
            selectedMuscle = null
            val firstPrimary = MuscleGroup.parseCsv(ex.primaryMusclesCsv).firstOrNull()
            if (firstPrimary != null && firstPrimary.side != currentSide) {
              currentSide = firstPrimary.side
              controller.setSide(firstPrimary.side)
            }
          },
          onClearExercise = { selectedExercise = null },
        )
      }
    } else {
      Column(modifier = Modifier.fillMaxSize()) {
        Box(
          modifier =
            Modifier
              .fillMaxWidth()
              .height(340.dp)
              .padding(horizontal = 16.dp),
        ) {
          AnatomyViewportCard(
            currentSide = currentSide,
            primaryMuscles = primaryMuscles,
            secondaryMuscles = secondaryMuscles,
            controller = controller,
            hasSelection = selectedMuscle != null || selectedExercise != null,
            onSideToggle = { side ->
              currentSide = side
              controller.setSide(side)
              onSideChanged(side)
              if (selectedExercise == null && selectedMuscle != null && selectedMuscle!!.side != side) {
                selectedMuscle = if (side == AnatomySide.FRONT) MuscleGroup.PECTORALS else MuscleGroup.LATS
              }
            },
            onMusclePicked = { picked ->
              selectedExercise = null
              selectedMuscle = picked
            },
            onClearSelection = {
              selectedMuscle = null
              selectedExercise = null
            },
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        AnatomyDetailsColumn(
          modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp),
          currentSide = currentSide,
          sideGroups = sideGroups,
          selectedMuscle = selectedMuscle,
          selectedExercise = selectedExercise,
          matchingExercises = matchingExercises,
          onSelectMuscle = { mg ->
            selectedExercise = null
            selectedMuscle = if (selectedMuscle == mg) null else mg
            if (mg.side != currentSide) {
              currentSide = mg.side
              controller.setSide(mg.side)
              onSideChanged(mg.side)
            }
          },
          onSelectExercise = { ex ->
            selectedExercise = if (selectedExercise?.id == ex.id) null else ex
            selectedMuscle = null
            val firstPrimary = MuscleGroup.parseCsv(ex.primaryMusclesCsv).firstOrNull()
            if (firstPrimary != null && firstPrimary.side != currentSide) {
              currentSide = firstPrimary.side
              controller.setSide(firstPrimary.side)
            }
          },
          onClearExercise = { selectedExercise = null },
        )
      }
    }
  }

  if (showAttributionDialog) {
    AlertDialog(
      onDismissRequest = { showAttributionDialog = false },
      containerColor = Graphite,
      titleContentColor = PureWhite,
      textContentColor = LightGray,
      title = { Text("3D-модель мышечной анатомии") },
      text = {
        Text(
          "Настоящая 3D-геометрия человеческого тела на движке Google Filament.\n\n" +
            "Источник анатомической сетки: BodyParts3D v3.0 (© DBCLS, лицензия CC BY-SA 2.1 Japan) в адаптации OrganUI (177 раздельных мышечных структур). " +
            "Коснись любой мышцы на модели, чтобы выделить её красным и увидеть функцию и безопасные упражнения для 14 лет.",
        )
      },
      confirmButton = {
        TextButton(onClick = { showAttributionDialog = false }) {
          Text("ПОНЯТНО", color = PureWhite)
        }
      },
    )
  }
}

@Composable
private fun AnatomyViewportCard(
  currentSide: AnatomySide,
  primaryMuscles: Set<MuscleGroup>,
  secondaryMuscles: Set<MuscleGroup>,
  controller: Anatomy3DController,
  hasSelection: Boolean,
  onSideToggle: (AnatomySide) -> Unit,
  onMusclePicked: (MuscleGroup?) -> Unit,
  onClearSelection: () -> Unit,
) {
  Surface(
    modifier = Modifier.fillMaxSize(),
    shape = RoundedCornerShape(18.dp),
    color = PureBlack,
    border = BorderStroke(1.dp, DarkGray),
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      Muscle3DView(
        primaryMuscles = primaryMuscles,
        secondaryMuscles = secondaryMuscles,
        preferredSide = currentSide,
        controller = controller,
        onMusclePicked = onMusclePicked,
        modifier = Modifier.fillMaxSize(),
      )

      // Top overlay: Front/Back switch + Clear selection
      Row(
        modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          AzxChip(
            text = "СПЕРЕДИ",
            selected = currentSide == AnatomySide.FRONT,
            onClick = { onSideToggle(AnatomySide.FRONT) },
            modifier = Modifier.testTag("anatomy_front_btn"),
          )
          AzxChip(
            text = "СЗАДИ",
            selected = currentSide == AnatomySide.BACK,
            onClick = { onSideToggle(AnatomySide.BACK) },
            modifier = Modifier.testTag("anatomy_back_side_btn"),
          )
        }

        if (hasSelection) {
          Surface(
            modifier =
              Modifier
                .minimumInteractiveComponentSize()
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onClearSelection)
                .testTag("anatomy_clear_btn"),
            color = AlmostBlack.copy(alpha = 0.9f),
            border = BorderStroke(1.dp, LightGray),
            shape = RoundedCornerShape(10.dp),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = "Снять выделение",
                tint = PureWhite,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text("Сброс", style = MaterialTheme.typography.labelMedium, color = PureWhite)
            }
          }
        }
      }

      // Bottom-left hint + legend
      Column(
        modifier =
          Modifier
            .align(Alignment.BottomStart)
            .padding(10.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(AlmostBlack.copy(alpha = 0.85f))
            .border(1.dp, DarkGray, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
      ) {
        Text(
          text = "Вращение: палец • Зум: щипок • Выбор: касание",
          style = MaterialTheme.typography.labelSmall,
          color = LightGray,
        )
        if (primaryMuscles.isNotEmpty()) {
          Spacer(modifier = Modifier.height(3.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier =
                Modifier
                  .size(8.dp)
                  .clip(RoundedCornerShape(2.dp))
                  .background(AnatomyModuleColors.SelectedMuscleRed),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = primaryMuscles.joinToString(", ") { it.titleRu },
              style = MaterialTheme.typography.labelSmall,
              color = PureWhite,
            )
          }
        }
      }

      // Bottom-right camera controls (+, -, flip, reset)
      Column(
        modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        AnatomyCamIconBtn(Icons.Rounded.ZoomIn, "Приблизить") { controller.zoomIn() }
        AnatomyCamIconBtn(Icons.Rounded.ZoomOut, "Отдалить") { controller.zoomOut() }
        AnatomyCamIconBtn(Icons.Rounded.SwapHoriz, "Развернуть") {
          val next = if (currentSide == AnatomySide.FRONT) AnatomySide.BACK else AnatomySide.FRONT
          onSideToggle(next)
        }
        AnatomyCamIconBtn(Icons.Rounded.Refresh, "Сброс камеры") { controller.resetCamera(currentSide) }
      }
    }
  }
}

@Composable
private fun AnatomyCamIconBtn(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  desc: String,
  onClick: () -> Unit,
) {
  Surface(
    modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick),
    color = AlmostBlack.copy(alpha = 0.88f),
    border = BorderStroke(1.dp, DarkGray),
    shape = RoundedCornerShape(10.dp),
  ) {
    Box(contentAlignment = Alignment.Center) {
      Icon(imageVector = icon, contentDescription = desc, tint = PureWhite, modifier = Modifier.size(18.dp))
    }
  }
}

@Composable
private fun AnatomyDetailsColumn(
  modifier: Modifier,
  currentSide: AnatomySide,
  sideGroups: List<MuscleGroup>,
  selectedMuscle: MuscleGroup?,
  selectedExercise: ExerciseEntity?,
  matchingExercises: List<ExerciseEntity>,
  onSelectMuscle: (MuscleGroup) -> Unit,
  onSelectExercise: (ExerciseEntity) -> Unit,
  onClearExercise: () -> Unit,
) {
  Column(modifier = modifier) {
    Text(
      text = "Группы мышц (${currentSide.titleRu.lowercase()})",
      style = MaterialTheme.typography.titleSmall,
      color = LightGray,
    )
    Spacer(modifier = Modifier.height(6.dp))
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      sideGroups.forEach { mg ->
        val active = selectedMuscle == mg
        AzxChip(
          text = mg.titleRu,
          selected = active,
          onClick = { onSelectMuscle(mg) },
        )
      }
    }
    Spacer(modifier = Modifier.height(10.dp))

    LazyColumn(
      modifier = Modifier.fillMaxWidth().weight(1f),
      contentPadding = PaddingValues(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {

    if (selectedMuscle != null) {
      item {
        AzxCard(containerColor = AlmostBlack) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = selectedMuscle.titleRu,
              style = MaterialTheme.typography.headlineSmall,
              color = PureWhite,
            )
            AzxBadge(text = selectedMuscle.side.titleRu.uppercase())
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = selectedMuscle.functionRu,
            style = MaterialTheme.typography.bodyMedium,
            color = LightGray,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Рекомендация (14 лет): ${selectedMuscle.safetyTip14Ru}",
            style = MaterialTheme.typography.bodySmall,
            color = MidGray,
          )
        }
      }
    }

    if (selectedExercise != null) {
      item {
        AzxCard(containerColor = AlmostBlack, borderColor = PureWhite) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "Режим упражнения",
              style = MaterialTheme.typography.labelMedium,
              color = LightGray,
            )
            TextButton(onClick = onClearExercise) {
              Text("Сбросить", color = PureWhite)
            }
          }
          Text(
            text = selectedExercise.nameRu,
            style = MaterialTheme.typography.titleLarge,
            color = PureWhite,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Основные мышцы (ярко-красный): " +
              MuscleGroup.parseCsv(selectedExercise.primaryMusclesCsv).joinToString { it.titleRu },
            style = MaterialTheme.typography.bodySmall,
            color = PureWhite,
          )
          val sec = MuscleGroup.parseCsv(selectedExercise.secondaryMusclesCsv)
          if (sec.isNotEmpty()) {
            Text(
              text = "Вспомогательные (тёмно-красный): ${sec.joinToString { it.titleRu }}",
              style = MaterialTheme.typography.bodySmall,
              color = LightGray,
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = selectedExercise.technique,
            style = MaterialTheme.typography.bodySmall,
            color = MidGray,
          )
        }
      }
    }

    item {
      Text(
        text =
          if (selectedMuscle != null) "Упражнения для: ${selectedMuscle.titleRu}"
          else "Нажми на упражнение, чтобы подсветить мышцы на 3D-модели",
        style = MaterialTheme.typography.titleSmall,
        color = PureWhite,
      )
    }

    items(matchingExercises, key = { it.id }) { ex ->
      val active = selectedExercise?.id == ex.id
      AzxCard(
        onClick = { onSelectExercise(ex) },
        borderColor = if (active) PureWhite else DarkGray,
        containerColor = if (active) AlmostBlack else Graphite,
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Rounded.FitnessCenter,
              contentDescription = null,
              tint = if (active) PureWhite else MidGray,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = ex.nameRu,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = PureWhite,
              )
              Text(
                text = MuscleGroup.parseCsv(ex.primaryMusclesCsv).joinToString(" • ") { it.titleRu },
                style = MaterialTheme.typography.bodySmall,
                color = MidGray,
              )
            }
          }
          AzxBadge(text = ex.category, filled = active)
        }
      }
    }
    }
  }
}
