package com.example.ui.anatomy

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View.OnLayoutChangeListener
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.domain.model.AnatomySide
import com.example.domain.model.MuscleGroup
import com.example.ui.theme.PureBlack
import com.google.android.filament.Colors
import com.google.android.filament.EntityManager
import com.google.android.filament.IndirectLight
import com.google.android.filament.LightManager
import com.google.android.filament.MaterialInstance
import com.google.android.filament.Skybox
import com.google.android.filament.View
import com.google.android.filament.utils.Float3
import com.google.android.filament.utils.Manipulator
import com.google.android.filament.utils.ModelViewer
import com.google.android.filament.utils.rotation
import com.google.android.filament.utils.scale
import com.google.android.filament.utils.translation
import com.google.android.filament.utils.transpose
import java.nio.ByteBuffer

class Anatomy3DController {
  internal var modelViewer: ModelViewer? = null
  internal var manipulator: Manipulator? = null
  internal var baseScaleFactor: Float = 1f
  internal var baseCenter: Float3 = Float3(0f, 0f, 0f)
  internal var currentYawDeg: Float = 0f

  fun setSide(side: AnatomySide) {
    currentYawDeg = if (side == AnatomySide.FRONT) 0f else 180f
    applyModelTransform()
    manipulator?.let { it.jumpToBookmark(it.homeBookmark) }
  }

  fun zoomIn() {
    manipulator?.scroll(0, 0, -2.5f)
  }

  fun zoomOut() {
    manipulator?.scroll(0, 0, 2.5f)
  }

  fun resetCamera(side: AnatomySide) {
    currentYawDeg = if (side == AnatomySide.FRONT) 0f else 180f
    applyModelTransform()
    manipulator?.let { it.jumpToBookmark(it.homeBookmark) }
  }

  internal fun applyModelTransform() {
    val mv = modelViewer ?: return
    val asset = mv.asset ?: return
    val tm = mv.engine.transformManager
    val targetCenter = Float3(0f, 0f, -4f)
    val rot = rotation(Float3(0f, 1f, 0f), currentYawDeg)
    val transform =
      translation(targetCenter) *
        rot *
        scale(Float3(baseScaleFactor)) *
        translation(-baseCenter)
    tm.setTransform(tm.getInstance(asset.root), transpose(transform).toFloatArray())
  }
}

@SuppressLint("ClickableViewAccessibility")
@Composable
fun Muscle3DView(
  primaryMuscles: Set<MuscleGroup>,
  secondaryMuscles: Set<MuscleGroup>,
  preferredSide: AnatomySide,
  controller: Anatomy3DController,
  onMusclePicked: (MuscleGroup?) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val currentOnMusclePicked by rememberUpdatedState(onMusclePicked)
  val currentPreferredSide by rememberUpdatedState(preferredSide)
  var viewerReady by remember { mutableStateOf(false) }

  // Pre-build monochrome vs red highlight node sets
  val primaryNodes = remember(primaryMuscles) { primaryMuscles.flatMap { it.glbNodes }.toSet() }
  val secondaryNodes =
    remember(secondaryMuscles, primaryNodes) {
      secondaryMuscles.flatMap { it.glbNodes }.toSet() - primaryNodes
    }

  val surfaceView = remember {
    SurfaceView(context).apply {
      setZOrderMediaOverlay(false)
    }
  }

  DisposableEffect(surfaceView) {
    val mainHandler = Handler(Looper.getMainLooper())
    val manipulator =
      Manipulator.Builder()
        .targetPosition(0f, 0f, -4f)
        .orbitHomePosition(0f, 0.04f, -0.55f)
        .orbitSpeed(0.008f, 0.008f)
        .zoomSpeed(0.08f)
        .viewport(surfaceView.width.coerceAtLeast(1), surfaceView.height.coerceAtLeast(1))
        .build(Manipulator.Mode.ORBIT)

    val layoutListener =
      OnLayoutChangeListener { _, left, top, right, bottom, _, _, _, _ ->
        val w = (right - left).coerceAtLeast(1)
        val h = (bottom - top).coerceAtLeast(1)
        manipulator.setViewport(w, h)
      }
    surfaceView.addOnLayoutChangeListener(layoutListener)

    val mv = ModelViewer(surfaceView, manipulator = manipulator)
    controller.modelViewer = mv
    controller.manipulator = manipulator

    // Strict pure black #000000 backdrop
    mv.scene.skybox = Skybox.Builder().color(0f, 0f, 0f, 1f).build(mv.engine)
    mv.renderer.clearOptions =
      mv.renderer.clearOptions.apply {
        clear = true
        clearColor = floatArrayOf(0f, 0f, 0f, 1f)
      }

    // Quality studio lighting for sculptural white/gray muscles & clear red contrast
    mv.view.isPostProcessingEnabled = true
    mv.view.antiAliasing = View.AntiAliasing.FXAA
    mv.scene.indirectLight =
      IndirectLight.Builder()
        .irradiance(
          2,
          floatArrayOf(
            0.85f, 0.85f, 0.85f,
            0.16f, 0.16f, 0.16f,
            0.20f, 0.20f, 0.20f,
            0.07f, 0.07f, 0.07f,
          ),
        )
        .intensity(24_000f)
        .build(mv.engine)

    val fillLight = EntityManager.get().create()
    LightManager.Builder(LightManager.Type.DIRECTIONAL)
      .color(1.0f, 1.0f, 1.0f)
      .intensity(52_000f)
      .direction(-0.5f, -0.3f, -0.8f)
      .castShadows(false)
      .build(mv.engine, fillLight)
    mv.scene.addEntity(fillLight)

    val rimLight = EntityManager.get().create()
    LightManager.Builder(LightManager.Type.DIRECTIONAL)
      .color(0.92f, 0.92f, 0.92f)
      .intensity(42_000f)
      .direction(0.55f, 0.3f, 0.78f)
      .castShadows(false)
      .build(mv.engine, rimLight)
    mv.scene.addEntity(rimLight)

    // Load real 177-muscle GLB from assets
    runCatching {
      context.assets.open("models/muscles.glb").use { stream ->
        val bytes = stream.readBytes()
        mv.loadModelGlb(ByteBuffer.wrap(bytes))
        mv.asset?.let { asset ->
          val centerArr = asset.boundingBox.center
          val halfArr = asset.boundingBox.halfExtent
          controller.baseCenter = Float3(centerArr[0], centerArr[1], centerArr[2])
          val maxExtent = 2.0f * maxOf(halfArr[0], halfArr[1], halfArr[2])
          controller.baseScaleFactor = if (maxExtent > 0f) 2.15f / maxExtent else 1f
          controller.currentYawDeg =
            if (currentPreferredSide == AnatomySide.FRONT) 0f else 180f
          controller.applyModelTransform()
          manipulator.jumpToBookmark(manipulator.homeBookmark)
        }
        viewerReady = true
      }
    }

    val tapDetector =
      GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
          override fun onSingleTapUp(e: MotionEvent): Boolean {
            val w = surfaceView.width
            val h = surfaceView.height
            if (w <= 0 || h <= 0) return false
            val px = e.x.toInt().coerceIn(0, w - 1)
            val py = (h - 1 - e.y.toInt()).coerceIn(0, h - 1)
            mv.view.pick(px, py, mainHandler) { result ->
              val entity = result.renderable
              val asset = mv.asset ?: return@pick
              if (entity == 0) return@pick

              var cur = entity
              var nodeName = asset.getName(cur)
              val tm = mv.engine.transformManager
              var depth = 0
              while (nodeName.isNullOrBlank() && depth < 4) {
                val inst = tm.getInstance(cur)
                if (inst == 0) break
                val parent = tm.getParent(inst)
                if (parent == 0) break
                cur = parent
                nodeName = asset.getName(cur)
                depth++
              }
              val matched =
                if (!nodeName.isNullOrBlank()) {
                  MuscleGroup.fromNodeName(nodeName, currentPreferredSide)
                } else {
                  null
                }
              if (matched != null) {
                currentOnMusclePicked(matched)
              }
            }
            return true
          }
        },
      )

    surfaceView.setOnTouchListener { _, event ->
      tapDetector.onTouchEvent(event)
      mv.onTouchEvent(event)
      true
    }

    val choreographer = Choreographer.getInstance()
    var running = true
    val frameCallback =
      object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
          if (!running) return
          choreographer.postFrameCallback(this)
          mv.render(frameTimeNanos)
        }
      }
    choreographer.postFrameCallback(frameCallback)

    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_RESUME -> {
          running = true
          choreographer.postFrameCallback(frameCallback)
        }
        Lifecycle.Event.ON_PAUSE -> {
          running = false
          choreographer.removeFrameCallback(frameCallback)
        }
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)

    onDispose {
      running = false
      choreographer.removeFrameCallback(frameCallback)
      lifecycleOwner.lifecycle.removeObserver(observer)
      surfaceView.removeOnLayoutChangeListener(layoutListener)
      mv.scene.removeEntity(fillLight)
      mv.scene.removeEntity(rimLight)
      EntityManager.get().destroy(fillLight)
      EntityManager.get().destroy(rimLight)
      controller.modelViewer = null
      controller.manipulator = null
    }
  }

  // Update PBR material colors via both RenderableManager node mapping and MaterialInstance names
  LaunchedEffect(viewerReady, primaryNodes, secondaryNodes) {
    val mv = controller.modelViewer ?: return@LaunchedEffect
    val asset = mv.asset ?: return@LaunchedEffect
    val rm = mv.engine.renderableManager

    // 1. Direct entity-to-MaterialInstance pass keyed by GLB node name (guaranteed accurate)
    val visitedInstances = HashSet<MaterialInstance>()
    asset.entities.forEach { entity ->
      val nodeName = asset.getName(entity) ?: return@forEach
      val ri = rm.getInstance(entity)
      if (ri != 0) {
        val count = rm.getPrimitiveCount(ri)
        for (p in 0 until count) {
          val mi = rm.getMaterialInstanceAt(ri, p)
          visitedInstances.add(mi)
          applyMuscleMaterialStyle(mi, nodeName, primaryNodes, secondaryNodes)
        }
      }
    }

    // 2. Fallback pass for any unvisited material instances keyed by MaterialInstance.name
    asset.instance.materialInstances.forEach { mi ->
      if (mi !in visitedInstances) {
        val matName = mi.name.orEmpty()
        applyMuscleMaterialStyle(mi, matName, primaryNodes, secondaryNodes)
      }
    }
  }

  Box(modifier = modifier.background(PureBlack)) {
    AndroidView(
      factory = { surfaceView },
      modifier = Modifier.fillMaxSize(),
    )
  }
}

private val tendKeywords = arrayOf("aponeurosis", "tendon", "linea-alba")
private val deepKeywords =
  arrayOf(
    "intercostals",
    "multifidus",
    "rotatores",
    "interspinales",
    "intertransversarii",
    "diaphragm",
    "obturator",
    "gemellus",
    "piriformis",
    "quadratus",
    "subclavius",
    "iliacus",
    "psoas",
  )

private fun applyMuscleMaterialStyle(
  mi: MaterialInstance,
  keyName: String,
  primaryNodes: Set<String>,
  secondaryNodes: Set<String>,
) {
  when {
    keyName in primaryNodes -> {
      mi.setParameter("baseColorFactor", Colors.RgbaType.SRGB, 0.92f, 0.05f, 0.09f, 1.0f)
      runCatching { mi.setParameter("emissiveFactor", 0.28f, 0.01f, 0.02f) }
    }
    keyName in secondaryNodes -> {
      mi.setParameter("baseColorFactor", Colors.RgbaType.SRGB, 0.62f, 0.10f, 0.13f, 1.0f)
      runCatching { mi.setParameter("emissiveFactor", 0.10f, 0.01f, 0.01f) }
    }
    tendKeywords.any { keyName.contains(it) } -> {
      mi.setParameter("baseColorFactor", Colors.RgbaType.SRGB, 0.93f, 0.93f, 0.93f, 1.0f)
      runCatching { mi.setParameter("emissiveFactor", 0f, 0f, 0f) }
    }
    deepKeywords.any { keyName.contains(it) } -> {
      mi.setParameter("baseColorFactor", Colors.RgbaType.SRGB, 0.64f, 0.64f, 0.64f, 1.0f)
      runCatching { mi.setParameter("emissiveFactor", 0f, 0f, 0f) }
    }
    else -> {
      mi.setParameter("baseColorFactor", Colors.RgbaType.SRGB, 0.85f, 0.85f, 0.85f, 1.0f)
      runCatching { mi.setParameter("emissiveFactor", 0f, 0f, 0f) }
    }
  }
}
