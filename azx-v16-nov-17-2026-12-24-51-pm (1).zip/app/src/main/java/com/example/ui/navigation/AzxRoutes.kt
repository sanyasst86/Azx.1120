package com.example.ui.navigation

import kotlinx.serialization.Serializable

sealed interface AzxRoute {
  @Serializable data object Dashboard : AzxRoute
  @Serializable data object Plans : AzxRoute
  @Serializable data object Goals : AzxRoute
  @Serializable data object Progress : AzxRoute
  @Serializable data object Profile : AzxRoute

  @Serializable data class DirectionDetail(val directionCode: String) : AzxRoute
  @Serializable data object BodyModule : AzxRoute
  @Serializable data class Anatomy3D(val exerciseId: Long = -1L) : AzxRoute
  @Serializable data object BasketballModule : AzxRoute
  @Serializable data object MindModule : AzxRoute
  @Serializable data object DisciplineModule : AzxRoute
  @Serializable data object StyleModule : AzxRoute
  @Serializable data object ProjectsModule : AzxRoute
  @Serializable data object LifeSkillsModule : AzxRoute
  @Serializable data object CoachModule : AzxRoute
  @Serializable data object GameModule : AzxRoute
}
