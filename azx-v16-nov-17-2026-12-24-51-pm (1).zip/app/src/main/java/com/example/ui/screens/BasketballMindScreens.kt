package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SportsBasketball
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.repository.AzxRepository
import com.example.domain.model.Direction
import com.example.ui.AzxUiState
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxChip
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxProgressBar
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.AzxSectionHeader
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import kotlinx.coroutines.delay

private data class BasketballDrill(
  val title: String,
  val skill: String,
  val instruction: String,
  val durationMin: Int,
  val musclesCsv: String,
)

private val basketballDrills =
  listOf(
    BasketballDrill(
      title = "Низкий дриблинг и перевод под коленом",
      skill = "Ведение и контроль мяча",
      instruction = "2 минуты правой рукой, 2 минуты левой, затем 3×30с быстрый кроссовер. Взгляд вперёд, мяч не выше колена.",
      durationMin = 12,
      musclesCsv = "forearms,quadriceps,calves",
    ),
    BasketballDrill(
      title = "Броски с близкой дистанции (Form Shooting)",
      skill = "Броски",
      instruction = "20 попаданий одной рукой с 1.5 м, затем 20 с 3 м после остановки. Фиксируй кисть после выпуска мяча.",
      durationMin = 15,
      musclesCsv = "triceps,anterior_delts,forearms",
    ),
    BasketballDrill(
      title = "Защитное скольжение и реакция на сигнал",
      skill = "Координация, реакция, работа ног",
      instruction = "4 подхода по 30 сек в низкой стойке: перемещение приставными шагами вправо-влево, смена направления по хлопку/сигналу.",
      durationMin = 10,
      musclesCsv = "quadriceps,glutes,hamstrings,calves",
    ),
    BasketballDrill(
      title = "Баланс при остановке и прыжковая подготовка",
      skill = "Баланс и прыжок",
      instruction = "Остановка прыжком (jump stop) с удержанием равновесия 2 сек + 4×6 мягких выпрыгиваний вверх. Бесшумное приземление на носки.",
      durationMin = 12,
      musclesCsv = "quadriceps,glutes,calves",
    ),
    BasketballDrill(
      title = "Тренировка на площадке: проход + завершение",
      skill = "Площадка и завершение",
      instruction = "10 проходов справа, 10 слева с завершением от щита с двух шагов (лей-ап), затем 10 штрафных бросков.",
      durationMin = 20,
      musclesCsv = "quadriceps,calves,triceps,forearms",
    ),
  )

@Composable
fun BasketballScreen(
  state: AzxUiState,
  onLogBasketballSession: (title: String, minutes: Int, musclesCsv: String, notes: String) -> Unit,
  onOpenAnatomy: () -> Unit,
  onBack: () -> Unit,
) {
  var selectedSkillFilter by remember { mutableStateOf("Все") }
  var sessionMinutes by remember { mutableIntStateOf(20) }
  var sessionNote by remember { mutableStateOf("") }

  val ballHistory =
    remember(state.workoutHistory) {
      state.workoutHistory.filter { it.category == "BASKETBALL" }
    }
  val skills = listOf("Все", "Ведение", "Броски", "Реакция", "Баланс", "Площадка")

  val filteredDrills =
    remember(selectedSkillFilter) {
      if (selectedSkillFilter == "Все") basketballDrills
      else basketballDrills.filter { it.skill.contains(selectedSkillFilter, ignoreCase = true) }
    }

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = PureWhite)
        }
        Column {
          Text("BASKETBALL", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
          Text("Ведение • Броски • Реакция • Ноги • Площадка", style = MaterialTheme.typography.bodySmall, color = MidGray)
        }
      }
      AzxSecondaryButton(text = "3D-мышцы", onClick = onOpenAnatomy)
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        val progress = (ballHistory.size / 10f).coerceIn(0f, 1f)
        AzxCard(containerColor = AlmostBlack) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column {
              Text("Прогресс баскетбольных навыков", style = MaterialTheme.typography.titleMedium, color = PureWhite)
              Text(
                "Тренировок на площадке/с мячом: ${ballHistory.size} • Минут: ${ballHistory.sumOf { it.durationMinutes }}",
                style = MaterialTheme.typography.bodySmall,
                color = MidGray,
              )
            }
            AzxBadge(text = "${(progress * 100).toInt()}%", filled = true)
          }
          Spacer(modifier = Modifier.height(8.dp))
          AzxProgressBar(progress = progress)
        }
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          skills.forEach { s ->
            AzxChip(text = s, selected = selectedSkillFilter == s, onClick = { selectedSkillFilter = s })
          }
        }
      }

      items(filteredDrills) { drill ->
        AzxCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            AzxBadge(text = drill.skill)
            AzxBadge(text = "${drill.durationMin} мин")
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(drill.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
          Spacer(modifier = Modifier.height(4.dp))
          Text(drill.instruction, style = MaterialTheme.typography.bodySmall, color = LightGray)
          Spacer(modifier = Modifier.height(10.dp))
          AzxPrimaryButton(
            text = "Засчитать тренировку (+65 XP)",
            icon = Icons.Rounded.Check,
            onClick = {
              onLogBasketballSession(drill.title, drill.durationMin, drill.musclesCsv, sessionNote)
              sessionNote = ""
            },
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }

      item {
        AzxCard(containerColor = AlmostBlack) {
          Text("Своя тренировка на площадке", style = MaterialTheme.typography.titleMedium, color = PureWhite)
          Spacer(modifier = Modifier.height(6.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(15, 30, 45, 60).forEach { m ->
              AzxChip(text = "$m мин", selected = sessionMinutes == m, onClick = { sessionMinutes = m })
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = sessionNote,
            onValueChange = { sessionNote = it },
            label = { Text("Что отрабатывал (процент бросков, слабая рука)") },
            colors = azxTextFieldColors(),
            modifier = Modifier.fillMaxWidth(),
          )
          Spacer(modifier = Modifier.height(8.dp))
          AzxSecondaryButton(
            text = "Записать занятие на площадке",
            icon = Icons.Rounded.SportsBasketball,
            onClick = {
              onLogBasketballSession(
                "Тренировка на площадке ($sessionMinutes мин)",
                sessionMinutes,
                "quadriceps,calves,forearms,triceps",
                sessionNote,
              )
              sessionNote = ""
            },
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }

      if (ballHistory.isNotEmpty()) {
        item {
          AzxSectionHeader(title = "История баскетбола (${ballHistory.size})")
        }
        items(ballHistory, key = { it.id }) { h ->
          AzxCard {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(h.workoutTitle, style = MaterialTheme.typography.titleSmall, color = PureWhite)
                Text(
                  "${h.durationMinutes} мин • ${AzxRepository.formatDateShort(h.completedAt)}" +
                    if (h.notes.isNotBlank()) " • ${h.notes}" else "",
                  style = MaterialTheme.typography.bodySmall,
                  color = MidGray,
                )
              }
              AzxBadge(text = "+${h.xpAwarded} XP")
            }
          }
        }
      }
    }
  }
}

@Composable
fun MindScreen(
  state: AzxUiState,
  onLogMindSession: (title: String, minutes: Int) -> Unit,
  onSaveTask: (TaskEntity) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onSaveGoal: (GoalEntity, List<String>) -> Unit,
  onBack: () -> Unit,
) {
  var sessionTitle by remember { mutableStateOf("Чтение / Языки / Учёба") }
  var focusMinutes by remember { mutableIntStateOf(25) }
  var secondsLeft by remember { mutableIntStateOf(25 * 60) }
  var timerRunning by remember { mutableStateOf(false) }

  var showAddTask by remember { mutableStateOf(false) }
  var showAddGoal by remember { mutableStateOf(false) }
  var bookTitle by remember { mutableStateOf("") }
  var noteText by remember { mutableStateOf("") }

  LaunchedEffect(timerRunning, secondsLeft) {
    if (timerRunning && secondsLeft > 0) {
      delay(1000)
      secondsLeft--
      if (secondsLeft == 0) {
        timerRunning = false
        onLogMindSession(sessionTitle.ifBlank { "Концентрация" }, focusMinutes)
      }
    }
  }

  val mindTasks = remember(state.tasks) { state.tasks.filter { it.direction == "MIND" } }
  val mindGoals = remember(state.goals) { state.goals.filter { it.direction == "MIND" } }

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = PureWhite)
      }
      Column {
        Text("MIND — ИНТЕЛЛЕКТ И УЧЁБА", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
        Text("Книги • Языки • Заметки • Таймер концентрации", style = MaterialTheme.typography.bodySmall, color = MidGray)
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Focus Timer Card
      item {
        AzxCard(containerColor = AlmostBlack) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Timer, contentDescription = null, tint = PureWhite)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Таймер занятий и концентрации", style = MaterialTheme.typography.titleMedium, color = PureWhite)
          }
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = sessionTitle,
            onValueChange = { sessionTitle = it },
            label = { Text("Предмет / Книга / Язык") },
            singleLine = true,
            colors = azxTextFieldColors(),
            modifier = Modifier.fillMaxWidth(),
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(15, 25, 45).forEach { m ->
              AzxChip(
                text = "$m мин",
                selected = focusMinutes == m,
                onClick = {
                  if (!timerRunning) {
                    focusMinutes = m
                    secondsLeft = m * 60
                  }
                },
              )
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "%02d:%02d".format(secondsLeft / 60, secondsLeft % 60),
            style = MaterialTheme.typography.displayLarge,
            color = PureWhite,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AzxPrimaryButton(
              text = if (timerRunning) "Пауза" else "Старт",
              icon = if (timerRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
              onClick = { timerRunning = !timerRunning },
              modifier = Modifier.weight(1f),
            )
            AzxSecondaryButton(
              text = "Засчитать",
              icon = Icons.Rounded.Check,
              onClick = {
                timerRunning = false
                onLogMindSession(sessionTitle.ifBlank { "Занятие MIND" }, focusMinutes)
                secondsLeft = focusMinutes * 60
              },
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // Quick Book / Language / Note entry
      item {
        AzxCard {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Book, contentDescription = null, tint = PureWhite)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Книги, языки и заметки", style = MaterialTheme.typography.titleMedium, color = PureWhite)
          }
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = bookTitle,
            onValueChange = { bookTitle = it },
            label = { Text("Книга / Тема по языку или учёбе") },
            singleLine = true,
            colors = azxTextFieldColors(),
            modifier = Modifier.fillMaxWidth(),
          )
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = noteText,
            onValueChange = { noteText = it },
            label = { Text("Конспект / новая лексика / вывод") },
            colors = azxTextFieldColors(),
            modifier = Modifier.fillMaxWidth(),
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AzxPrimaryButton(
              text = "Добавить в список MIND",
              enabled = bookTitle.isNotBlank(),
              onClick = {
                onSaveTask(
                  TaskEntity(
                    title = bookTitle.trim(),
                    description = noteText.trim(),
                    direction = "MIND",
                    dateEpochDay = state.todayEpoch,
                  ),
                )
                bookTitle = ""
                noteText = ""
              },
              modifier = Modifier.weight(1f),
            )
            AzxSecondaryButton(
              text = "+ Цель",
              icon = Icons.Rounded.Add,
              onClick = { showAddGoal = true },
            )
          }
        }
      }

      item {
        AzxSectionHeader(
          title = "Учебные цели (${mindGoals.size})",
          actionLabel = "+ Задача",
          onAction = { showAddTask = true },
        )
      }
      items(mindGoals, key = { it.id }) { g ->
        AzxCard {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(g.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
            AzxBadge(text = "${g.progressPercent}%")
          }
          Spacer(modifier = Modifier.height(6.dp))
          AzxProgressBar(progress = g.progressPercent / 100f)
        }
      }

      item {
        AzxSectionHeader(title = "Задачи и история MIND (${mindTasks.size})")
      }
      items(mindTasks, key = { it.id }) { t ->
        AzxCard(onClick = { onToggleTask(t) }) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
              checked = t.status == "DONE",
              onCheckedChange = { onToggleTask(t) },
              colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(t.title, style = MaterialTheme.typography.titleSmall, color = PureWhite)
              if (t.description.isNotBlank()) {
                Text(t.description, style = MaterialTheme.typography.bodySmall, color = LightGray)
              }
            }
            AzxBadge(text = if (t.status == "DONE") "ГОТОВО" else "АКТИВ")
          }
        }
      }
    }
  }

  if (showAddTask) {
    TaskEditorDialog(
      defaultDirection = Direction.MIND,
      goals = state.goals,
      onDismiss = { showAddTask = false },
      onSave = onSaveTask,
    )
  }
  if (showAddGoal) {
    GoalEditorDialog(
      defaultDirection = Direction.MIND,
      onDismiss = { showAddGoal = false },
      onSave = onSaveGoal,
    )
  }
}
