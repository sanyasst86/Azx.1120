package com.example.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.ExerciseEntity
import com.example.data.local.entity.WorkoutEntity
import com.example.data.repository.AzxRepository
import com.example.domain.model.MuscleGroup
import com.example.ui.AzxUiState
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxChip
import com.example.ui.theme.AzxEmptyState
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import kotlinx.coroutines.delay

private enum class BodyTab(val label: String) {
  WORKOUTS("Программы"),
  EXERCISES("Каталог упражнений"),
  HISTORY("История и статистика"),
}

private val bodyCategories =
  listOf(
    "ALL" to "Все",
    "HOME" to "Дом",
    "GYM" to "Зал",
    "AFK" to "АФК",
    "LFK" to "ЛФК",
    "BASKETBALL" to "Баскетбол",
    "RECOVERY" to "Восстановление",
    "MOBILITY" to "Мобильность",
  )

@Composable
fun BodyScreen(
  state: AzxUiState,
  onOpenAnatomy: (Long?) -> Unit,
  onSaveWorkout: (WorkoutEntity) -> Unit,
  onDeleteWorkout: (WorkoutEntity) -> Unit,
  onCompleteWorkout: (Long, String, String, Int, Int, String, String) -> Unit,
  onBack: () -> Unit,
) {
  var tab by remember { mutableStateOf(BodyTab.WORKOUTS) }
  var selectedCategory by remember { mutableStateOf("ALL") }
  var searchQuery by remember { mutableStateOf("") }
  var showBuilderDialog by remember { mutableStateOf(false) }
  var activeWorkout by remember { mutableStateOf<WorkoutEntity?>(null) }
  var selectedExerciseDetail by remember { mutableStateOf<ExerciseEntity?>(null) }

  BackHandler(enabled = activeWorkout != null) {
    activeWorkout = null
  }

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = PureWhite)
        }
        Column {
          Text("BODY — СПОРТ И АНАТОМИЯ", style = MaterialTheme.typography.titleLarge, color = PureWhite)
          Text("Безопасные программы для 14 лет • Без перегрузок", style = MaterialTheme.typography.bodySmall, color = MidGray)
        }
      }
      AzxPrimaryButton(
        text = "3D-Тело",
        icon = Icons.Rounded.AccessibilityNew,
        onClick = { onOpenAnatomy(null) },
        modifier = Modifier.testTag("body_open_3d_btn"),
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      BodyTab.entries.forEach { t ->
        AzxChip(text = t.label, selected = tab == t, onClick = { tab = t })
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Active Workout Player Mode
    if (activeWorkout != null) {
      ActiveWorkoutPlayer(
        workout = activeWorkout!!,
        exercises = state.exercises,
        soundEnabled = state.settings.workoutSoundEnabled,
        onFinish = { setsCompleted, minutes, notes ->
          onCompleteWorkout(
            activeWorkout!!.id,
            activeWorkout!!.title,
            activeWorkout!!.category,
            minutes,
            setsCompleted,
            activeWorkout!!.targetMusclesCsv,
            notes,
          )
          activeWorkout = null
          tab = BodyTab.HISTORY
        },
        onCancel = { activeWorkout = null },
      )
      return@Column
    }

    when (tab) {
      BodyTab.WORKOUTS -> {
        val filteredWorkouts =
          remember(state.workouts, selectedCategory) {
            state.workouts.filter { selectedCategory == "ALL" || it.category == selectedCategory }
          }
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(
                modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                bodyCategories.forEach { (code, lbl) ->
                  AzxChip(text = lbl, selected = selectedCategory == code, onClick = { selectedCategory = code })
                }
              }
              Spacer(modifier = Modifier.width(8.dp))
              AzxSecondaryButton(
                text = "+ Свой",
                icon = Icons.Rounded.Add,
                onClick = { showBuilderDialog = true },
              )
            }
          }

          items(filteredWorkouts, key = { it.id }) { workout ->
            AzxCard {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    AzxBadge(text = workout.category)
                    Spacer(modifier = Modifier.width(6.dp))
                    AzxBadge(text = "${workout.estimatedMinutes} мин")
                    if (workout.isCustom) {
                      Spacer(modifier = Modifier.width(6.dp))
                      AzxBadge(text = "МОЙ")
                    }
                  }
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(workout.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                  Text(workout.description, style = MaterialTheme.typography.bodySmall, color = MidGray)
                  val muscles = MuscleGroup.parseCsv(workout.targetMusclesCsv)
                  if (muscles.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      "Мышцы: ${muscles.joinToString { it.titleRu }}",
                      style = MaterialTheme.typography.labelSmall,
                      color = LightGray,
                    )
                  }
                }
              }
              Spacer(modifier = Modifier.height(10.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                AzxPrimaryButton(
                  text = "Начать тренировку",
                  icon = Icons.Rounded.PlayArrow,
                  onClick = { activeWorkout = workout },
                  modifier = Modifier.weight(1f),
                )
                if (workout.isCustom) {
                  IconButton(onClick = { onDeleteWorkout(workout) }) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Удалить комплекс", tint = MidGray)
                  }
                }
              }
            }
          }
        }
      }

      BodyTab.EXERCISES -> {
        val filteredEx =
          remember(state.exercises, selectedCategory, searchQuery) {
            state.exercises.filter { ex ->
              (selectedCategory == "ALL" || ex.category == selectedCategory) &&
                (searchQuery.isBlank() ||
                  ex.nameRu.contains(searchQuery, ignoreCase = true) ||
                  ex.description.contains(searchQuery, ignoreCase = true))
            }
          }
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          item {
            OutlinedTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              label = { Text("Поиск упражнения") },
              singleLine = true,
              colors = azxTextFieldColors(),
              modifier = Modifier.fillMaxWidth(),
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              bodyCategories.forEach { (code, lbl) ->
                AzxChip(text = lbl, selected = selectedCategory == code, onClick = { selectedCategory = code })
              }
            }
          }

          items(filteredEx, key = { it.id }) { ex ->
            AzxCard(onClick = { selectedExerciseDetail = ex }) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(ex.nameRu, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                  Text(
                    "${ex.defaultSets} подх. × " +
                      (if (ex.defaultDurationSec > 0) "${ex.defaultDurationSec} сек" else "${ex.defaultReps} повт.") +
                      " • Отдых ${ex.restSec}с",
                    style = MaterialTheme.typography.labelSmall,
                    color = LightGray,
                  )
                  Text(
                    MuscleGroup.parseCsv(ex.primaryMusclesCsv).joinToString(" • ") { it.titleRu },
                    style = MaterialTheme.typography.bodySmall,
                    color = MidGray,
                  )
                }
                AzxBadge(text = ex.category)
              }
            }
          }
        }
      }

      BodyTab.HISTORY -> {
        val totalMin = state.workoutHistory.sumOf { it.durationMinutes }
        val totalSets = state.workoutHistory.sumOf { it.totalSetsCompleted }
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          item {
            AzxCard(containerColor = AlmostBlack) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column {
                  Text("Тренировок", style = MaterialTheme.typography.labelSmall, color = MidGray)
                  Text("${state.workoutHistory.size}", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
                }
                Column {
                  Text("Время", style = MaterialTheme.typography.labelSmall, color = MidGray)
                  Text("$totalMin мин", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
                }
                Column {
                  Text("Подходов", style = MaterialTheme.typography.labelSmall, color = MidGray)
                  Text("$totalSets", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
                }
              }
            }
          }
          if (state.workoutHistory.isEmpty()) {
            item {
              AzxEmptyState(
                icon = Icons.Rounded.FitnessCenter,
                title = "История тренировок пуста",
                description = "Запусти и заверши любую программу — данные сохранятся в Room.",
                actionLabel = "К программам",
                onAction = { tab = BodyTab.WORKOUTS },
              )
            }
          } else {
            items(state.workoutHistory, key = { it.id }) { item ->
              AzxCard {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(item.workoutTitle, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                    Text(
                      "${item.category} • ${item.durationMinutes} мин • ${item.totalSetsCompleted} подх. • ${AzxRepository.formatDateShort(item.completedAt)}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MidGray,
                    )
                  }
                  AzxBadge(text = "+${item.xpAwarded} XP", filled = true)
                }
              }
            }
          }
        }
      }
    }
  }

  if (selectedExerciseDetail != null) {
    val ex = selectedExerciseDetail!!
    AlertDialog(
      onDismissRequest = { selectedExerciseDetail = null },
      containerColor = AlmostBlack,
      titleContentColor = PureWhite,
      textContentColor = LightGray,
      title = { Text(ex.nameRu) },
      text = {
        Column(
          modifier = Modifier.verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(ex.description, style = MaterialTheme.typography.bodyMedium, color = PureWhite)
          Text("Техника выполнения:", style = MaterialTheme.typography.labelMedium, color = PureWhite)
          Text(ex.technique, style = MaterialTheme.typography.bodySmall, color = LightGray)
          Text("Безопасность (14 лет):", style = MaterialTheme.typography.labelMedium, color = PureWhite)
          Text(ex.safetyNotes, style = MaterialTheme.typography.bodySmall, color = MidGray)
          Text(
            "Основные мышцы: ${MuscleGroup.parseCsv(ex.primaryMusclesCsv).joinToString { it.titleRu }}",
            style = MaterialTheme.typography.bodySmall,
            color = PureWhite,
          )
        }
      },
      confirmButton = {
        TextButton(
          onClick = {
            selectedExerciseDetail = null
            onOpenAnatomy(ex.id)
          },
        ) {
          Text("ПОКАЗАТЬ В 3D", color = PureWhite)
        }
      },
      dismissButton = {
        TextButton(onClick = { selectedExerciseDetail = null }) {
          Text("ЗАКРЫТЬ", color = LightGray)
        }
      },
    )
  }

  if (showBuilderDialog) {
    WorkoutBuilderDialog(
      exercises = state.exercises,
      onDismiss = { showBuilderDialog = false },
      onSave = onSaveWorkout,
    )
  }
}

@Composable
private fun ActiveWorkoutPlayer(
  workout: WorkoutEntity,
  exercises: List<ExerciseEntity>,
  soundEnabled: Boolean,
  onFinish: (setsCompleted: Int, minutes: Int, notes: String) -> Unit,
  onCancel: () -> Unit,
) {
  val workoutExercises =
    remember(workout, exercises) {
      val ids = workout.exerciseIdsCsv.split(",").mapNotNull { it.trim().toLongOrNull() }
      ids.mapNotNull { id -> exercises.find { it.id == id } }
    }
  var totalSetsDone by remember { mutableIntStateOf(0) }
  var elapsedSeconds by remember { mutableIntStateOf(0) }
  var restSecondsLeft by remember { mutableIntStateOf(0) }
  var restRunning by remember { mutableStateOf(false) }
  var notes by remember { mutableStateOf("") }
  val completedSetKeys = remember { mutableStateListOf<String>() }

  LaunchedEffect(Unit) {
    while (true) {
      delay(1000)
      elapsedSeconds++
    }
  }

  val toneGenerator = remember {
    runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80) }.getOrNull()
  }
  DisposableEffect(Unit) {
    onDispose {
      runCatching { toneGenerator?.release() }
    }
  }

  LaunchedEffect(restRunning, restSecondsLeft) {
    if (restRunning && restSecondsLeft > 0) {
      delay(1000)
      restSecondsLeft--
      if (restSecondsLeft == 0) {
        restRunning = false
        if (soundEnabled) {
          runCatching {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 350)
          }
        }
      }
    }
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      AzxCard(containerColor = AlmostBlack, borderColor = PureWhite) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(workout.title, style = MaterialTheme.typography.titleLarge, color = PureWhite)
            Text(
              "Время: %02d:%02d • Выполнено подходов: $totalSetsDone".format(
                elapsedSeconds / 60,
                elapsedSeconds % 60,
              ),
              style = MaterialTheme.typography.labelMedium,
              color = LightGray,
            )
          }
          AzxBadge(text = workout.category, filled = true)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Timer, contentDescription = null, tint = PureWhite)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (restRunning) "Отдых: ${restSecondsLeft}с" else "Таймер отдыха готов",
              style = MaterialTheme.typography.titleSmall,
              color = PureWhite,
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AzxChip(
              text = "45с",
              selected = restRunning && restSecondsLeft <= 45,
              onClick = {
                restSecondsLeft = 45
                restRunning = true
              },
            )
            AzxChip(
              text = "60с",
              selected = restRunning && restSecondsLeft > 45,
              onClick = {
                restSecondsLeft = 60
                restRunning = true
              },
            )
          }
        }
      }
    }

    items(workoutExercises, key = { it.id }) { ex ->
      AzxCard {
        Text(ex.nameRu, style = MaterialTheme.typography.titleMedium, color = PureWhite)
        Text(
          ex.technique,
          style = MaterialTheme.typography.bodySmall,
          color = MidGray,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          (1..ex.defaultSets).forEach { setNum ->
            val key = "${ex.id}_$setNum"
            val done = key in completedSetKeys
            AzxChip(
              text = if (ex.defaultDurationSec > 0) "П$setNum (${ex.defaultDurationSec}с)" else "П$setNum (${ex.defaultReps}x)",
              selected = done,
              onClick = {
                if (done) {
                  completedSetKeys.remove(key)
                  totalSetsDone = (totalSetsDone - 1).coerceAtLeast(0)
                } else {
                  completedSetKeys.add(key)
                  totalSetsDone++
                  restSecondsLeft = ex.restSec
                  restRunning = true
                }
              },
            )
          }
        }
      }
    }

    item {
      OutlinedTextField(
        value = notes,
        onValueChange = { notes = it },
        label = { Text("Заметка по тренировке (самочувствие, техника)") },
        colors = azxTextFieldColors(),
        modifier = Modifier.fillMaxWidth(),
      )
      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        AzxSecondaryButton(text = "Отмена", onClick = onCancel, modifier = Modifier.weight(1f))
        AzxPrimaryButton(
          text = "Завершить",
          icon = Icons.Rounded.Check,
          enabled = totalSetsDone > 0,
          onClick = {
            val mins = (elapsedSeconds / 60).coerceAtLeast(1)
            onFinish(totalSetsDone, mins, notes.trim())
          },
          modifier = Modifier.weight(1.4f),
        )
      }
    }
  }
}

@Composable
private fun WorkoutBuilderDialog(
  exercises: List<ExerciseEntity>,
  onDismiss: () -> Unit,
  onSave: (WorkoutEntity) -> Unit,
) {
  var title by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("HOME") }
  val pickedIds = remember { mutableStateListOf<Long>() }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = AlmostBlack,
    titleContentColor = PureWhite,
    title = { Text("Конструктор комплекса") },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Название комплекса") },
          singleLine = true,
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          bodyCategories.drop(1).forEach { (code, lbl) ->
            AzxChip(text = lbl, selected = category == code, onClick = { category = code })
          }
        }
        Text("Выбери упражнения (${pickedIds.size}):", style = MaterialTheme.typography.labelMedium, color = LightGray)
        exercises.forEach { ex ->
          val checked = ex.id in pickedIds
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
              checked = checked,
              onCheckedChange = {
                if (checked) pickedIds.remove(ex.id) else pickedIds.add(ex.id)
              },
              colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
            )
            Text(ex.nameRu, style = MaterialTheme.typography.bodySmall, color = PureWhite)
          }
        }
      }
    },
    confirmButton = {
      TextButton(
        enabled = title.isNotBlank() && pickedIds.isNotEmpty(),
        onClick = {
          val selectedEx = exercises.filter { it.id in pickedIds }
          val muscles =
            selectedEx
              .flatMap { it.primaryMusclesCsv.split(",") }
              .map { it.trim() }
              .filter { it.isNotEmpty() }
              .distinct()
              .joinToString(",")
          onSave(
            WorkoutEntity(
              title = title.trim(),
              category = category,
              description = "Пользовательский комплекс (${selectedEx.size} упр.)",
              exerciseIdsCsv = pickedIds.joinToString(","),
              targetMusclesCsv = muscles,
              estimatedMinutes = (selectedEx.size * 6).coerceIn(10, 60),
              isCustom = true,
            ),
          )
          onDismiss()
        },
      ) {
        Text("СОХРАНИТЬ", color = if (title.isNotBlank() && pickedIds.isNotEmpty()) PureWhite else MidGray)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("ОТМЕНА", color = LightGray) }
    },
  )
}
