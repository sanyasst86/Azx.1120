package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Forward
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.coach.CoachHorizon
import com.example.coach.CoachPlanResult
import com.example.data.repository.AzxRepository
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxChip
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun CoachScreen(
  plan: CoachPlanResult,
  onHorizonChange: (CoachHorizon) -> Unit,
  onCarryOverOverdue: () -> Unit,
  onShiftBlock: (String, Int) -> Unit,
  onRemoveBlock: (String) -> Unit,
  onApplyToCalendar: () -> Unit,
  onBack: () -> Unit,
) {
  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = PureWhite)
      }
      Column {
        Text("COACH — ПЕРСОНАЛЬНЫЙ ПЛАНИРОВЩИК", style = MaterialTheme.typography.titleLarge, color = PureWhite)
        Text(
          "Локальный алгоритм расписания и приоритетов (оффлайн)",
          style = MaterialTheme.typography.bodySmall,
          color = MidGray,
        )
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          CoachHorizon.entries.forEach { h ->
            AzxChip(
              text = h.titleRu,
              selected = plan.horizon == h,
              onClick = { onHorizonChange(h) },
            )
          }
        }
      }

      item {
        AzxCard(containerColor = AlmostBlack) {
          Text("Рекомендации по организации", style = MaterialTheme.typography.titleMedium, color = PureWhite)
          Spacer(modifier = Modifier.height(6.dp))
          plan.recommendations.forEach { rec ->
            Text("• $rec", style = MaterialTheme.typography.bodySmall, color = LightGray)
            Spacer(modifier = Modifier.height(4.dp))
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            if (plan.overdueCount > 0) {
              AzxSecondaryButton(
                text = "Перенести (${plan.overdueCount})",
                icon = Icons.Rounded.Forward,
                onClick = onCarryOverOverdue,
                modifier = Modifier.weight(1f),
              )
            }
            AzxPrimaryButton(
              text = "Применить в календарь",
              icon = Icons.Rounded.Check,
              onClick = onApplyToCalendar,
              modifier = Modifier.weight(1f).testTag("coach_apply_btn"),
            )
          }
        }
      }

      item {
        Text(
          text = "Слоты плана (${plan.blocks.size}) — можно вручную сдвинуть время или убрать блок",
          style = MaterialTheme.typography.titleSmall,
          color = LightGray,
        )
      }

      items(plan.blocks, key = { it.id }) { block ->
        AzxCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                AzxBadge(
                  text = "%02d:%02d".format(block.startMinutes / 60, block.startMinutes % 60),
                  filled = true,
                )
                Spacer(modifier = Modifier.width(6.dp))
                AzxBadge(text = block.direction)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = AzxRepository.formatEpochDay(block.dateEpochDay),
                  style = MaterialTheme.typography.labelSmall,
                  color = MidGray,
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(block.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
              Text(
                text = "${block.durationMinutes} мин • ${block.note.ifBlank { block.type }}",
                style = MaterialTheme.typography.bodySmall,
                color = MidGray,
              )
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            IconButton(onClick = { onShiftBlock(block.id, -30) }) {
              Icon(Icons.Rounded.Remove, contentDescription = "Раньше на 30 мин", tint = LightGray)
            }
            Text("±30м", style = MaterialTheme.typography.labelSmall, color = MidGray)
            IconButton(onClick = { onShiftBlock(block.id, 30) }) {
              Icon(Icons.Rounded.Add, contentDescription = "Позже на 30 мин", tint = LightGray)
            }
            IconButton(onClick = { onRemoveBlock(block.id) }) {
              Icon(Icons.Rounded.Delete, contentDescription = "Убрать блок", tint = MidGray)
            }
          }
        }
      }
    }
  }
}
