package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.TaskEntity
import com.example.domain.model.Direction
import com.example.ui.AzxUiState
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxEmptyState
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxProgressBar
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.AzxSectionHeader
import com.example.ui.theme.DarkGray
import com.example.ui.theme.Graphite
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun DashboardScreen(
  state: AzxUiState,
  isWideLayout: Boolean,
  onStartDay: () -> Unit,
  onAddTask: (TaskEntity) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onOpenCoach: () -> Unit,
  onOpenGame: () -> Unit,
  onOpenBody: () -> Unit,
  onOpenAnatomy: () -> Unit,
  onOpenPlans: () -> Unit,
  onOpenGoals: () -> Unit,
  onOpenDirection: (Direction) -> Unit,
) {
  var showTaskDialog by remember { mutableStateOf(false) }

  val todayTasks =
    remember(state.tasks, state.todayEpoch) {
      state.tasks.filter { it.dateEpochDay == state.todayEpoch }
    }
  val doneTodayCount = todayTasks.count { it.status == "DONE" }
  val todayHabits = state.habits.filter { it.isActive }
  val habitsDoneToday =
    remember(state.habitHistories, state.todayEpoch) {
      state.habitHistories.count { it.dateEpochDay == state.todayEpoch && it.completed }
    }
  val totalDayItems = todayTasks.size + todayHabits.size
  val completedDayItems = doneTodayCount + habitsDoneToday.coerceAtMost(todayHabits.size)
  val dayProgress =
    if (totalDayItems == 0) 0f
    else (completedDayItems.toFloat() / totalDayItems.toFloat()).coerceIn(0f, 1f)

  val activeGoals = remember(state.goals) { state.goals.filter { !it.isCompleted }.take(3) }
  val currentMissions =
    remember(state.missions) { state.missions.filter { !it.isCompleted }.take(3) }
  val unlockedAchievements =
    remember(state.achievements) { state.achievements.filter { it.isUnlocked }.take(3) }
  val nextWorkout =
    remember(state.workouts, state.todayEpoch) {
      state.workouts.firstOrNull { it.scheduledEpochDay == state.todayEpoch }
        ?: state.workouts.firstOrNull()
    }

  val isDayStartedToday = state.dayStartedEpoch == state.todayEpoch

  LazyColumn(
    modifier = Modifier.fillMaxSize().background(PureBlack),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // 1. Header & Greeting
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "AZX.V16 // BUILD YOUR PRIME",
            style = MaterialTheme.typography.labelSmall,
            color = MidGray,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Привет, ${state.profile.displayName}",
            style = MaterialTheme.typography.displaySmall,
            color = PureWhite,
          )
        }
        AzxBadge(
          text = "LVL ${state.levelProgress.level} • ${state.levelProgress.rankTitle}",
          filled = true,
        )
      }
    }

    // 2, 3, 4, 5. Level, XP, Streak, Daily Progress Card
    item {
      AzxCard(containerColor = AlmostBlack) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          MetricTile(
            label = "УРОВЕНЬ",
            value = "${state.levelProgress.level}",
            sub = "${state.levelProgress.currentXp} / ${state.levelProgress.nextLevelXp} XP",
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "ОПЫТ (XP)",
            value = "${state.totalXp}",
            sub = "За реальные действия",
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "STREAK",
            value = "${state.streakDays} дн.",
            sub = "Без штрафа за отдых",
            modifier = Modifier.weight(1f),
          )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = "Прогресс за день",
            style = MaterialTheme.typography.titleSmall,
            color = PureWhite,
          )
          Text(
            text = "${(dayProgress * 100).toInt()}% ($completedDayItems/$totalDayItems)",
            style = MaterialTheme.typography.labelMedium,
            color = LightGray,
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        AzxProgressBar(progress = dayProgress, heightDp = 9)
      }
    }

    // 11 & 12. НАЧАТЬ ДЕНЬ + Быстрое добавление задачи
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        AzxPrimaryButton(
          text = if (isDayStartedToday) "ДЕНЬ АКТИВЕН" else "НАЧАТЬ ДЕНЬ",
          icon = if (isDayStartedToday) Icons.Rounded.CheckCircle else Icons.Rounded.PlayArrow,
          onClick = onStartDay,
          modifier = Modifier.weight(1.2f).testTag("start_day_button"),
        )
        AzxSecondaryButton(
          text = "+ ЗАДАЧА",
          icon = Icons.Rounded.Add,
          onClick = { showTaskDialog = true },
          modifier = Modifier.weight(1f).testTag("quick_add_task_button"),
        )
      }
    }

    // Quick module access (COACH, GAME, 3D АНАТОМИЯ)
    item {
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        QuickModuleCard("COACH", "План дня", Icons.Rounded.Route, onOpenCoach)
        QuickModuleCard("GAME", "${state.totalXp} XP", Icons.Rounded.SportsEsports, onOpenGame)
        QuickModuleCard("3D МЫШЦЫ", "Анатомия", Icons.Rounded.AccessibilityNew, onOpenAnatomy)
        QuickModuleCard("BODY", "Тренировки", Icons.Rounded.FitnessCenter, onOpenBody)
      }
    }

    // 7 Directions strip
    item {
      AzxSectionHeader(
        title = "7 Направлений",
        subtitle = "Выбери направление для задач, целей и статистики",
        actionLabel = "Все",
        onAction = onOpenGoals,
      )
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Direction.entries.forEach { dir ->
          Surface(
            modifier =
              Modifier
                .width(128.dp)
                .clip(RoundedCornerShape(14.dp))
                .clickable { onOpenDirection(dir) }
                .testTag("dir_card_${dir.code}"),
            color = Graphite,
            border = BorderStroke(1.dp, DarkGray),
            shape = RoundedCornerShape(14.dp),
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Icon(
                imageVector = dir.icon,
                contentDescription = dir.title,
                tint = PureWhite,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = dir.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = PureWhite,
                maxLines = 1,
              )
              val dirDone = state.tasks.count { it.direction == dir.code && it.status == "DONE" }
              Text(
                text = "Выполнено: $dirDone",
                style = MaterialTheme.typography.bodySmall,
                color = MidGray,
                maxLines = 1,
              )
            }
          }
        }
      }
    }

    // 6. Задачи на сегодня
    item {
      AzxSectionHeader(
        title = "Задачи на сегодня",
        subtitle = if (todayTasks.isEmpty()) "Добавь задачи на день" else "$doneTodayCount из ${todayTasks.size} выполнено",
        actionLabel = "Планы",
        onAction = onOpenPlans,
      )
    }

    if (todayTasks.isEmpty()) {
      item {
        AzxEmptyState(
          icon = Icons.Rounded.RadioButtonUnchecked,
          title = "На сегодня задач пока нет",
          description = "Создай первую задачу — прогресс и XP начнут расти только после реального выполнения.",
          actionLabel = "Добавить задачу",
          onAction = { showTaskDialog = true },
        )
      }
    } else {
      items(todayTasks.take(5), key = { it.id }) { task ->
        val done = task.status == "DONE"
        AzxCard(onClick = { onToggleTask(task) }) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Checkbox(
              checked = done,
              onCheckedChange = { onToggleTask(task) },
              colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = task.title,
                style =
                  MaterialTheme.typography.titleMedium.copy(
                    textDecoration = if (done) TextDecoration.LineThrough else TextDecoration.None,
                  ),
                color = if (done) MidGray else PureWhite,
              )
              Text(
                text = buildString {
                  append(task.direction)
                  task.timeMinutes?.let { tm ->
                    append(" • %02d:%02d".format(tm / 60, tm % 60))
                  }
                },
                style = MaterialTheme.typography.bodySmall,
                color = MidGray,
              )
            }
            AzxBadge(text = "+${task.xpAwarded} XP")
          }
        }
      }
    }

    // 7. Ближайшая тренировка
    item {
      AzxSectionHeader(
        title = "Ближайшая тренировка",
        actionLabel = "Модуль BODY",
        onAction = onOpenBody,
      )
      Spacer(modifier = Modifier.height(6.dp))
      if (nextWorkout == null) {
        AzxEmptyState(
          icon = Icons.Rounded.FitnessCenter,
          title = "Тренировки не настроены",
          description = "Создай собственный комплекс в разделе BODY.",
          actionLabel = "Открыть BODY",
          onAction = onOpenBody,
        )
      } else {
        AzxCard(onClick = onOpenBody) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = nextWorkout.title,
                style = MaterialTheme.typography.titleMedium,
                color = PureWhite,
              )
              Text(
                text = nextWorkout.description,
                style = MaterialTheme.typography.bodySmall,
                color = MidGray,
                maxLines = 2,
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            AzxBadge(text = "${nextWorkout.estimatedMinutes} мин", filled = true)
          }
        }
      }
    }

    // 8. Активные цели
    item {
      AzxSectionHeader(
        title = "Активные цели",
        actionLabel = "Все цели",
        onAction = onOpenGoals,
      )
      Spacer(modifier = Modifier.height(6.dp))
      if (activeGoals.isEmpty()) {
        AzxEmptyState(
          icon = Icons.Rounded.CheckCircle,
          title = "Активных целей пока нет",
          description = "Поставь реальную цель в разделе «Цели», чтобы отслеживать процент выполнения.",
          actionLabel = "Открыть цели",
          onAction = onOpenGoals,
        )
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          activeGoals.forEach { goal ->
            AzxCard(onClick = onOpenGoals) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(goal.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                AzxBadge(text = "${goal.progressPercent}%")
              }
              Spacer(modifier = Modifier.height(6.dp))
              AzxProgressBar(progress = goal.progressPercent / 100f, heightDp = 6)
            }
          }
        }
      }
    }

    // 9. Текущие миссии
    item {
      AzxSectionHeader(
        title = "Текущие миссии",
        actionLabel = "GAME",
        onAction = onOpenGame,
      )
      Spacer(modifier = Modifier.height(6.dp))
      if (currentMissions.isEmpty()) {
        AzxCard(onClick = onOpenGame) {
          Text(
            text = "Все текущие миссии выполнены! Загляни в раздел GAME.",
            style = MaterialTheme.typography.bodyMedium,
            color = LightGray,
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          currentMissions.forEach { m ->
            AzxCard(onClick = onOpenGame) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(m.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                  Text(m.description, style = MaterialTheme.typography.bodySmall, color = MidGray)
                }
                AzxBadge(text = "${m.currentCount}/${m.targetCount} • +${m.xpReward} XP")
              }
            }
          }
        }
      }
    }

    // 10. Последние достижения (strictly real unlocked only!)
    item {
      AzxSectionHeader(
        title = "Последние достижения",
        actionLabel = "Все",
        onAction = onOpenGame,
      )
      Spacer(modifier = Modifier.height(6.dp))
      if (unlockedAchievements.isEmpty()) {
        AzxEmptyState(
          icon = Icons.Rounded.EmojiEvents,
          title = "Достижений пока 0",
          description = "Выполняй задачи, тренировки и привычки — первые достижения откроются автоматически.",
          actionLabel = "Открыть GAME",
          onAction = onOpenGame,
        )
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          unlockedAchievements.forEach { ach ->
            AzxCard(onClick = onOpenGame) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(ach.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                  Text(ach.description, style = MaterialTheme.typography.bodySmall, color = MidGray)
                }
                AzxBadge(text = "ОТКРЫТО", filled = true)
              }
            }
          }
        }
      }
      Spacer(modifier = Modifier.height(16.dp))
    }
  }

  if (showTaskDialog) {
    TaskEditorDialog(
      goals = state.goals,
      onDismiss = { showTaskDialog = false },
      onSave = onAddTask,
    )
  }
}

@Composable
private fun MetricTile(
  label: String,
  value: String,
  sub: String,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier) {
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = MidGray)
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = value, style = MaterialTheme.typography.headlineMedium, color = PureWhite)
    Text(text = sub, style = MaterialTheme.typography.bodySmall, color = LightGray, maxLines = 1)
  }
}

@Composable
private fun QuickModuleCard(
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  onClick: () -> Unit,
) {
  Surface(
    modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick),
    color = AlmostBlack,
    border = BorderStroke(1.dp, DarkGray),
    shape = RoundedCornerShape(14.dp),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(imageVector = icon, contentDescription = title, tint = PureWhite, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text(text = title, style = MaterialTheme.typography.labelLarge, color = PureWhite)
        Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = MidGray)
      }
    }
  }
}
