package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.repository.AzxRepository
import com.example.domain.model.Direction
import com.example.ui.AzxUiState
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxEmptyState
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxProgressBar
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.AzxSectionHeader
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun DirectionDetailScreen(
  direction: Direction,
  state: AzxUiState,
  onBack: () -> Unit,
  onSaveTask: (TaskEntity) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onSaveGoal: (GoalEntity, List<String>) -> Unit,
  onOpenSpecializedModule: (Direction) -> Unit,
) {
  var showAddTask by remember { mutableStateOf(false) }
  var showAddGoal by remember { mutableStateOf(false) }

  val dirTasks = remember(state.tasks, direction) { state.tasks.filter { it.direction == direction.code } }
  val dirGoals = remember(state.goals, direction) { state.goals.filter { it.direction == direction.code } }
  val doneTasks = dirTasks.filter { it.status == "DONE" }
  val openTasks = dirTasks.filter { it.status != "DONE" }

  val completionRate =
    if (dirTasks.isEmpty()) 0f else (doneTasks.size.toFloat() / dirTasks.size.toFloat()).coerceIn(0f, 1f)

  val specialButtonLabel =
    when (direction) {
      Direction.BODY -> "Открыть модуль BODY и 3D"
      Direction.BASKETBALL -> "Открыть модуль BASKETBALL"
      Direction.MIND -> "Открыть модуль MIND"
      Direction.DISCIPLINE -> "Открыть модуль DISCIPLINE"
      Direction.STYLE -> "Открыть модуль STYLE"
      Direction.PROJECTS -> "Открыть менеджер PROJECTS"
      Direction.LIFE_SKILLS -> "Открыть LIFE SKILLS"
    }

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = PureWhite)
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(direction.title, style = MaterialTheme.typography.headlineMedium, color = PureWhite)
        Text(direction.subtitle, style = MaterialTheme.typography.bodySmall, color = MidGray)
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Progress & Stats Card
      item {
        AzxCard(containerColor = AlmostBlack) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column {
              Text("Прогресс направления", style = MaterialTheme.typography.titleSmall, color = PureWhite)
              Text(
                "Задач: ${doneTasks.size}/${dirTasks.size} • Целей: ${dirGoals.size}",
                style = MaterialTheme.typography.bodySmall,
                color = MidGray,
              )
            }
            AzxBadge(text = "${(completionRate * 100).toInt()}%", filled = true)
          }
          Spacer(modifier = Modifier.height(8.dp))
          AzxProgressBar(progress = completionRate, heightDp = 8)
          Spacer(modifier = Modifier.height(12.dp))
          AzxPrimaryButton(
            text = specialButtonLabel,
            icon = Icons.Rounded.OpenInNew,
            onClick = { onOpenSpecializedModule(direction) },
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          AzxSecondaryButton(
            text = "+ Задача",
            icon = Icons.Rounded.Add,
            onClick = { showAddTask = true },
            modifier = Modifier.weight(1f),
          )
          AzxSecondaryButton(
            text = "+ Цель",
            icon = Icons.Rounded.Add,
            onClick = { showAddGoal = true },
            modifier = Modifier.weight(1f),
          )
        }
      }

      // Direction Goals
      item {
        AzxSectionHeader(title = "Цели направления (${dirGoals.size})")
      }
      if (dirGoals.isEmpty()) {
        item {
          AzxCard {
            Text(
              "Целей в ${direction.title} пока нет.",
              style = MaterialTheme.typography.bodySmall,
              color = MidGray,
            )
          }
        }
      } else {
        items(dirGoals, key = { it.id }) { g ->
          AzxCard {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(g.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
              AzxBadge(text = "${g.progressPercent}%")
            }
            Spacer(modifier = Modifier.height(6.dp))
            AzxProgressBar(progress = g.progressPercent / 100f)
          }
        }
      }

      // Open Tasks
      item {
        AzxSectionHeader(title = "Активные задачи (${openTasks.size})")
      }
      if (openTasks.isEmpty()) {
        item {
          AzxEmptyState(
            icon = Icons.Rounded.TaskAlt,
            title = "Нет активных задач",
            description = "Добавь задачу для направления ${direction.title}.",
            actionLabel = "Добавить задачу",
            onAction = { showAddTask = true },
          )
        }
      } else {
        items(openTasks, key = { it.id }) { task ->
          AzxCard(onClick = { onToggleTask(task) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Checkbox(
                checked = false,
                onCheckedChange = { onToggleTask(task) },
                colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
              )
              Column(modifier = Modifier.weight(1f)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                Text(AzxRepository.formatEpochDay(task.dateEpochDay), style = MaterialTheme.typography.bodySmall, color = MidGray)
              }
              AzxBadge(text = "+${task.xpAwarded} XP")
            }
          }
        }
      }

      // Completion History
      item {
        AzxSectionHeader(title = "История выполнения (${doneTasks.size})")
      }
      if (doneTasks.isEmpty()) {
        item {
          AzxCard {
            Text("История появится после выполнения первых задач.", style = MaterialTheme.typography.bodySmall, color = MidGray)
          }
        }
      } else {
        items(doneTasks.take(15), key = { it.id }) { task ->
          AzxCard(containerColor = AlmostBlack) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                task.title,
                style = MaterialTheme.typography.bodyMedium.copy(textDecoration = TextDecoration.LineThrough),
                color = LightGray,
              )
              Text(
                task.completedAt?.let { AzxRepository.formatDateShort(it) } ?: "",
                style = MaterialTheme.typography.labelSmall,
                color = MidGray,
              )
            }
          }
        }
      }
    }
  }

  if (showAddTask) {
    TaskEditorDialog(
      defaultDirection = direction,
      goals = state.goals,
      onDismiss = { showAddTask = false },
      onSave = onSaveTask,
    )
  }

  if (showAddGoal) {
    GoalEditorDialog(
      defaultDirection = direction,
      onDismiss = { showAddGoal = false },
      onSave = onSaveGoal,
    )
  }
}
