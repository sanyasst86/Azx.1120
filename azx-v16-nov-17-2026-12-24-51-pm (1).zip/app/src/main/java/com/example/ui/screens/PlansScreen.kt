package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Mood
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CalendarEventEntity
import com.example.data.local.entity.DiaryEntryEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.repository.AzxRepository
import com.example.domain.model.Direction
import com.example.ui.AzxUiState
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxChip
import com.example.ui.theme.AzxEmptyState
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.DarkGray
import com.example.ui.theme.Graphite
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

private enum class PlansTab(val label: String) {
  TASKS("Задачи"),
  CALENDAR("Календарь"),
  HABITS_DIARY("Привычки и дневник"),
}

private enum class CalendarMode(val label: String) {
  DAY("День"),
  WEEK("Неделя"),
  MONTH("Месяц"),
}

@Composable
fun PlansScreen(
  state: AzxUiState,
  onSaveTask: (TaskEntity) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onDeleteTask: (TaskEntity) -> Unit,
  onSaveHabit: (HabitEntity) -> Unit,
  onToggleHabitDay: (HabitEntity, Long) -> Unit,
  onDeleteHabit: (HabitEntity) -> Unit,
  onSaveDiary: (DiaryEntryEntity) -> Unit,
  onSaveCalendarEvent: (CalendarEventEntity) -> Unit,
  onDeleteCalendarEvent: (CalendarEventEntity) -> Unit,
  onOpenCoach: () -> Unit,
) {
  var selectedTab by remember { mutableStateOf(PlansTab.TASKS) }
  var editingTask by remember { mutableStateOf<TaskEntity?>(null) }
  var showNewTaskDialog by remember { mutableStateOf(false) }
  var showNewHabitDialog by remember { mutableStateOf(false) }
  var editingHabit by remember { mutableStateOf<HabitEntity?>(null) }
  var taskDirectionFilter by remember { mutableStateOf<Direction?>(null) }
  var calendarMode by remember { mutableStateOf(CalendarMode.DAY) }
  var selectedCalendarDay by remember(state.todayEpoch) { mutableLongStateOf(state.todayEpoch) }

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    // Header + COACH CTA
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text("ПЛАНЫ И РИТМ", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
        Text("Задачи • Календарь • Привычки • Дневник", style = MaterialTheme.typography.bodySmall, color = MidGray)
      }
      AzxSecondaryButton(
        text = "COACH",
        icon = Icons.Rounded.Route,
        onClick = onOpenCoach,
        modifier = Modifier.testTag("open_coach_btn"),
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      PlansTab.entries.forEach { tab ->
        AzxChip(
          text = tab.label,
          selected = selectedTab == tab,
          onClick = { selectedTab = tab },
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    when (selectedTab) {
      PlansTab.TASKS -> {
        val filteredTasks =
          remember(state.tasks, taskDirectionFilter) {
            state.tasks.filter { taskDirectionFilter == null || it.direction == taskDirectionFilter!!.code }
          }
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(
                modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                AzxChip(
                  text = "Все",
                  selected = taskDirectionFilter == null,
                  onClick = { taskDirectionFilter = null },
                )
                Direction.entries.forEach { d ->
                  AzxChip(
                    text = d.title,
                    selected = taskDirectionFilter == d,
                    onClick = { taskDirectionFilter = d },
                  )
                }
              }
              Spacer(modifier = Modifier.width(8.dp))
              AzxPrimaryButton(
                text = "+ Задача",
                onClick = { showNewTaskDialog = true },
                modifier = Modifier.testTag("plans_add_task_btn"),
              )
            }
          }

          if (filteredTasks.isEmpty()) {
            item {
              AzxEmptyState(
                icon = Icons.Rounded.TaskAlt,
                title = "Задачи отсутствуют",
                description = "Добавь задачу, привяжи её к цели и задай повтор или напоминание.",
                actionLabel = "Создать задачу",
                onAction = { showNewTaskDialog = true },
              )
            }
          } else {
            items(filteredTasks, key = { it.id }) { task ->
              val done = task.status == "DONE"
              AzxCard {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Checkbox(
                    checked = done,
                    onCheckedChange = { onToggleTask(task) },
                    colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
                  )
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = task.title,
                      style =
                        MaterialTheme.typography.titleMedium.copy(
                          textDecoration = if (done) TextDecoration.LineThrough else TextDecoration.None,
                        ),
                      color = if (done) MidGray else PureWhite,
                    )
                    Text(
                      text =
                        "${task.direction} • ${AzxRepository.formatEpochDay(task.dateEpochDay)}" +
                          (task.timeMinutes?.let { " • %02d:%02d".format(it / 60, it % 60) } ?: ""),
                      style = MaterialTheme.typography.bodySmall,
                      color = MidGray,
                    )
                    if (task.description.isNotBlank()) {
                      Text(task.description, style = MaterialTheme.typography.bodySmall, color = LightGray)
                    }
                  }
                  IconButton(onClick = { editingTask = task }) {
                    Icon(Icons.Rounded.Edit, contentDescription = "Редактировать", tint = LightGray)
                  }
                  IconButton(onClick = { onDeleteTask(task) }) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Удалить", tint = MidGray)
                  }
                }
              }
            }
          }
        }
      }

      PlansTab.CALENDAR -> {
        CalendarSection(
          state = state,
          mode = calendarMode,
          selectedDay = selectedCalendarDay,
          onModeChange = { calendarMode = it },
          onSelectDay = { selectedCalendarDay = it },
          onToggleTask = onToggleTask,
          onSaveEvent = onSaveCalendarEvent,
          onDeleteEvent = onDeleteCalendarEvent,
        )
      }

      PlansTab.HABITS_DIARY -> {
        HabitsAndDiarySection(
          state = state,
          onAddHabit = { showNewHabitDialog = true },
          onEditHabit = { editingHabit = it },
          onToggleHabitDay = onToggleHabitDay,
          onDeleteHabit = onDeleteHabit,
          onSaveDiary = onSaveDiary,
        )
      }
    }
  }

  if (showNewTaskDialog || editingTask != null) {
    TaskEditorDialog(
      initialTask = editingTask,
      defaultEpochDay = selectedCalendarDay,
      goals = state.goals,
      onDismiss = {
        showNewTaskDialog = false
        editingTask = null
      },
      onSave = onSaveTask,
    )
  }

  if (showNewHabitDialog || editingHabit != null) {
    HabitEditorDialog(
      initialHabit = editingHabit,
      onDismiss = {
        showNewHabitDialog = false
        editingHabit = null
      },
      onSave = onSaveHabit,
    )
  }
}

@Composable
private fun CalendarSection(
  state: AzxUiState,
  mode: CalendarMode,
  selectedDay: Long,
  onModeChange: (CalendarMode) -> Unit,
  onSelectDay: (Long) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onSaveEvent: (CalendarEventEntity) -> Unit,
  onDeleteEvent: (CalendarEventEntity) -> Unit,
) {
  var showAddEvent by remember { mutableStateOf(false) }
  var newEventTitle by remember { mutableStateOf("") }
  var newEventHour by remember { mutableIntStateOf(16) }

  val rangeDays =
    remember(mode, selectedDay) {
      when (mode) {
        CalendarMode.DAY -> listOf(selectedDay)
        CalendarMode.WEEK -> (0..6).map { selectedDay + it }
        CalendarMode.MONTH -> (0..29).map { state.todayEpoch + it }
      }
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          CalendarMode.entries.forEach { m ->
            AzxChip(text = m.label, selected = mode == m, onClick = { onModeChange(m) })
          }
        }
        AzxSecondaryButton(
          text = "+ Событие",
          onClick = { showAddEvent = !showAddEvent },
        )
      }
    }

    if (showAddEvent) {
      item {
        AzxCard(containerColor = AlmostBlack) {
          OutlinedTextField(
            value = newEventTitle,
            onValueChange = { newEventTitle = it },
            label = { Text("Название события на ${AzxRepository.formatEpochDay(selectedDay)}") },
            colors = azxTextFieldColors(),
            modifier = Modifier.fillMaxWidth(),
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(9, 15, 17, 19).forEach { h ->
              AzxChip(
                text = "%02d:00".format(h),
                selected = newEventHour == h,
                onClick = { newEventHour = h },
              )
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          AzxPrimaryButton(
            text = "Добавить в календарь",
            enabled = newEventTitle.isNotBlank(),
            onClick = {
              onSaveEvent(
                CalendarEventEntity(
                  title = newEventTitle.trim(),
                  direction = "DISCIPLINE",
                  dateEpochDay = selectedDay,
                  startTimeMinutes = newEventHour * 60,
                  durationMinutes = 45,
                  type = "EVENT",
                ),
              )
              newEventTitle = ""
              showAddEvent = false
            },
          )
        }
      }
    }

    // Horizontal day selector for Day mode
    if (mode == CalendarMode.DAY) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          (-2..10).forEach { offset ->
            val d = state.todayEpoch + offset
            AzxChip(
              text = AzxRepository.formatEpochDay(d),
              selected = selectedDay == d,
              onClick = { onSelectDay(d) },
            )
          }
        }
      }
    }

    items(rangeDays, key = { it }) { day ->
      val dayTasks = state.tasks.filter { it.dateEpochDay == day }
      val dayEvents = state.calendarEvents.filter { it.dateEpochDay == day }
      if (mode == CalendarMode.DAY || dayTasks.isNotEmpty() || dayEvents.isNotEmpty()) {
        AzxCard(
          onClick = { onSelectDay(day) },
          borderColor = if (day == selectedDay) PureWhite else DarkGray,
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = AzxRepository.formatEpochDay(day),
              style = MaterialTheme.typography.titleMedium,
              color = PureWhite,
            )
            AzxBadge(text = "${dayTasks.size + dayEvents.size} эл.")
          }
          if (dayTasks.isEmpty() && dayEvents.isEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text("Свободный день", style = MaterialTheme.typography.bodySmall, color = MidGray)
          } else {
            Spacer(modifier = Modifier.height(8.dp))
            dayEvents.forEach { ev ->
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  text = "%02d:%02d  %s".format(ev.startTimeMinutes / 60, ev.startTimeMinutes % 60, ev.title),
                  style = MaterialTheme.typography.bodyMedium,
                  color = LightGray,
                  modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { onDeleteEvent(ev) }) {
                  Icon(Icons.Rounded.Delete, contentDescription = "Удалить событие", tint = MidGray)
                }
              }
            }
            dayTasks.forEach { t ->
              Row(
                modifier = Modifier.fillMaxWidth().clickable { onToggleTask(t) }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = Icons.Rounded.Check,
                  contentDescription = null,
                  tint = if (t.status == "DONE") PureWhite else DarkGray,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = t.title,
                  style = MaterialTheme.typography.bodyMedium,
                  color = if (t.status == "DONE") MidGray else PureWhite,
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun HabitsAndDiarySection(
  state: AzxUiState,
  onAddHabit: () -> Unit,
  onEditHabit: (HabitEntity) -> Unit,
  onToggleHabitDay: (HabitEntity, Long) -> Unit,
  onDeleteHabit: (HabitEntity) -> Unit,
  onSaveDiary: (DiaryEntryEntity) -> Unit,
) {
  val today = state.todayEpoch
  val existingTodayDiary =
    remember(state.diaryEntries, today) {
      state.diaryEntries.firstOrNull { it.dateEpochDay == today }
    }
  var mood by remember(existingTodayDiary) { mutableIntStateOf(existingTodayDiary?.moodRating ?: 4) }
  var sleepHours by remember(existingTodayDiary) {
    mutableFloatStateOf(existingTodayDiary?.sleepHours ?: 8f)
  }
  var isRestDay by remember(existingTodayDiary) {
    mutableStateOf(existingTodayDiary?.isRestDay ?: false)
  }
  var diaryNote by remember(existingTodayDiary) {
    mutableStateOf(existingTodayDiary?.gratitudeOrNote ?: "")
  }

  val last7Days = remember(today) { (6 downTo 0).map { today - it } }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("Трекер привычек", style = MaterialTheme.typography.titleLarge, color = PureWhite)
        AzxPrimaryButton(text = "+ Привычка", onClick = onAddHabit)
      }
    }

    if (state.habits.isEmpty()) {
      item {
        AzxEmptyState(
          icon = Icons.Rounded.CalendarMonth,
          title = "Привычек пока нет",
          description = "Создай первую полезную привычку — календарь покажет серию выполнения за 7 дней.",
          actionLabel = "Создать привычку",
          onAction = onAddHabit,
        )
      }
    } else {
      items(state.habits, key = { it.id }) { habit ->
        val completedDays =
          state.habitHistories.filter { it.habitId == habit.id && it.completed }.map { it.dateEpochDay }.toSet()
        AzxCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(habit.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
              Text(
                text = "${habit.direction} • Серия: ${habit.currentStreak} дн. • Рекорд: ${habit.bestStreak}",
                style = MaterialTheme.typography.bodySmall,
                color = MidGray,
              )
            }
            IconButton(onClick = { onEditHabit(habit) }) {
              Icon(Icons.Rounded.Edit, contentDescription = "Изменить", tint = LightGray)
            }
            IconButton(onClick = { onDeleteHabit(habit) }) {
              Icon(Icons.Rounded.Delete, contentDescription = "Удалить", tint = MidGray)
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            last7Days.forEach { d ->
              val checked = d in completedDays
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                  modifier =
                    Modifier
                      .size(36.dp)
                      .clip(RoundedCornerShape(8.dp))
                      .clickable { onToggleHabitDay(habit, d) },
                  color = if (checked) PureWhite else AlmostBlack,
                  border = BorderStroke(1.dp, if (checked) PureWhite else DarkGray),
                  shape = RoundedCornerShape(8.dp),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    if (checked) {
                      Icon(Icons.Rounded.Check, contentDescription = "Выполнено", tint = PureBlack, modifier = Modifier.size(18.dp))
                    }
                  }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = if (d == today) "Сег" else AzxRepository.formatEpochDay(d).take(2),
                  style = MaterialTheme.typography.labelSmall,
                  color = MidGray,
                )
              }
            }
          }
        }
      }
    }

    // Diary & Wellness Card
    item {
      AzxCard(containerColor = AlmostBlack) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.Mood, contentDescription = null, tint = PureWhite)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Дневник и самочувствие за сегодня", style = MaterialTheme.typography.titleMedium, color = PureWhite)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text("Самочувствие (1–5)", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          (1..5).forEach { score ->
            AzxChip(text = "$score", selected = mood == score, onClick = { mood = score })
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text("Сон (часы)", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf(7f, 8f, 9f, 10f).forEach { h ->
            AzxChip(text = "${h.toInt()} ч", selected = sleepHours == h, onClick = { sleepHours = h })
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("День восстановления / отдыха", style = MaterialTheme.typography.bodyMedium, color = PureWhite)
            Text("Сохраняет Streak без тренировочной нагрузки", style = MaterialTheme.typography.bodySmall, color = MidGray)
          }
          Switch(
            checked = isRestDay,
            onCheckedChange = { isRestDay = it },
            colors = SwitchDefaults.colors(checkedThumbColor = PureBlack, checkedTrackColor = PureWhite),
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = diaryNote,
          onValueChange = { diaryNote = it },
          label = { Text("Ежедневная заметка / итог дня") },
          minLines = 2,
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(10.dp))
        AzxPrimaryButton(
          text = "Сохранить запись дневника",
          onClick = {
            onSaveDiary(
              DiaryEntryEntity(
                id = existingTodayDiary?.id ?: 0L,
                dateEpochDay = today,
                moodRating = mood,
                sleepHours = sleepHours,
                isRestDay = isRestDay,
                gratitudeOrNote = diaryNote.trim(),
              ),
            )
          },
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }

    if (state.diaryEntries.isNotEmpty()) {
      item {
        Text("История дневника", style = MaterialTheme.typography.titleMedium, color = PureWhite)
      }
      items(state.diaryEntries.take(10), key = { it.id }) { entry ->
        AzxCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(AzxRepository.formatEpochDay(entry.dateEpochDay), style = MaterialTheme.typography.titleSmall, color = PureWhite)
            AzxBadge(text = "Оценка ${entry.moodRating}/5 • Сон ${entry.sleepHours.toInt()}ч")
          }
          if (entry.gratitudeOrNote.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(entry.gratitudeOrNote, style = MaterialTheme.typography.bodySmall, color = LightGray)
          }
        }
      }
    }
  }
}
