package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.backup.LocalTransferManager
import com.example.backup.TransferSessionInfo
import com.example.data.local.entity.ProfileEntity
import com.example.data.local.entity.ReminderEntity
import com.example.data.local.entity.SettingsEntity
import com.example.data.repository.AzxRepository
import com.example.data.repository.FullBackupSnapshot
import com.example.notifications.NotificationHelper
import com.example.ui.AzxUiState
import com.example.ui.BackupDialogState
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxChip
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.AzxSectionHeader
import com.example.ui.theme.Graphite
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun ProfileScreen(
  state: AzxUiState,
  backupDialog: BackupDialogState,
  transferSession: TransferSessionInfo?,
  transferRunning: Boolean,
  onSaveProfile: (ProfileEntity) -> Unit,
  onSaveSettings: (SettingsEntity) -> Unit,
  onAddReminder: (ReminderEntity) -> Unit,
  onToggleReminder: (ReminderEntity) -> Unit,
  onDeleteReminder: (ReminderEntity) -> Unit,
  onExportBackup: (android.net.Uri) -> Unit,
  onImportBackup: (android.net.Uri) -> Unit,
  onConfirmRestore: (FullBackupSnapshot) -> Unit,
  onDismissBackupDialog: () -> Unit,
  onStartWifiQrSender: () -> Unit,
  onCancelWifiQrSender: () -> Unit,
  onReceiveFromWifi: (String, Int, String) -> Unit,
  onShowMessage: (String) -> Unit,
) {
  val context = LocalContext.current
  val p = state.profile
  val s = state.settings

  var displayName by remember(p) { mutableStateOf(p.displayName) }
  var ageText by remember(p) { mutableStateOf(p.age.toString()) }
  var heightText by remember(p) { mutableStateOf(p.heightCm.toString()) }
  var weightText by remember(p) { mutableStateOf(p.weightKg.toString()) }
  var fitnessLevel by remember(p) { mutableStateOf(p.fitnessLevel) }
  var interests by remember(p) { mutableStateOf(p.interests) }
  var mainGoals by remember(p) { mutableStateOf(p.mainGoalsSummary) }
  var priorities by remember(p) { mutableStateOf(p.priorities) }
  var scheduleNotes by remember(p) { mutableStateOf(p.scheduleNotes) }
  var equipment by remember(p) { mutableStateOf(p.availableEquipment) }

  var newReminderTitle by remember { mutableStateOf("") }
  var newReminderHour by remember { mutableIntStateOf(18) }

  var showReceiveDialog by remember { mutableStateOf(false) }
  var showQrScanner by remember { mutableStateOf(false) }
  var receiveIp by remember { mutableStateOf("") }
  var receivePort by remember { mutableStateOf("") }
  var receivePin by remember { mutableStateOf("") }

  val notifPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) {
        onSaveSettings(s.copy(notificationsEnabled = true))
        onShowMessage("Уведомления включены.")
      } else {
        onSaveSettings(s.copy(notificationsEnabled = false))
        onShowMessage("Разрешение на уведомления отклонено системой.")
      }
    }

  val exportBackupLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
      if (uri != null) onExportBackup(uri)
    }

  val importBackupLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) onImportBackup(uri)
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize().background(PureBlack),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text("ПРОФИЛЬ И СИСТЕМА", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
          Text(
            "Личные настройки • Уведомления • Резервные копии",
            style = MaterialTheme.typography.bodySmall,
            color = MidGray,
          )
        }
        AzxBadge(text = "LVL ${state.levelProgress.level}", filled = true)
      }
    }

    // Editable Profile Form
    item {
      AzxCard(containerColor = AlmostBlack) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.Person, contentDescription = null, tint = PureWhite)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Личные данные и спорт-профиль", style = MaterialTheme.typography.titleMedium, color = PureWhite)
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = displayName,
          onValueChange = { displayName = it },
          label = { Text("Имя / Позывной") },
          singleLine = true,
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = ageText,
            onValueChange = { ageText = it.filter { ch -> ch.isDigit() } },
            label = { Text("Возраст") },
            singleLine = true,
            colors = azxTextFieldColors(),
            modifier = Modifier.weight(1f),
          )
          OutlinedTextField(
            value = heightText,
            onValueChange = { heightText = it.filter { ch -> ch.isDigit() } },
            label = { Text("Рост (см)") },
            singleLine = true,
            colors = azxTextFieldColors(),
            modifier = Modifier.weight(1f),
          )
          OutlinedTextField(
            value = weightText,
            onValueChange = { weightText = it },
            label = { Text("Вес (кг)") },
            singleLine = true,
            colors = azxTextFieldColors(),
            modifier = Modifier.weight(1f),
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Уровень подготовки", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Spacer(modifier = Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("Базовый", "Средний", "Атлетичный").forEach { lvl ->
            AzxChip(text = lvl, selected = fitnessLevel == lvl, onClick = { fitnessLevel = lvl })
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = interests,
          onValueChange = { interests = it },
          label = { Text("Интересы") },
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
          value = mainGoals,
          onValueChange = { mainGoals = it },
          label = { Text("Главные цели") },
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
          value = priorities,
          onValueChange = { priorities = it },
          label = { Text("Приоритеты") },
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
          value = scheduleNotes,
          onValueChange = { scheduleNotes = it },
          label = { Text("Расписание (учёба, тренировки, сон)") },
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
          value = equipment,
          onValueChange = { equipment = it },
          label = { Text("Оборудование для тренировок") },
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(10.dp))
        AzxPrimaryButton(
          text = "Сохранить профиль",
          icon = Icons.Rounded.Save,
          onClick = {
            onSaveProfile(
              p.copy(
                displayName = displayName.trim().ifBlank { "Атлет" },
                age = ageText.toIntOrNull()?.coerceIn(10, 99) ?: 14,
                heightCm = heightText.toIntOrNull()?.coerceIn(100, 230) ?: 168,
                weightKg = weightText.toFloatOrNull()?.coerceIn(30f, 180f) ?: 56f,
                fitnessLevel = fitnessLevel,
                interests = interests.trim(),
                mainGoalsSummary = mainGoals.trim(),
                priorities = priorities.trim(),
                scheduleNotes = scheduleNotes.trim(),
                availableEquipment = equipment.trim(),
              ),
            )
          },
          modifier = Modifier.fillMaxWidth().testTag("save_profile_btn"),
        )
      }
    }

    // Notifications & Reminders
    item {
      AzxCard {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = PureWhite)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("Уведомления Android", style = MaterialTheme.typography.titleMedium, color = PureWhite)
              Text("План дня в %02d:%02d • Напоминания".format(s.dailyPlanHour, s.dailyPlanMinute), style = MaterialTheme.typography.bodySmall, color = MidGray)
            }
          }
          Switch(
            checked = s.notificationsEnabled,
            onCheckedChange = { enable ->
              if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                !NotificationHelper.hasNotificationPermission(context)
              ) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
              } else {
                onSaveSettings(s.copy(notificationsEnabled = enable))
              }
            },
            colors = SwitchDefaults.colors(checkedThumbColor = PureBlack, checkedTrackColor = PureWhite),
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Время утреннего плана:", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf(7, 8, 9, 15).forEach { h ->
            AzxChip(
              text = "%02d:00".format(h),
              selected = s.dailyPlanHour == h,
              onClick = { onSaveSettings(s.copy(dailyPlanHour = h, dailyPlanMinute = 0)) },
            )
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = newReminderTitle,
          onValueChange = { newReminderTitle = it },
          label = { Text("Новое напоминание (тренировка / привычка)") },
          singleLine = true,
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf(9, 16, 18, 21).forEach { h ->
            AzxChip(
              text = "%02d:00".format(h),
              selected = newReminderHour == h,
              onClick = { newReminderHour = h },
            )
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        AzxSecondaryButton(
          text = "Добавить напоминание",
          enabled = newReminderTitle.isNotBlank(),
          onClick = {
            onAddReminder(
              ReminderEntity(
                title = newReminderTitle.trim(),
                targetType = "DAILY_PLAN",
                hour = newReminderHour,
                minute = 0,
              ),
            )
            newReminderTitle = ""
          },
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }

    items(state.reminders, key = { it.id }) { rem ->
      AzxCard {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(rem.title, style = MaterialTheme.typography.titleSmall, color = PureWhite)
            Text("%02d:%02d • ${rem.targetType}".format(rem.hour, rem.minute), style = MaterialTheme.typography.bodySmall, color = MidGray)
          }
          Switch(
            checked = rem.enabled,
            onCheckedChange = { onToggleReminder(rem) },
            colors = SwitchDefaults.colors(checkedThumbColor = PureBlack, checkedTrackColor = PureWhite),
          )
          IconButton(onClick = { onDeleteReminder(rem) }) {
            Icon(Icons.Rounded.Delete, contentDescription = "Удалить напоминание", tint = MidGray)
          }
        }
      }
    }

    // Backup & Restore + Local Wi-Fi / QR Transfer
    item {
      AzxCard(containerColor = AlmostBlack) {
        Text("Резервные копии и перенос", style = MaterialTheme.typography.titleMedium, color = PureWhite)
        Text(
          if (s.lastBackupAt > 0) "Последний бэкап: ${AzxRepository.formatDateShort(s.lastBackupAt)}"
          else "Проверка целостности SHA-256 и подтверждение перед заменой данных",
          style = MaterialTheme.typography.bodySmall,
          color = MidGray,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AzxPrimaryButton(
            text = "Экспорт файла",
            icon = Icons.Rounded.Backup,
            onClick = { exportBackupLauncher.launch("azx_v16_backup.json") },
            modifier = Modifier.weight(1f).testTag("export_backup_btn"),
          )
          AzxSecondaryButton(
            text = "Импорт файла",
            icon = Icons.Rounded.Restore,
            onClick = { importBackupLauncher.launch(arrayOf("application/json", "*/*")) },
            modifier = Modifier.weight(1f).testTag("import_backup_btn"),
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AzxSecondaryButton(
            text = "Отправить по Wi-Fi (QR)",
            icon = Icons.Rounded.QrCode2,
            enabled = !transferRunning,
            onClick = onStartWifiQrSender,
            modifier = Modifier.weight(1f),
          )
          AzxSecondaryButton(
            text = "Принять по Wi-Fi",
            icon = Icons.Rounded.Wifi,
            enabled = !transferRunning,
            onClick = { showReceiveDialog = true },
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    // Achievements summary in Profile
    item {
      AzxSectionHeader(
        title = "Достижения (${state.achievements.count { it.isUnlocked }}/${state.achievements.size})",
      )
      Spacer(modifier = Modifier.height(6.dp))
      val unlocked = state.achievements.filter { it.isUnlocked }
      if (unlocked.isEmpty()) {
        AzxCard {
          Text("Открытых достижений пока нет.", style = MaterialTheme.typography.bodySmall, color = MidGray)
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          unlocked.forEach { a ->
            AzxCard {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(a.title, style = MaterialTheme.typography.titleSmall, color = PureWhite)
                AzxBadge(text = "ОТКРЫТО", filled = true)
              }
            }
          }
        }
      }
      Spacer(modifier = Modifier.height(16.dp))
    }
  }

  // QR Sender Session Dialog
  if (transferSession != null) {
    AlertDialog(
      onDismissRequest = onCancelWifiQrSender,
      containerColor = Graphite,
      titleContentColor = PureWhite,
      title = { Text("Передача по локальному Wi-Fi") },
      text = {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Image(
            bitmap = transferSession.qrBitmap.asImageBitmap(),
            contentDescription = "QR-код для переноса данных AZX.V16",
            modifier = Modifier.size(210.dp),
          )
          Text(
            "IP: ${transferSession.ipAddress} • Порт: ${transferSession.port}",
            style = MaterialTheme.typography.labelMedium,
            color = PureWhite,
          )
          Text(
            "PIN: ${transferSession.pin}",
            style = MaterialTheme.typography.headlineSmall,
            color = PureWhite,
          )
          Text(
            "Открой AZX.V16 на втором устройстве (в той же Wi-Fi сети) -> Профиль -> Принять по Wi-Fi.",
            style = MaterialTheme.typography.bodySmall,
            color = LightGray,
          )
        }
      },
      confirmButton = {
        TextButton(onClick = onCancelWifiQrSender) { Text("ОТМЕНИТЬ", color = PureWhite) }
      },
    )
  }

  // Receive over Wi-Fi Dialog
  if (showReceiveDialog) {
    AlertDialog(
      onDismissRequest = { showReceiveDialog = false },
      containerColor = Graphite,
      titleContentColor = PureWhite,
      title = { Text("Принять копию по Wi-Fi") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          AzxSecondaryButton(
            text = "Сканировать QR-код",
            icon = Icons.Rounded.QrCodeScanner,
            onClick = { showQrScanner = true },
            modifier = Modifier.fillMaxWidth(),
          )
          OutlinedTextField(
            value = receiveIp,
            onValueChange = { receiveIp = it },
            label = { Text("IP адрес отправителя") },
            singleLine = true,
            colors = azxTextFieldColors(),
            modifier = Modifier.fillMaxWidth(),
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = receivePort,
              onValueChange = { receivePort = it.filter { c -> c.isDigit() } },
              label = { Text("Порт") },
              singleLine = true,
              colors = azxTextFieldColors(),
              modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
              value = receivePin,
              onValueChange = { receivePin = it.filter { c -> c.isDigit() } },
              label = { Text("PIN") },
              singleLine = true,
              colors = azxTextFieldColors(),
              modifier = Modifier.weight(1f),
            )
          }
        }
      },
      confirmButton = {
        TextButton(
          enabled = receiveIp.isNotBlank() && receivePort.toIntOrNull() != null && receivePin.isNotBlank(),
          onClick = {
            showReceiveDialog = false
            onReceiveFromWifi(receiveIp, receivePort.toInt(), receivePin)
          },
        ) {
          Text("ПОДКЛЮЧИТЬСЯ", color = PureWhite)
        }
      },
      dismissButton = {
        TextButton(onClick = { showReceiveDialog = false }) { Text("ОТМЕНА", color = LightGray) }
      },
    )
  }

  if (showQrScanner) {
    QrScannerDialog(
      onQrDecoded = { raw ->
        showQrScanner = false
        val parsed = LocalTransferManager.parseQrPayload(raw)
        if (parsed != null) {
          receiveIp = parsed.first
          receivePort = parsed.second.toString()
          receivePin = parsed.third
        } else {
          onShowMessage("QR-код не относится к AZX.V16.")
        }
      },
      onDismiss = { showQrScanner = false },
    )
  }

  // Backup Verification & Confirmation Dialog
  when (backupDialog) {
    is BackupDialogState.ConfirmRestore -> {
      val info = backupDialog.preview
      AlertDialog(
        onDismissRequest = onDismissBackupDialog,
        containerColor = Graphite,
        titleContentColor = PureWhite,
        title = { Text("Подтверждение замены данных") },
        text = {
          Text(
            "Целостность SHA-256 подтверждена (${backupDialog.sourceLabel}).\n\n" +
              "В копии:\n" +
              "• Задач: ${info.tasksCount}\n" +
              "• Целей: ${info.goalsCount}\n" +
              "• Тренировок: ${info.workoutsCount}\n" +
              "• Суммарный XP: ${info.xpTotal}\n\n" +
              "Заменить текущие данные на устройстве?",
            color = LightGray,
          )
        },
        confirmButton = {
          TextButton(onClick = { onConfirmRestore(info.snapshot) }) {
            Text("ЗАМЕНИТЬ ДАННЫЕ", color = PureWhite)
          }
        },
        dismissButton = {
          TextButton(onClick = onDismissBackupDialog) {
            Text("ОТМЕНА", color = LightGray)
          }
        },
      )
    }
    is BackupDialogState.Error -> {
      AlertDialog(
        onDismissRequest = onDismissBackupDialog,
        containerColor = Graphite,
        titleContentColor = PureWhite,
        title = { Text("Ошибка резервной копии") },
        text = { Text(backupDialog.message, color = LightGray) },
        confirmButton = {
          TextButton(onClick = onDismissBackupDialog) { Text("ПОНЯТНО", color = PureWhite) }
        },
      )
    }
    BackupDialogState.None -> Unit
  }
}
