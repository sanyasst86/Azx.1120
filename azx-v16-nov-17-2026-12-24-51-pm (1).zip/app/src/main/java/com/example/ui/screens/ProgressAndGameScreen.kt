package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.repository.AzxRepository
import com.example.domain.model.Direction
import com.example.ui.AzxUiState
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxChip
import com.example.ui.theme.AzxMonochromeBarChart
import com.example.ui.theme.AzxMonochromeLineChart
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxProgressBar
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.AzxSectionHeader
import com.example.ui.theme.DarkGray
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.MonochromeChartPoint
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

enum class StatsPeriod(val label: String, val days: Int) {
  DAY("День", 1),
  WEEK("Неделя", 7),
  MONTH("Месяц", 30),
  YEAR("Год", 365),
}

@Composable
fun ProgressAndGameScreen(
  state: AzxUiState,
  startInGameTab: Boolean = false,
  onExportPdf: (android.net.Uri, String, Int) -> Unit,
  onOpenGameStandalone: (() -> Unit)? = null,
  onBack: (() -> Unit)? = null,
) {
  var showGameView by remember(startInGameTab) { mutableStateOf(startInGameTab) }
  var period by remember { mutableStateOf(StatsPeriod.WEEK) }

  val pdfLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
      if (uri != null) {
        onExportPdf(uri, period.label, period.days)
      }
    }

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = PureWhite)
          }
        }
        Column {
          Text(
            if (showGameView) "GAME — УРОВНИ И МИССИИ" else "СТАТИСТИКА И ПРОГРЕСС",
            style = MaterialTheme.typography.headlineMedium,
            color = PureWhite,
          )
          Text("Только реальные данные • Чёрно-белые графики", style = MaterialTheme.typography.bodySmall, color = MidGray)
        }
      }
    }

    if (onBack == null) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        AzxChip(
          text = "Статистика и PDF",
          selected = !showGameView,
          onClick = { showGameView = false },
        )
        AzxChip(
          text = "GAME (XP и Миссии)",
          selected = showGameView,
          onClick = { showGameView = true },
        )
      }
      Spacer(modifier = Modifier.height(8.dp))
    }

    if (showGameView) {
      GameBody(state = state)
    } else {
      StatsBody(
        state = state,
        period = period,
        onPeriodChange = { period = it },
        onExportPdfClick = {
          val fileName = "AZX_V16_Stats_${period.name.lowercase()}.pdf"
          pdfLauncher.launch(fileName)
        },
        onOpenGame = onOpenGameStandalone ?: { showGameView = true },
      )
    }
  }
}

@Composable
private fun StatsBody(
  state: AzxUiState,
  period: StatsPeriod,
  onPeriodChange: (StatsPeriod) -> Unit,
  onExportPdfClick: () -> Unit,
  onOpenGame: () -> Unit,
) {
  val cutoffDay = state.todayEpoch - (period.days - 1)
  val cutoffMillis = AzxRepository.millisFromEpochDay(cutoffDay)

  val periodTasks = remember(state.tasks, cutoffDay) { state.tasks.filter { it.dateEpochDay >= cutoffDay } }
  val tasksDone = periodTasks.count { it.status == "DONE" }
  val workoutsPeriod = remember(state.workoutHistory, cutoffMillis) {
    state.workoutHistory.filter { it.completedAt >= cutoffMillis }
  }
  val basketballPeriod = workoutsPeriod.count { it.category == "BASKETBALL" }
  val habitsDonePeriod = remember(state.habitHistories, cutoffDay) {
    state.habitHistories.count { it.completed && it.dateEpochDay >= cutoffDay }
  }
  val xpPeriod = remember(state.xpTransactions, cutoffMillis) {
    state.xpTransactions.filter { it.createdAt >= cutoffMillis }.sumOf { it.amount }
  }

  val directionChartPoints =
    remember(periodTasks, workoutsPeriod) {
      Direction.entries.map { d ->
        val taskPts = periodTasks.count { it.direction == d.code && it.status == "DONE" }
        val workoutPts =
          when (d) {
            Direction.BODY -> workoutsPeriod.count { it.category != "BASKETBALL" }
            Direction.BASKETBALL -> workoutsPeriod.count { it.category == "BASKETBALL" }
            else -> 0
          }
        MonochromeChartPoint(
          label = d.title.take(4),
          value = (taskPts + workoutPts).toFloat(),
        )
      }
    }

  val xpTrendPoints =
    remember(state.xpTransactions, state.todayEpoch) {
      (6 downTo 0).map { offset ->
        val day = state.todayEpoch - offset
        val dayXp =
          state.xpTransactions
            .filter { AzxRepository.epochDayFromMillis(it.createdAt) == day }
            .sumOf { it.amount }
        MonochromeChartPoint(
          label = if (offset == 0) "Сег" else AzxRepository.formatEpochDay(day).take(2),
          value = dayXp.toFloat(),
        )
      }
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          StatsPeriod.entries.forEach { p ->
            AzxChip(text = p.label, selected = period == p, onClick = { onPeriodChange(p) })
          }
        }
        Spacer(modifier = Modifier.width(8.dp))
        AzxPrimaryButton(
          text = "PDF",
          icon = Icons.Rounded.PictureAsPdf,
          onClick = onExportPdfClick,
          modifier = Modifier.testTag("export_pdf_btn"),
        )
      }
    }

    item {
      AzxCard(containerColor = AlmostBlack) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          StatCell("Задачи", "$tasksDone / ${periodTasks.size}")
          StatCell("Тренировки", "${workoutsPeriod.size}")
          StatCell("Баскетбол", "$basketballPeriod")
          StatCell("Привычки", "$habitsDonePeriod")
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          StatCell("XP (${period.label})", "$xpPeriod")
          StatCell("Уровень", "${state.levelProgress.level}")
          StatCell("Цели", "${state.goals.count { it.isCompleted }}/${state.goals.size}")
          StatCell("Проекты", "${state.projects.count { it.status == "DONE" }}/${state.projects.size}")
        }
      }
    }

    item {
      AzxCard {
        Text("Активность по 7 направлениям (${period.label})", style = MaterialTheme.typography.titleMedium, color = PureWhite)
        Spacer(modifier = Modifier.height(10.dp))
        AzxMonochromeBarChart(points = directionChartPoints)
      }
    }

    item {
      AzxCard {
        Text("Динамика XP за 7 дней", style = MaterialTheme.typography.titleMedium, color = PureWhite)
        Spacer(modifier = Modifier.height(10.dp))
        AzxMonochromeLineChart(points = xpTrendPoints)
      }
    }

    item {
      AzxSecondaryButton(
        text = "Открыть GAME: миссии и достижения",
        icon = Icons.Rounded.SportsEsports,
        onClick = onOpenGame,
        modifier = Modifier.fillMaxWidth(),
      )
    }
  }
}

@Composable
private fun StatCell(label: String, value: String) {
  Column {
    Text(label, style = MaterialTheme.typography.labelSmall, color = MidGray)
    Text(value, style = MaterialTheme.typography.titleMedium, color = PureWhite)
  }
}

@Composable
private fun GameBody(state: AzxUiState) {
  val dailyMissions = remember(state.missions) { state.missions.filter { !it.isWeekly } }
  val weeklyMissions = remember(state.missions) { state.missions.filter { it.isWeekly } }
  val rewards =
    remember(state.levelProgress.level) {
      listOf(
        2 to "Ранг ИНИЦИАТОР: разблокирован контроль ритма дня",
        5 to "Ранг АТЛЕТ: стабильная база 500+ XP",
        10 to "Ранг СТРАТЕГ: высокий уровень планирования и проектов",
        15 to "Ранг ДИСЦИПЛИНА: мастерство серий без срывов",
        22 to "Ранг ПРАЙМ: элитный баланс тела, ума и творчества",
      )
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      AzxCard(containerColor = AlmostBlack) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              "УРОВЕНЬ ${state.levelProgress.level} • ${state.levelProgress.rankTitle}",
              style = MaterialTheme.typography.headlineSmall,
              color = PureWhite,
            )
            Text(
              "Всего XP: ${state.totalXp} • До следующего: ${state.levelProgress.nextLevelXp - state.totalXp} XP",
              style = MaterialTheme.typography.bodySmall,
              color = LightGray,
            )
          }
          AzxBadge(text = "STREAK ${state.streakDays}д", filled = true)
        }
        Spacer(modifier = Modifier.height(10.dp))
        AzxProgressBar(progress = state.levelProgress.progressFraction, heightDp = 10)
      }
    }

    item {
      AzxSectionHeader(title = "Ежедневные миссии (${dailyMissions.count { it.isCompleted }}/${dailyMissions.size})")
    }
    items(dailyMissions, key = { it.id }) { m ->
      AzxCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Column(modifier = Modifier.weight(1f)) {
            Text(m.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
            Text(m.description, style = MaterialTheme.typography.bodySmall, color = MidGray)
          }
          AzxBadge(text = "${m.currentCount}/${m.targetCount} • +${m.xpReward} XP", filled = m.isCompleted)
        }
        Spacer(modifier = Modifier.height(6.dp))
        AzxProgressBar(progress = m.currentCount.toFloat() / m.targetCount.coerceAtLeast(1))
      }
    }

    item {
      AzxSectionHeader(title = "Недельные испытания (${weeklyMissions.count { it.isCompleted }}/${weeklyMissions.size})")
    }
    items(weeklyMissions, key = { it.id }) { m ->
      AzxCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Column(modifier = Modifier.weight(1f)) {
            Text(m.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
            Text(m.description, style = MaterialTheme.typography.bodySmall, color = MidGray)
          }
          AzxBadge(text = "${m.currentCount}/${m.targetCount} • +${m.xpReward} XP", filled = m.isCompleted)
        }
        Spacer(modifier = Modifier.height(6.dp))
        AzxProgressBar(progress = m.currentCount.toFloat() / m.targetCount.coerceAtLeast(1))
      }
    }

    item {
      AzxSectionHeader(
        title = "Достижения (${state.achievements.count { it.isUnlocked }}/${state.achievements.size})",
      )
    }
    items(state.achievements, key = { it.id }) { ach ->
      AzxCard(
        containerColor = if (ach.isUnlocked) AlmostBlack else com.example.ui.theme.Graphite,
        borderColor = if (ach.isUnlocked) PureWhite else DarkGray,
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(ach.title, style = MaterialTheme.typography.titleMedium, color = if (ach.isUnlocked) PureWhite else LightGray)
            Text(ach.description, style = MaterialTheme.typography.bodySmall, color = MidGray)
          }
          AzxBadge(
            text = if (ach.isUnlocked) "ОТКРЫТО +${ach.xpReward}" else "${ach.xpReward} XP",
            filled = ach.isUnlocked,
          )
        }
      }
    }

    item {
      AzxSectionHeader(title = "Награды и ранги")
    }
    items(rewards) { (lvl, text) ->
      val reached = state.levelProgress.level >= lvl
      AzxCard(borderColor = if (reached) PureWhite else DarkGray) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text(text, style = MaterialTheme.typography.bodyMedium, color = if (reached) PureWhite else MidGray, modifier = Modifier.weight(1f))
          AzxBadge(text = "LVL $lvl", filled = reached)
        }
      }
    }

    item {
      AzxSectionHeader(title = "История XP (${state.xpTransactions.size})")
    }
    if (state.xpTransactions.isEmpty()) {
      item {
        AzxCard {
          Text(
            "XP начисляется только за реальные выполненные действия. За открытие приложения XP не начисляется.",
            style = MaterialTheme.typography.bodySmall,
            color = MidGray,
          )
        }
      }
    } else {
      items(state.xpTransactions.take(25), key = { it.id }) { tx ->
        AzxCard {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(modifier = Modifier.weight(1f)) {
              Text(tx.description, style = MaterialTheme.typography.bodyMedium, color = PureWhite)
              Text("${tx.sourceType} • ${AzxRepository.formatDateShort(tx.createdAt)}", style = MaterialTheme.typography.labelSmall, color = MidGray)
            }
            AzxBadge(text = "+${tx.amount} XP", filled = true)
          }
        }
      }
    }
  }
}
