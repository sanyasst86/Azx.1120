package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.ProjectStepEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.repository.AzxRepository
import com.example.domain.model.Direction
import com.example.ui.AzxUiState
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxBadge
import com.example.ui.theme.AzxCard
import com.example.ui.theme.AzxChip
import com.example.ui.theme.AzxEmptyState
import com.example.ui.theme.AzxPrimaryButton
import com.example.ui.theme.AzxProgressBar
import com.example.ui.theme.AzxSecondaryButton
import com.example.ui.theme.AzxSectionHeader
import com.example.ui.theme.DarkGray
import com.example.ui.theme.Graphite
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

private val projectCategories =
  listOf(
    "CAR_PHOTO" to "Автофотография",
    "VIDEO_EDIT" to "Видеомонтаж (CapCut)",
    "CONTENT" to "Создание контента",
    "OTHER" to "Другой проект",
  )

@Composable
fun ProjectsScreen(
  state: AzxUiState,
  onSaveProject: (ProjectEntity, List<String>) -> Unit,
  onDeleteProject: (ProjectEntity) -> Unit,
  onAddProjectStep: (Long, String) -> Unit,
  onToggleProjectStep: (ProjectStepEntity) -> Unit,
  onDeleteProjectStep: (ProjectStepEntity) -> Unit,
  onBack: () -> Unit,
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var prefillCategory by remember { mutableStateOf("CAR_PHOTO") }
  var expandedProjectId by remember { mutableStateOf<Long?>(null) }
  var newStepText by remember { mutableStateOf("") }
  var noteEditText by remember { mutableStateOf("") }

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = PureWhite)
        }
        Column {
          Text("PROJECTS — ТВОРЧЕСТВО", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
          Text("Автосъёмка • CapCut • Контент • Этапы", style = MaterialTheme.typography.bodySmall, color = MidGray)
        }
      }
      AzxPrimaryButton(
        text = "+ Проект",
        onClick = {
          prefillCategory = "CAR_PHOTO"
          showCreateDialog = true
        },
      )
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Specialized quick templates for Car Photo, CapCut Editing, and Content
      item {
        Text("Специализированные направления проектов", style = MaterialTheme.typography.titleSmall, color = LightGray)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          AzxSecondaryButton(
            text = "Автофотосъёмка",
            icon = Icons.Rounded.CameraAlt,
            onClick = {
              prefillCategory = "CAR_PHOTO"
              showCreateDialog = true
            },
          )
          AzxSecondaryButton(
            text = "Видеомонтаж CapCut",
            icon = Icons.Rounded.Movie,
            onClick = {
              prefillCategory = "VIDEO_EDIT"
              showCreateDialog = true
            },
          )
          AzxSecondaryButton(
            text = "Создание контента",
            icon = Icons.Rounded.Videocam,
            onClick = {
              prefillCategory = "CONTENT"
              showCreateDialog = true
            },
          )
        }
      }

      if (state.projects.isEmpty()) {
        item {
          AzxEmptyState(
            icon = Icons.Rounded.Videocam,
            title = "Проектов пока нет",
            description = "Создай проект для автосъёмки, видеомонтажа в CapCut или серии контента с готовыми этапами.",
            actionLabel = "Создать проект",
            onAction = { showCreateDialog = true },
          )
        }
      } else {
        items(state.projects, key = { it.id }) { proj ->
          val steps = state.projectSteps.filter { it.projectId == proj.id }
          val expanded = expandedProjectId == proj.id
          val catTitle = projectCategories.find { it.first == proj.category }?.second ?: proj.category
          AzxCard(
            onClick = {
              expandedProjectId = if (expanded) null else proj.id
              noteEditText = proj.notes
            },
            borderColor = if (expanded) PureWhite else DarkGray,
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  AzxBadge(text = catTitle)
                  Spacer(modifier = Modifier.width(6.dp))
                  AzxBadge(text = if (proj.status == "DONE") "ГОТОВ" else "В РАБОТЕ", filled = proj.status == "DONE")
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(proj.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                Text(
                  "Срок: ${AzxRepository.formatEpochDay(proj.deadlineEpochDay)} • Этапы: ${steps.count { it.isDone }}/${steps.size}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MidGray,
                )
              }
              AzxBadge(text = "${proj.progressPercent}%", filled = proj.progressPercent == 100)
            }
            Spacer(modifier = Modifier.height(8.dp))
            AzxProgressBar(progress = proj.progressPercent / 100f)

            if (expanded) {
              Spacer(modifier = Modifier.height(10.dp))
              if (proj.description.isNotBlank()) {
                Text(proj.description, style = MaterialTheme.typography.bodySmall, color = LightGray)
                Spacer(modifier = Modifier.height(6.dp))
              }
              steps.forEach { step ->
                Row(
                  modifier = Modifier.fillMaxWidth().clickable { onToggleProjectStep(step) },
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Checkbox(
                    checked = step.isDone,
                    onCheckedChange = { onToggleProjectStep(step) },
                    colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
                  )
                  Text(
                    text = step.title,
                    style =
                      MaterialTheme.typography.bodyMedium.copy(
                        textDecoration = if (step.isDone) TextDecoration.LineThrough else TextDecoration.None,
                      ),
                    color = if (step.isDone) MidGray else PureWhite,
                    modifier = Modifier.weight(1f),
                  )
                  IconButton(onClick = { onDeleteProjectStep(step) }) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Удалить этап", tint = MidGray)
                  }
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                OutlinedTextField(
                  value = newStepText,
                  onValueChange = { newStepText = it },
                  label = { Text("Новый этап") },
                  singleLine = true,
                  colors = azxTextFieldColors(),
                  modifier = Modifier.weight(1f),
                )
                Spacer(modifier = Modifier.width(6.dp))
                AzxSecondaryButton(
                  text = "+",
                  enabled = newStepText.isNotBlank(),
                  onClick = {
                    onAddProjectStep(proj.id, newStepText)
                    newStepText = ""
                  },
                )
              }

              Spacer(modifier = Modifier.height(8.dp))
              OutlinedTextField(
                value = noteEditText,
                onValueChange = { noteEditText = it },
                label = { Text("Заметки (ракурсы, LUT, музыка, идеи)") },
                colors = azxTextFieldColors(),
                modifier = Modifier.fillMaxWidth(),
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                AzxSecondaryButton(
                  text = "Сохранить заметки",
                  onClick = {
                    onSaveProject(proj.copy(notes = noteEditText.trim()), emptyList())
                  },
                )
                IconButton(onClick = { onDeleteProject(proj) }) {
                  Icon(Icons.Rounded.Delete, contentDescription = "Удалить проект", tint = MidGray)
                }
              }

              if (proj.historyLog.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text("История изменений:", style = MaterialTheme.typography.labelSmall, color = MidGray)
                Text(proj.historyLog, style = MaterialTheme.typography.bodySmall, color = MidGray)
              }
            }
          }
        }
      }
    }
  }

  if (showCreateDialog) {
    CreateProjectDialog(
      defaultCategory = prefillCategory,
      onDismiss = { showCreateDialog = false },
      onSave = onSaveProject,
    )
  }
}

@Composable
private fun CreateProjectDialog(
  defaultCategory: String,
  onDismiss: () -> Unit,
  onSave: (ProjectEntity, List<String>) -> Unit,
) {
  var category by remember { mutableStateOf(defaultCategory) }
  var title by remember { mutableStateOf("") }
  var description by remember { mutableStateOf("") }
  val suggestedSteps =
    when (category) {
      "CAR_PHOTO" -> listOf("Выбор локации и света", "Подбор ракурсов и деталей", "Съёмка серии", "Цветокоррекция и отбор")
      "VIDEO_EDIT" -> listOf("Сбор исходников", "Черновая склейка в CapCut", "Саунд-дизайн и переходы", "Цветокор и экспорт 1080p/4K")
      "CONTENT" -> listOf("Идея и хук первых 3 сек", "Сценарий и список кадров", "Съёмка и монтаж", "Публикация и разбор")
      else -> listOf("План проекта", "Реализация", "Финальная проверка")
    }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Graphite,
    titleContentColor = PureWhite,
    title = { Text("Новый проект") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          projectCategories.forEach { (code, lbl) ->
            AzxChip(text = lbl, selected = category == code, onClick = { category = code })
          }
        }
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Название проекта") },
          singleLine = true,
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Описание / референсы") },
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Text("Авто-этапы (${suggestedSteps.size}): ${suggestedSteps.joinToString(" -> ")}", style = MaterialTheme.typography.bodySmall, color = LightGray)
      }
    },
    confirmButton = {
      TextButton(
        enabled = title.isNotBlank(),
        onClick = {
          onSave(
            ProjectEntity(
              title = title.trim(),
              category = category,
              description = description.trim(),
              deadlineEpochDay = AzxRepository.todayEpochDay() + 14,
            ),
            suggestedSteps,
          )
          onDismiss()
        },
      ) {
        Text("СОЗДАТЬ", color = if (title.isNotBlank()) PureWhite else MidGray)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("ОТМЕНА", color = LightGray) }
    },
  )
}

private val lifeSkillCategories =
  listOf(
    "Самостоятельность",
    "Организация",
    "Бытовые навыки",
    "Финансовая грамотность",
    "Планирование",
    "Ответственность",
  )

@Composable
fun LifeSkillsScreen(
  state: AzxUiState,
  onSaveTask: (TaskEntity) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onSaveGoal: (GoalEntity, List<String>) -> Unit,
  onBack: () -> Unit,
) {
  var selectedCat by remember { mutableStateOf(lifeSkillCategories.first()) }
  var showAddTask by remember { mutableStateOf(false) }
  var showAddGoal by remember { mutableStateOf(false) }

  val lsTasks = remember(state.tasks) { state.tasks.filter { it.direction == "LIFE_SKILLS" } }
  val lsGoals = remember(state.goals) { state.goals.filter { it.direction == "LIFE_SKILLS" } }
  val doneCount = lsTasks.count { it.status == "DONE" }
  val progress = if (lsTasks.isEmpty()) 0f else (doneCount.toFloat() / lsTasks.size).coerceIn(0f, 1f)

  Column(modifier = Modifier.fillMaxSize().background(PureBlack)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = PureWhite)
      }
      Column {
        Text("LIFE SKILLS — ЖИЗНЕННЫЕ НАВЫКИ", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
        Text("Самостоятельность • Быт • Финансы • Ответственность", style = MaterialTheme.typography.bodySmall, color = MidGray)
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        AzxCard(containerColor = AlmostBlack) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("Прогресс навыков", style = MaterialTheme.typography.titleMedium, color = PureWhite)
            AzxBadge(text = "${(progress * 100).toInt()}%", filled = true)
          }
          Spacer(modifier = Modifier.height(8.dp))
          AzxProgressBar(progress = progress)
          Spacer(modifier = Modifier.height(10.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AzxPrimaryButton(text = "+ Задача", icon = Icons.Rounded.Add, onClick = { showAddTask = true }, modifier = Modifier.weight(1f))
            AzxSecondaryButton(text = "+ Цель", icon = Icons.Rounded.Add, onClick = { showAddGoal = true }, modifier = Modifier.weight(1f))
          }
        }
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          lifeSkillCategories.forEach { cat ->
            AzxChip(text = cat, selected = selectedCat == cat, onClick = { selectedCat = cat })
          }
        }
      }

      item {
        val quickPractice =
          when (selectedCat) {
            "Финансовая грамотность" -> "Записать все расходы и накопления за неделю"
            "Бытовые навыки" -> "Приготовить полезный завтрак и убрать кухню за собой"
            "Самостоятельность" -> "Собрать портфель и форму с вечера без напоминаний"
            "Организация" -> "Разобрать файлы, рюкзак и порядок на столе"
            "Планирование" -> "Составить бюджет времени на выходные"
            else -> "Выполнить взятое на себя обещание в срок"
          }
        AzxSecondaryButton(
          text = "+ Практика ($selectedCat): $quickPractice",
          onClick = {
            onSaveTask(
              TaskEntity(
                title = quickPractice,
                description = selectedCat,
                direction = "LIFE_SKILLS",
                dateEpochDay = state.todayEpoch,
              ),
            )
          },
          modifier = Modifier.fillMaxWidth(),
        )
      }

      if (lsGoals.isNotEmpty()) {
        item { AzxSectionHeader(title = "Цели Life Skills (${lsGoals.size})") }
        items(lsGoals, key = { it.id }) { g ->
          AzxCard {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(g.title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
              AzxBadge(text = "${g.progressPercent}%")
            }
            Spacer(modifier = Modifier.height(6.dp))
            AzxProgressBar(progress = g.progressPercent / 100f)
          }
        }
      }

      item { AzxSectionHeader(title = "Задачи Life Skills (${lsTasks.size})") }
      items(lsTasks, key = { it.id }) { t ->
        AzxCard(onClick = { onToggleTask(t) }) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
              checked = t.status == "DONE",
              onCheckedChange = { onToggleTask(t) },
              colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(t.title, style = MaterialTheme.typography.titleSmall, color = PureWhite)
              if (t.description.isNotBlank()) {
                Text(t.description, style = MaterialTheme.typography.bodySmall, color = MidGray)
              }
            }
          }
        }
      }
    }
  }

  if (showAddTask) {
    TaskEditorDialog(
      defaultDirection = Direction.LIFE_SKILLS,
      goals = state.goals,
      onDismiss = { showAddTask = false },
      onSave = onSaveTask,
    )
  }
  if (showAddGoal) {
    GoalEditorDialog(
      defaultDirection = Direction.LIFE_SKILLS,
      onDismiss = { showAddGoal = false },
      onSave = onSaveGoal,
    )
  }
}
