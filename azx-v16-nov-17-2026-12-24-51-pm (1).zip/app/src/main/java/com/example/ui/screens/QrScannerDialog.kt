package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.Graphite
import com.example.ui.theme.LightGray
import com.example.ui.theme.PureWhite
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.util.concurrent.Executors

@Composable
fun QrScannerDialog(
  onQrDecoded: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  var hasPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
        PackageManager.PERMISSION_GRANTED,
    )
  }
  val permissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      hasPermission = granted
    }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Graphite,
    titleContentColor = PureWhite,
    title = { Text("Сканер QR для передачи по Wi-Fi") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!hasPermission) {
          Text(
            "Для сканирования QR-кода с другого устройства нужен доступ к камере. Либо введи IP, порт и PIN вручную.",
            style = MaterialTheme.typography.bodySmall,
            color = LightGray,
          )
          TextButton(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
            Text("РАЗРЕШИТЬ КАМЕРУ", color = PureWhite)
          }
        } else {
          val executor = remember { Executors.newSingleThreadExecutor() }
          var decodedOnce by remember { mutableStateOf(false) }

          DisposableEffect(Unit) {
            onDispose { executor.shutdown() }
          }

          AndroidView(
            modifier = Modifier.fillMaxWidth().height(260.dp),
            factory = { ctx ->
              val previewView = PreviewView(ctx)
              val future = ProcessCameraProvider.getInstance(ctx)
              future.addListener(
                {
                  val provider = future.get()
                  val preview =
                    Preview.Builder().build().also {
                      it.surfaceProvider = previewView.surfaceProvider
                    }
                  val analyzer =
                    ImageAnalysis.Builder()
                      .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                      .build()
                      .also { analysis ->
                        analysis.setAnalyzer(executor) { image ->
                          if (!decodedOnce) {
                            decodeQrFromImage(image)?.let { code ->
                              decodedOnce = true
                              previewView.post { onQrDecoded(code) }
                            }
                          }
                          image.close()
                        }
                      }
                  runCatching {
                    provider.unbindAll()
                    provider.bindToLifecycle(
                      lifecycleOwner,
                      CameraSelector.DEFAULT_BACK_CAMERA,
                      preview,
                      analyzer,
                    )
                  }
                },
                ContextCompat.getMainExecutor(ctx),
              )
              previewView
            },
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            "Наведи камеру на QR-код, показанный на первом устройстве.",
            style = MaterialTheme.typography.bodySmall,
            color = LightGray,
          )
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("ЗАКРЫТЬ", color = PureWhite) }
    },
  )
}

private fun decodeQrFromImage(image: ImageProxy): String? {
  return try {
    val plane = image.planes.firstOrNull() ?: return null
    val buffer = plane.buffer
    val data = ByteArray(buffer.remaining())
    buffer.get(data)
    val source =
      PlanarYUVLuminanceSource(
        data,
        image.width,
        image.height,
        0,
        0,
        image.width,
        image.height,
        false,
      )
    val bitmap = BinaryBitmap(HybridBinarizer(source))
    MultiFormatReader().decode(bitmap).text
  } catch (_: Exception) {
    null
  }
}
