package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.repository.AzxRepository
import com.example.domain.model.Direction
import com.example.ui.theme.AlmostBlack
import com.example.ui.theme.AzxChip
import com.example.ui.theme.DarkGray
import com.example.ui.theme.Graphite
import com.example.ui.theme.LightGray
import com.example.ui.theme.MidGray
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun azxTextFieldColors() =
  OutlinedTextFieldDefaults.colors(
    focusedTextColor = PureWhite,
    unfocusedTextColor = PureWhite,
    focusedBorderColor = PureWhite,
    unfocusedBorderColor = DarkGray,
    focusedLabelColor = PureWhite,
    unfocusedLabelColor = MidGray,
    cursorColor = PureWhite,
    focusedContainerColor = AlmostBlack,
    unfocusedContainerColor = AlmostBlack,
  )

@Composable
fun TaskEditorDialog(
  initialTask: TaskEntity? = null,
  defaultDirection: Direction = Direction.DISCIPLINE,
  defaultEpochDay: Long = AzxRepository.todayEpochDay(),
  goals: List<GoalEntity>,
  onDismiss: () -> Unit,
  onSave: (TaskEntity) -> Unit,
) {
  var title by remember { mutableStateOf(initialTask?.title ?: "") }
  var description by remember { mutableStateOf(initialTask?.description ?: "") }
  var direction by remember {
    mutableStateOf(
      Direction.entries.find { it.code == initialTask?.direction } ?: defaultDirection,
    )
  }
  var dayOffset by remember {
    mutableIntStateOf(
      ((initialTask?.dateEpochDay ?: defaultEpochDay) - AzxRepository.todayEpochDay()).toInt()
        .coerceIn(0, 7),
    )
  }
  var hour by remember {
    mutableIntStateOf((initialTask?.timeMinutes ?: 17 * 60) / 60)
  }
  var minute by remember {
    mutableIntStateOf((initialTask?.timeMinutes ?: 17 * 60) % 60)
  }
  var hasTime by remember { mutableStateOf(initialTask?.timeMinutes != null) }
  var priority by remember { mutableIntStateOf(initialTask?.priority ?: 2) }
  var repeatRule by remember { mutableStateOf(initialTask?.repeatRule ?: "NONE") }
  var reminderEnabled by remember { mutableStateOf(initialTask?.reminderEnabled ?: false) }
  var selectedGoalId by remember { mutableStateOf(initialTask?.goalId) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Graphite,
    titleContentColor = PureWhite,
    title = {
      Text(if (initialTask == null) "Новая задача" else "Редактировать задачу")
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Название задачи") },
          singleLine = true,
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Описание / заметка") },
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )

        Text("Направление", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Direction.entries.forEach { d ->
            AzxChip(
              text = d.title,
              selected = direction == d,
              onClick = { direction = d },
            )
          }
        }

        Text("Дата", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          listOf(0 to "Сегодня", 1 to "Завтра", 2 to "+2 дня", 7 to "Через неделю").forEach { (off, label) ->
            AzxChip(text = label, selected = dayOffset == off, onClick = { dayOffset = off })
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Checkbox(
            checked = hasTime,
            onCheckedChange = { hasTime = it },
            colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
          )
          Text("Задать время (${"%02d:%02d".format(hour, minute)})", color = PureWhite)
        }
        if (hasTime) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(8, 16, 18, 20).forEach { h ->
              AzxChip(
                text = "${"%02d".format(h)}:00",
                selected = hour == h && minute == 0,
                onClick = {
                  hour = h
                  minute = 0
                },
              )
            }
          }
        }

        Text("Приоритет", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf(1 to "Низкий", 2 to "Средний", 3 to "Высокий").forEach { (p, lbl) ->
            AzxChip(text = lbl, selected = priority == p, onClick = { priority = p })
          }
        }

        Text("Повтор", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("NONE" to "Нет", "DAILY" to "Ежедневно", "WEEKLY" to "Еженедельно").forEach { (r, lbl) ->
            AzxChip(text = lbl, selected = repeatRule == r, onClick = { repeatRule = r })
          }
        }

        if (goals.isNotEmpty()) {
          Text("Привязка к цели", style = MaterialTheme.typography.labelMedium, color = LightGray)
          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            AzxChip(
              text = "Без цели",
              selected = selectedGoalId == null,
              onClick = { selectedGoalId = null },
            )
            goals.filter { !it.isCompleted }.forEach { g ->
              AzxChip(
                text = g.title.take(18),
                selected = selectedGoalId == g.id,
                onClick = { selectedGoalId = g.id },
              )
            }
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Checkbox(
            checked = reminderEnabled,
            onCheckedChange = {
              reminderEnabled = it
              if (it) hasTime = true
            },
            colors = CheckboxDefaults.colors(checkedColor = PureWhite, checkmarkColor = PureBlack),
          )
          Text("Напоминание-уведомление", color = PureWhite)
        }
      }
    },
    confirmButton = {
      TextButton(
        enabled = title.isNotBlank(),
        onClick = {
          val today = AzxRepository.todayEpochDay()
          val task =
            (initialTask ?: TaskEntity(title = title.trim(), dateEpochDay = today + dayOffset))
              .copy(
                title = title.trim(),
                description = description.trim(),
                direction = direction.code,
                dateEpochDay = today + dayOffset,
                timeMinutes = if (hasTime) hour * 60 + minute else null,
                priority = priority,
                repeatRule = repeatRule,
                reminderEnabled = reminderEnabled,
                goalId = selectedGoalId,
              )
          onSave(task)
          onDismiss()
        },
      ) {
        Text("СОХРАНИТЬ", color = if (title.isNotBlank()) PureWhite else MidGray)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("ОТМЕНА", color = LightGray)
      }
    },
  )
}

@Composable
fun GoalEditorDialog(
  initialGoal: GoalEntity? = null,
  defaultDirection: Direction = Direction.BODY,
  onDismiss: () -> Unit,
  onSave: (GoalEntity, List<String>) -> Unit,
) {
  var title by remember { mutableStateOf(initialGoal?.title ?: "") }
  var description by remember { mutableStateOf(initialGoal?.description ?: "") }
  var direction by remember {
    mutableStateOf(
      Direction.entries.find { it.code == initialGoal?.direction } ?: defaultDirection,
    )
  }
  var priority by remember { mutableIntStateOf(initialGoal?.priority ?: 2) }
  var deadlineDays by remember { mutableIntStateOf(14) }
  var subtasksText by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Graphite,
    titleContentColor = PureWhite,
    title = { Text(if (initialGoal == null) "Новая цель" else "Редактировать цель") },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Название цели") },
          singleLine = true,
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Зачем это нужно / критерий успеха") },
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Text("Направление", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Direction.entries.forEach { d ->
            AzxChip(text = d.title, selected = direction == d, onClick = { direction = d })
          }
        }
        Text("Приоритет", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf(1 to "Низкий", 2 to "Средний", 3 to "Высокий").forEach { (p, lbl) ->
            AzxChip(text = lbl, selected = priority == p, onClick = { priority = p })
          }
        }
        Text("Дедлайн", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          listOf(7 to "7 дн", 14 to "14 дн", 30 to "30 дн", 90 to "90 дн").forEach { (d, lbl) ->
            AzxChip(text = lbl, selected = deadlineDays == d, onClick = { deadlineDays = d })
          }
        }
        if (initialGoal == null) {
          OutlinedTextField(
            value = subtasksText,
            onValueChange = { subtasksText = it },
            label = { Text("Подзадачи (каждая с новой строки)") },
            minLines = 2,
            colors = azxTextFieldColors(),
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }
    },
    confirmButton = {
      TextButton(
        enabled = title.isNotBlank(),
        onClick = {
          val deadline =
            initialGoal?.deadlineEpochDay ?: (AzxRepository.todayEpochDay() + deadlineDays)
          val g =
            (initialGoal
              ?: GoalEntity(
                title = title.trim(),
                direction = direction.code,
                deadlineEpochDay = deadline,
              ))
              .copy(
                title = title.trim(),
                description = description.trim(),
                direction = direction.code,
                priority = priority,
                deadlineEpochDay = deadline,
              )
          val subs = subtasksText.lines().map { it.trim() }.filter { it.isNotEmpty() }
          onSave(g, subs)
          onDismiss()
        },
      ) {
        Text("СОХРАНИТЬ", color = if (title.isNotBlank()) PureWhite else MidGray)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("ОТМЕНА", color = LightGray) }
    },
  )
}

@Composable
fun HabitEditorDialog(
  initialHabit: HabitEntity? = null,
  defaultDirection: Direction = Direction.DISCIPLINE,
  onDismiss: () -> Unit,
  onSave: (HabitEntity) -> Unit,
) {
  var title by remember { mutableStateOf(initialHabit?.title ?: "") }
  var direction by remember {
    mutableStateOf(
      Direction.entries.find { it.code == initialHabit?.direction } ?: defaultDirection,
    )
  }
  var targetPerWeek by remember { mutableIntStateOf(initialHabit?.targetPerWeek ?: 5) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Graphite,
    titleContentColor = PureWhite,
    title = { Text(if (initialHabit == null) "Новая привычка" else "Редактировать привычку") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Название привычки") },
          singleLine = true,
          colors = azxTextFieldColors(),
          modifier = Modifier.fillMaxWidth(),
        )
        Text("Направление", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Direction.entries.forEach { d ->
            AzxChip(text = d.title, selected = direction == d, onClick = { direction = d })
          }
        }
        Text("Цель в неделю", style = MaterialTheme.typography.labelMedium, color = LightGray)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf(3, 5, 7).forEach { cnt ->
            AzxChip(
              text = "$cnt раз",
              selected = targetPerWeek == cnt,
              onClick = { targetPerWeek = cnt },
            )
          }
        }
      }
    },
    confirmButton = {
      TextButton(
        enabled = title.isNotBlank(),
        onClick = {
          val h =
            (initialHabit ?: HabitEntity(title = title.trim(), direction = direction.code)).copy(
              title = title.trim(),
              direction = direction.code,
              targetPerWeek = targetPerWeek,
            )
          onSave(h)
          onDismiss()
        },
      ) {
        Text("СОХРАНИТЬ", color = if (title.isNotBlank()) PureWhite else MidGray)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("ОТМЕНА", color = LightGray) }
    },
  )
}
