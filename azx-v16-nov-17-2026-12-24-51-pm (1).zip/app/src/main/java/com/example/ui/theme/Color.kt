package com.example.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Строгая палитра PREMIUM AMOLED DARK для AZX.V16.
 * Никаких цветных акцентов в общем интерфейсе.
 */
val PureBlack = Color(0xFF000000)
val AlmostBlack = Color(0xFF101010)
val Graphite = Color(0xFF1A1A1A)
val DarkGray = Color(0xFF303030)
val MidGray = Color(0xFF777777)
val LightGray = Color(0xFFBDBDBD)
val PureWhite = Color(0xFFFFFFFF)

/**
 * Красный цвет разрешён ИСКЛЮЧИТЕЛЬНО для подсветки выбранных/тренируемых мышц
 * внутри 3D-модуля мышечной анатомии.
 */
object AnatomyModuleColors {
  val SelectedMuscleRed = Color(0xFFD91622)
  val SecondaryMuscleRed = Color(0xFF8C1D24)
}
