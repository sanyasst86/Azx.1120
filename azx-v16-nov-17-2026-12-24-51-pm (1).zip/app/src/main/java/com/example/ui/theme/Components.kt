package com.example.ui.theme

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun AzxCard(
  modifier: Modifier = Modifier,
  onClick: (() -> Unit)? = null,
  containerColor: Color = Graphite,
  borderColor: Color = DarkGray,
  contentPadding: PaddingValues = PaddingValues(16.dp),
  content: @Composable ColumnScope.() -> Unit,
) {
  val shape = RoundedCornerShape(16.dp)
  val cardModifier =
    modifier
      .fillMaxWidth()
      .clip(shape)
      .then(
        if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
      )
  Surface(
    modifier = cardModifier,
    shape = shape,
    color = containerColor,
    border = BorderStroke(1.dp, borderColor),
  ) {
    Column(modifier = Modifier.padding(contentPadding), content = content)
  }
}

@Composable
fun AzxPrimaryButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  icon: ImageVector? = null,
) {
  Button(
    onClick = onClick,
    enabled = enabled,
    modifier = modifier.defaultMinSize(minHeight = 48.dp),
    shape = RoundedCornerShape(12.dp),
    colors =
      ButtonDefaults.buttonColors(
        containerColor = PureWhite,
        contentColor = PureBlack,
        disabledContainerColor = DarkGray,
        disabledContentColor = MidGray,
      ),
    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
  ) {
    if (icon != null) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
    }
    Text(
      text = text,
      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun AzxSecondaryButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  icon: ImageVector? = null,
) {
  OutlinedButton(
    onClick = onClick,
    enabled = enabled,
    modifier = modifier.defaultMinSize(minHeight = 48.dp),
    shape = RoundedCornerShape(12.dp),
    border = BorderStroke(1.dp, if (enabled) LightGray else DarkGray),
    colors =
      ButtonDefaults.outlinedButtonColors(
        containerColor = AlmostBlack,
        contentColor = PureWhite,
        disabledContentColor = MidGray,
      ),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
  ) {
    if (icon != null) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
    }
    Text(
      text = text,
      style = MaterialTheme.typography.titleSmall,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun AzxBadge(
  text: String,
  modifier: Modifier = Modifier,
  filled: Boolean = false,
) {
  val bg = if (filled) PureWhite else AlmostBlack
  val fg = if (filled) PureBlack else LightGray
  val border = if (filled) PureWhite else DarkGray
  Box(
    modifier =
      modifier
        .clip(RoundedCornerShape(8.dp))
        .background(bg)
        .border(1.dp, border, RoundedCornerShape(8.dp))
        .padding(horizontal = 8.dp, vertical = 4.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      color = fg,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun AzxChip(
  text: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val bg = if (selected) PureWhite else Graphite
  val fg = if (selected) PureBlack else LightGray
  val border = if (selected) PureWhite else DarkGray
  Box(
    modifier =
      modifier
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(10.dp))
        .background(bg)
        .border(1.dp, border, RoundedCornerShape(10.dp))
        .clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 10.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
      color = fg,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun AzxProgressBar(
  progress: Float,
  modifier: Modifier = Modifier,
  heightDp: Int = 8,
) {
  val animated by animateFloatAsState(
    targetValue = progress.coerceIn(0f, 1f),
    animationSpec = tween(durationMillis = 350),
    label = "azx_progress",
  )
  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .height(heightDp.dp)
        .clip(RoundedCornerShape(99.dp))
        .background(DarkGray),
  ) {
    if (animated > 0f) {
      Box(
        modifier =
          Modifier
            .fillMaxWidth(animated)
            .height(heightDp.dp)
            .clip(RoundedCornerShape(99.dp))
            .background(PureWhite),
      )
    }
  }
}

@Composable
fun AzxSectionHeader(
  title: String,
  subtitle: String? = null,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        color = PureWhite,
      )
      if (!subtitle.isNullOrBlank()) {
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MidGray,
        )
      }
    }
    if (actionLabel != null && onAction != null) {
      Box(
        modifier =
          Modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onAction)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = actionLabel,
          style = MaterialTheme.typography.labelMedium,
          color = LightGray,
        )
      }
    }
  }
}

@Composable
fun AzxEmptyState(
  icon: ImageVector,
  title: String,
  description: String,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  AzxCard(modifier = modifier, containerColor = AlmostBlack) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = MidGray,
        modifier = Modifier.size(32.dp),
      )
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = PureWhite,
      )
      Text(
        text = description,
        style = MaterialTheme.typography.bodySmall,
        color = MidGray,
      )
      if (actionLabel != null && onAction != null) {
        Spacer(modifier = Modifier.height(4.dp))
        AzxSecondaryButton(text = actionLabel, onClick = onAction)
      }
    }
  }
}

data class MonochromeChartPoint(
  val label: String,
  val value: Float,
)

@Composable
fun AzxMonochromeBarChart(
  points: List<MonochromeChartPoint>,
  modifier: Modifier = Modifier,
) {
  if (points.isEmpty()) return
  val maxVal = (points.maxOfOrNull { it.value } ?: 1f).coerceAtLeast(1f)
  Column(modifier = modifier.fillMaxWidth()) {
    Canvas(
      modifier = Modifier.fillMaxWidth().height(130.dp),
    ) {
      val barCount = points.size
      val spacing = 10.dp.toPx()
      val totalSpacing = spacing * (barCount - 1).coerceAtLeast(0)
      val barWidth = ((size.width - totalSpacing) / barCount.coerceAtLeast(1)).coerceAtLeast(6f)
      val baseY = size.height - 6.dp.toPx()

      // Baseline grid lines
      for (i in 0..2) {
        val y = baseY * (i / 2f)
        drawLine(
          color = DarkGray,
          start = Offset(0f, y),
          end = Offset(size.width, y),
          strokeWidth = 1.dp.toPx(),
        )
      }

      points.forEachIndexed { idx, point ->
        val ratio = (point.value / maxVal).coerceIn(0f, 1f)
        val barH = (baseY - 4.dp.toPx()) * ratio
        val x = idx * (barWidth + spacing)
        drawRoundRect(
          color = DarkGray.copy(alpha = 0.45f),
          topLeft = Offset(x, 0f),
          size = Size(barWidth, baseY),
          cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
        )
        if (barH > 0f) {
          drawRoundRect(
            color = if (ratio >= 0.7f) PureWhite else LightGray,
            topLeft = Offset(x, baseY - barH),
            size = Size(barWidth, barH),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
          )
        }
      }
    }
    Spacer(modifier = Modifier.height(6.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      points.forEach { point ->
        Text(
          text = point.label,
          style = MaterialTheme.typography.labelSmall,
          color = MidGray,
          maxLines = 1,
        )
      }
    }
  }
}

@Composable
fun AzxMonochromeLineChart(
  points: List<MonochromeChartPoint>,
  modifier: Modifier = Modifier,
) {
  if (points.isEmpty()) return
  val maxVal = (points.maxOfOrNull { it.value } ?: 1f).coerceAtLeast(1f)
  Column(modifier = modifier.fillMaxWidth()) {
    Canvas(modifier = Modifier.fillMaxWidth().height(120.dp)) {
      val stepX =
        if (points.size > 1) size.width / (points.size - 1) else size.width
      val h = size.height - 12.dp.toPx()
      val path = Path()
      val offsets =
        points.mapIndexed { idx, pt ->
          val x = if (points.size == 1) size.width / 2f else idx * stepX
          val y = 6.dp.toPx() + h * (1f - (pt.value / maxVal).coerceIn(0f, 1f))
          Offset(x, y)
        }
      offsets.forEachIndexed { idx, offset ->
        if (idx == 0) path.moveTo(offset.x, offset.y) else path.lineTo(offset.x, offset.y)
      }
      drawLine(
        color = DarkGray,
        start = Offset(0f, size.height - 6.dp.toPx()),
        end = Offset(size.width, size.height - 6.dp.toPx()),
        strokeWidth = 1.dp.toPx(),
      )
      drawPath(
        path = path,
        color = PureWhite,
        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
      )
      offsets.forEach { offset ->
        drawCircle(color = PureBlack, radius = 4.5.dp.toPx(), center = offset)
        drawCircle(color = PureWhite, radius = 3.dp.toPx(), center = offset)
      }
    }
    Spacer(modifier = Modifier.height(4.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      points.forEach {
        Text(text = it.label, style = MaterialTheme.typography.labelSmall, color = MidGray)
      }
    }
  }
}
