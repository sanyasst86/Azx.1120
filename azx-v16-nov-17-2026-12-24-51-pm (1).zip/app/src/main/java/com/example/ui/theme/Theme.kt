package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val AzxMonochromeColorScheme =
  darkColorScheme(
    primary = PureWhite,
    onPrimary = PureBlack,
    primaryContainer = Graphite,
    onPrimaryContainer = PureWhite,
    secondary = LightGray,
    onSecondary = PureBlack,
    secondaryContainer = DarkGray,
    onSecondaryContainer = PureWhite,
    tertiary = MidGray,
    onTertiary = PureWhite,
    tertiaryContainer = AlmostBlack,
    onTertiaryContainer = LightGray,
    background = PureBlack,
    onBackground = PureWhite,
    surface = AlmostBlack,
    onSurface = PureWhite,
    surfaceVariant = Graphite,
    onSurfaceVariant = LightGray,
    surfaceContainerLowest = PureBlack,
    surfaceContainerLow = AlmostBlack,
    surfaceContainer = Graphite,
    surfaceContainerHigh = Graphite,
    surfaceContainerHighest = DarkGray,
    outline = DarkGray,
    outlineVariant = DarkGray,
    error = LightGray,
    onError = PureBlack,
    errorContainer = Graphite,
    onErrorContainer = PureWhite,
    inverseSurface = PureWhite,
    inverseOnSurface = PureBlack,
    inversePrimary = PureBlack,
    surfaceTint = PureWhite,
  )

val AzxShapes =
  Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp),
  )

@Composable
fun AzxTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = AzxMonochromeColorScheme,
    typography = AzxTypography,
    shapes = AzxShapes,
    content = content,
  )
}
