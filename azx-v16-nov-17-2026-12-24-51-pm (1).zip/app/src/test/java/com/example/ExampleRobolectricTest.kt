package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AzxDatabase
import com.example.data.local.AzxPreferencesDataStore
import com.example.data.local.entity.DiaryEntryEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.repository.AzxRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var context: Context
  private lateinit var db: AzxDatabase
  private lateinit var repo: AzxRepository

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    db = Room.inMemoryDatabaseBuilder(context, AzxDatabase::class.java).allowMainThreadQueries().build()
    repo = AzxRepository(db, AzxPreferencesDataStore(context))
  }

  @After
  fun tearDown() {
    db.close()
  }

  @Test
  fun `app metadata strings match AZX V16 identity`() {
    assertEquals("AZX.V16", context.getString(R.string.app_name))
    assertEquals("BUILD YOUR PRIME", context.getString(R.string.app_slogan))
  }

  @Test
  fun `initial seed starts with zero fake user xp and zero completed tasks`() = runBlocking {
    repo.ensureInitialized()
    assertEquals(0, repo.totalXp.first())
    assertTrue(repo.tasks.first().isEmpty())
    assertTrue(repo.exercises.first().isNotEmpty())
    assertTrue(repo.workouts.first().isNotEmpty())
    assertTrue(repo.achievements.first().isNotEmpty())
    assertTrue(repo.missions.first().isNotEmpty())
  }

  @Test
  fun `xp anti duplication prevents farming xp by toggling same task repeatedly`() = runBlocking {
    repo.ensureInitialized()
    val today = AzxRepository.todayEpochDay()
    val id =
      repo.saveTask(
        TaskEntity(
          title = "Отжимания с контролем",
          direction = "BODY",
          dateEpochDay = today,
          xpAwarded = 40,
        ),
      )
    val created = repo.tasks.first().first { it.id == id }

    // Mark DONE -> awards 40 XP + unlocks FIRST_TASK achievement (30 XP) = 70 XP
    repo.toggleTaskDone(created)
    val xpAfterFirst = repo.totalXp.first()
    assertEquals(70, xpAfterFirst)

    // Toggle back to TODO then DONE again -> must NOT duplicate task_done XP or achievement XP
    val doneTask = repo.tasks.first().first { it.id == id }
    repo.toggleTaskDone(doneTask)
    val todoAgain = repo.tasks.first().first { it.id == id }
    repo.toggleTaskDone(todoAgain)

    val taskTxCount = repo.xpTransactions.first().count { it.actionKey == "task_done_$id" }
    assertEquals(1, taskTxCount)
    assertEquals(70, repo.totalXp.first())
  }

  @Test
  fun `rest day diary entry preserves streak without penalty`() = runBlocking {
    repo.ensureInitialized()
    val today = AzxRepository.todayEpochDay()
    // Active task completed 2 days ago
    repo.saveTask(
      TaskEntity(
        title = "Растяжка и бег",
        direction = "BODY",
        dateEpochDay = today - 2,
        status = "DONE",
        completedAt = AzxRepository.millisFromEpochDay(today - 2),
      ),
    )
    // Rest day recorded yesterday in diary
    repo.saveDiaryEntry(
      DiaryEntryEntity(
        dateEpochDay = today - 1,
        moodRating = 4,
        energyRating = 4,
        sleepHours = 8.5f,
        isRestDay = true,
        gratitudeOrNote = "День восстановления",
      ),
    )
    // Active task completed today
    repo.saveTask(
      TaskEntity(
        title = "Броски по кольцу",
        direction = "BASKETBALL",
        dateEpochDay = today,
        status = "DONE",
        completedAt = AzxRepository.millisFromEpochDay(today),
      ),
    )
    val streak =
      repo.computeOverallStreak(
        tasks = repo.tasks.first(),
        habitHistories = repo.habitHistory.first(),
        workoutHistories = repo.workoutHistory.first(),
        diaryEntries = repo.diaryEntries.first(),
      )
    assertEquals(3, streak)
  }

  @Test
  fun `backup snapshot export and restore preserves tasks and workouts`() = runBlocking {
    repo.ensureInitialized()
    val today = AzxRepository.todayEpochDay()
    repo.saveTask(
      TaskEntity(
        title = "Повторить английские слова",
        direction = "MIND",
        dateEpochDay = today,
        xpAwarded = 25,
      ),
    )
    val snapshot = repo.createBackupSnapshot()
    assertEquals(1, snapshot.tasks.size)

    // Clear and restore
    db.coreDao().clearTasks()
    assertTrue(repo.tasks.first().isEmpty())

    repo.restoreBackupSnapshot(snapshot)
    val restored = repo.tasks.first()
    assertEquals(1, restored.size)
    assertEquals("Повторить английские слова", restored.first().title)
  }
}
