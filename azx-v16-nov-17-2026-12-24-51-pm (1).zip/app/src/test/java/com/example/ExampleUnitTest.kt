package com.example

import com.example.backup.BackupManager
import com.example.backup.BackupVerifyResult
import com.example.coach.CoachHorizon
import com.example.coach.CoachPlanner
import com.example.data.local.SeedData
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.ProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.repository.FullBackupSnapshot
import com.example.domain.model.AnatomySide
import com.example.domain.model.LevelSystem
import com.example.domain.model.MuscleGroup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun `level system starts at level 1 with zero xp and advances cleanly`() {
    val start = LevelSystem.calculate(0)
    assertEquals(1, start.level)
    assertEquals(0, start.currentXp)
    assertEquals(100, start.nextLevelXp)
    assertEquals("СТАРТ", start.rankTitle)

    val lvl2 = LevelSystem.calculate(100)
    assertEquals(2, lvl2.level)
    assertEquals("СТАРТ", lvl2.rankTitle)

    val lvl3 = LevelSystem.calculate(250)
    assertEquals(3, lvl3.level)
    assertEquals("ИНИЦИАТОР", lvl3.rankTitle)
  }

  @Test
  fun `muscle groups cover 8 front and 8 back groups with side aware deltoid picking`() {
    assertEquals(8, MuscleGroup.frontGroups().size)
    assertEquals(8, MuscleGroup.backGroups().size)
    assertEquals(
      MuscleGroup.ANTERIOR_DELTS,
      MuscleGroup.fromNodeName("deltoid", AnatomySide.FRONT),
    )
    assertEquals(
      MuscleGroup.POSTERIOR_DELTS,
      MuscleGroup.fromNodeName("deltoid", AnatomySide.BACK),
    )
    assertEquals(
      MuscleGroup.PECTORALS,
      MuscleGroup.fromNodeName("pectoralis-major", AnatomySide.FRONT),
    )
  }

  @Test
  fun `backup manager detects tampered payload via sha256 verification`() {
    val snapshot =
      FullBackupSnapshot(
        exportedAt = 1_700_000_000_000L,
        profile = ProfileEntity(displayName = "Тест Атлет"),
        tasks = listOf(
          TaskEntity(
            id = 1L,
            title = "Пробежка",
            direction = "BODY",
            dateEpochDay = 20_000L,
            status = "DONE",
            xpAwarded = 30,
          ),
        ),
      )
    val validJson = BackupManager.serializeEnvelope(snapshot)
    val verified = BackupManager.verifyAndParseEnvelope(validJson)
    assertTrue(verified is BackupVerifyResult.Valid)
    assertEquals("Тест Атлет", (verified as BackupVerifyResult.Valid).snapshot.profile?.displayName)

    val tamperedJson = validJson.replace("Тест Атлет", "Подмена")
    val tampered = BackupManager.verifyAndParseEnvelope(tamperedJson)
    assertTrue(tampered is BackupVerifyResult.Invalid)
  }

  @Test
  fun `coach planner flags overdue tasks and plans day and week horizons`() {
    val today = 20_100L
    val tasks =
      listOf(
        TaskEntity(
          id = 1L,
          title = "Просроченная задача",
          direction = "MIND",
          dateEpochDay = today - 2,
          priority = 3,
          durationMinutes = 40,
        ),
        TaskEntity(
          id = 2L,
          title = "Броски в кольцо",
          direction = "BASKETBALL",
          dateEpochDay = today,
          priority = 2,
          durationMinutes = 45,
        ),
      )
    val dayPlan =
      CoachPlanner.buildPlan(
        horizon = CoachHorizon.DAY,
        baseDay = today,
        profile = ProfileEntity(),
        tasks = tasks,
        goals = listOf(
          GoalEntity(
            id = 1L,
            title = "Скорость",
            direction = "BODY",
            priority = 3,
            deadlineEpochDay = today + 14,
          ),
        ),
        workouts = SeedData.defaultWorkouts(),
        existingEvents = emptyList(),
      )
    assertEquals(1, dayPlan.overdueCount)
    assertTrue(dayPlan.blocks.any { it.title == "Просроченная задача" })
    assertTrue(dayPlan.blocks.any { it.type == "REST" })

    val weekPlan =
      CoachPlanner.buildPlan(
        horizon = CoachHorizon.WEEK,
        baseDay = today,
        profile = ProfileEntity(),
        tasks = tasks,
        goals = emptyList(),
        workouts = SeedData.defaultWorkouts(),
        existingEvents = emptyList(),
      )
    assertTrue(weekPlan.blocks.map { it.dateEpochDay }.distinct().size == 7)
  }
}
